#include <windows.h>   // jjhou
#include <iostream.h>  // jjhou
#include "mfclite.h"   // jjhou
#include "shape.h"     // jjhou

void main()
{
  CDWordArray myArray;
  myArray.Add(2);
  myArray.Add(3);
  myArray.Add(4);
  myArray.Add(5);
  myArray.Add(6);
  myArray.Add(2);

/*
  // test CFile
  {
  CFile aFile("output.dat", CFile::modeWrite);
  for (int i=0; i<6; i++) {
    DWORD dw = myArray[i];
    aFile.Write(&dw, sizeof(DWORD));
  }
  aFile.Close();
  }

  {
  CFile aFile("output.dat", CFile::modeRead);
  DWORD dw;
  for (int i=0; i<6; i++) {
    aFile.Read(&dw, sizeof(DWORD));
    cout << dw << endl;
  }
  aFile.Close();
  }


  // test CArchive
  {
  CFile* pFile = new CFile("output2.dat", CFile::modeWrite);
  CArchive saveArchive(pFile, CArchive::store);
  for (int i=0; i<6; i++) {
    DWORD dw = myArray[i];
    saveArchive.Write(&dw, sizeof(DWORD));
  }
  saveArchive.Close();
  pFile->Close();
  }

  {
  CFile* pFile = new CFile("output2.dat", CFile::modeRead);
  CArchive loadArchive(pFile, CArchive::load);
  DWORD dw;
  for (int i=0; i<6; i++) {
    loadArchive.Read(&dw, sizeof(DWORD));
    cout << dw << endl;
  }
  loadArchive.Close();
  pFile->Close();
  }


  // test CDWordArray's Serialize
  {
  CFile* pFile = new CFile("output3.dat", CFile::modeWrite);
  CArchive ar(pFile, CArchive::store);
  myArray.Serialize(ar);
  ar.Close();
  pFile->Close();
  }

  {
  CFile* pFile = new CFile("output3.dat", CFile::modeRead);
  CArchive ar(pFile, CArchive::load);
  myArray.Serialize(ar);
  ar.Close();
  pFile->Close();

  cout << myArray[0] << endl;
  cout << myArray[1] << endl;
  cout << myArray[2] << endl;
  cout << myArray[3] << endl;
  cout << myArray[4] << endl;
  cout << myArray[5] << endl;
  }
*/

  // test CObList and Serialization
  {
  CFile* pFile = new CFile("output4.dat", CFile::modeWrite);
  CArchive ar(pFile, CArchive::store);
  CObList myList;
  myList.AddTail(&myArray);
  myList.Serialize(ar);
  ar.Close();
  pFile->Close();
  }

  {
  CFile* pFile = new CFile("output4.dat", CFile::modeRead);
  CArchive ar(pFile, CArchive::load);
  CObList myList;
  myList.Serialize(ar);
  ar.Close();
  pFile->Close();

  POSITION pos = myList.GetHeadPosition();
  while (pos != NULL) {
      CDWordArray* pDArray = (CDWordArray*)myList.GetNext(pos);
      for (int i = 0; i< pDArray->GetSize(); i++)
           cout << (*pDArray)[i] << endl;
  }
  }

  {
  CShape* pShape[6];

  pShape[0] = new CEllipse(3.0, 3.0, 7.0, 21.0);
  pShape[1] = new CCircle(5.0, 5.0, 7.0);
  pShape[2] = new CTriangle(0.0, 0.0, 1.0, 0.0, 0.0, 1.0);
  pShape[3] = new CRect(5.6, 6.8, 3.0, 9.0);
  pShape[4] = new CSquare(3.2, 4.3, 6.0);
  pShape[5] = new CStroke;
  CStroke* pStroke = dynamic_cast<CStroke*>(pShape[5]);
  pStroke->aDArray.Add(1);
  pStroke->aDArray.Add(2);
  pStroke->aDArray.Add(3);
  pStroke->aDArray.Add(4);
  pStroke->aDArray.Add(5);
  pStroke->aDArray.Add(6);
  pStroke->aDArray.Add(7);

  CFile* pFile = new CFile("output5.dat", CFile::modeWrite);
  CArchive ar(pFile, CArchive::store);
  CObList myList;

  for (int i=0; i<6; i++)
      myList.AddTail(pShape[i]);

  myList.Serialize(ar);
  ar.Close();
  pFile->Close();

  POSITION pos = myList.GetHeadPosition();
  while (pos != NULL) {
      CShape* pS = (CShape*)myList.GetNext(pos);
      pS->display();
  }
 }


  {
  CFile* pFile = new CFile("output5.dat", CFile::modeRead);
  CArchive ar(pFile, CArchive::load);
  CObList myList;
  myList.Serialize(ar);
  ar.Close();
  pFile->Close();

  POSITION pos = myList.GetHeadPosition();
  while (pos != NULL) {
      CShape* pS = (CShape*)myList.GetNext(pos);
      pS->display();
  }
  }
}

