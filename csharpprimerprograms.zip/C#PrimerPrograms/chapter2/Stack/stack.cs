namespace CSharpPrimer
{
    public class stack 
	{
		private static byte ms_default_size; // = 24;
		private int         m_top = 0;
     	private string []   m_stack;

		public bool Empty { get{ return m_top == 0; }}
		public bool Full  { get{ return m_top == m_stack.Length; }}

		public void push( string elem )
		{
			if ( Full )
				 throw new System.Exception( "push on stack full" );
			
			m_stack[ m_top++ ] = elem;
		}

		public string pop()
		{
			if ( Empty )
				 throw new System.Exception( "pop on stack empty" );
			
			return m_stack[ --m_top ];
		}

		public string peek()
		{
			if ( Empty )
			     throw new System.Exception( "peek on stack empty" );

			return m_stack[ m_top - 1 ];
		}

		static stack(){ ms_default_size = 24; }
		
		public stack() : this( ms_default_size ) {}
		public stack( int size )
		{
			if ( size <= 0 )
				 size = ms_default_size;

			m_stack = new string[ size ];
		}

		public stack( string [] array ) : this( array, false ) {}
		public stack( string [] array, bool fromBack )
		{
			if ( array.Length == 0 )
			     throw new System.Exception( "init with empty array" );

			m_stack = new string[ array.Length ];
			for ( int iy = 0, ix = fromBack ? array.Length-1 : 0; 
				  iy < array.Length ; 
				  ++iy, ix += fromBack ? -1 : 1 )
				        m_stack[ iy ] = array[ ix ];

			m_top = array.Length;
		}

		static public byte DefaultSize
		{ 
			get{ return ms_default_size;  }
			set{ ms_default_size = value; }
		}

		public int Count
			 { get{ return m_top; }}

		public int Size
		{
			get
			{ 
				if ( m_stack == null )
					 m_stack = new string[ ms_default_size ];
				
				return m_stack.Length; 
			}

			set
			{
				if ( value > m_stack.Length ){
					string [] t = new string[ value ];
					for ( int ix = 0; ix < m_stack.Length; ++ix )
						  t[ ix ] = m_stack[ ix ];
				}
			}
      }
	}
}
