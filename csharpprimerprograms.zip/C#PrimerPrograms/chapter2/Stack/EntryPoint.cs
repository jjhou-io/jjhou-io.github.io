using CSharpPrimer;
using System;

public class EntryPoint
{
	public static int Main()
	{
		string [] text = 
		{
			@"Alice Emma has long flowing red hair. Her Daddy says",
			@"when the wind blows through her hair, it looks almost alive,",
			@"like a fiery bird in flight. A beautiful fiery bird, he tells her,",
			@"magical but untamed. ""Daddy, shush, there is no such creature,""",
			@"she tells him, at the same time wanting him to tell her more.",
			@"Shyly, she asks, ""I mean, Daddy, is there?""",
		};

		try
		{	
			Console.WriteLine( "OK: about to initialize stack with array\n" );

			bool  fromBack = true;
		    stack myStack = new stack( text, fromBack );

			Console.WriteLine( "stack size: {0}", myStack.Size );
			Console.WriteLine( "stack top elem: {0}", myStack.peek());

			Console.WriteLine( "\nOK: about to pop each string:\n" );

			while ( !myStack.Empty )
					Console.WriteLine( myStack.pop() );

			Console.WriteLine( "\nOK: completed while loop." );
		}
		catch( Exception e )
		{
			Console.WriteLine( "Exception caught: {0}", e.Message );
			return -1;
		}
		finally
		{
			Console.WriteLine( "OK: in finally. Always finish here" );
			// return 0; // illegal
		}

		return 0;
	}
	
}
