using System;

public class EnumTest
{
	public static void Main()
	{
		Console.WriteLine( "Beginning EnumTest.Main()" );

		EnumUsage.enumUsage();
		EnumUsage.classUsage();

		Console.WriteLine( "Beginning EnumTest.Main()" );
	}
}

public enum chapters 
{
	Preface, BasicLang, Class, Inheritance, Interfaces, Exceptions,
	Namespaces, Attributes, Reflection, Delegates, Collections,
	current = Preface
}

class tester
{
	public enum weekdays : byte 
	{ sunday, monday, tuesday, wednesday, thursday, friday, saturday };

	public static string [] daysFrench = 
		{
				"dimanche", "lundi", "mardi", "mercredi",
			    "jeudi", "vendredi", "samedi" };

	public static void test( string [] foreign )
	{
		weekdays wd = weekdays.sunday;
		for ( ; wd <= weekdays.saturday; ++wd )
			Console.WriteLine( wd + " : " +  foreign[ (int)wd ] );
	}
}

public class EnumUsage
{
	public static int ival;
	static bool [] status = new bool[]
	{
		false, false, false, true, false, true, 
		false, true,  false, true, true
	};

	public static void statusIndex( chapters c )
	{
		int eval = (int)Enum.Parse( c.GetType(),c.ToString() );
		Console.WriteLine( "\tThe {0} Chapter is {1}",
			                c, status[eval]? "complete" : "incomplete" );
	}

    public enum OpenModes : byte
		{ input = 1, output, append };

	public enum test1 { a = x, b, c = 2, x = (int)3.0 };
    // note difference in this instance which results in error: 
	//      public enum test2{ a = x, b, c , x };


	public static void enumUsage()
	{
		chapters next_todo = chapters.current;
		Console.WriteLine( "\nThe next chapter to do is {0}", next_todo ); 
		
	    Type enumType = typeof( OpenModes );
        Type elemType = Enum.GetUnderlyingType( enumType);
	    Console.WriteLine( "{0} underlying type of {1}",
				elemType.FullName, 
				enumType.FullName );  
	}

	public static void classUsage()
	{
		// get enum value from enumeration string

		// previous version of Enum
		// chapters todo = (chapters) Enum.FromString( typeof( chapters), "current" );
		
		// equivalent functionality now 
		chapters todo = (chapters) Enum.Parse( typeof( chapters), "current" );

		// get string array of the enumeration names stable ordered by value
		string [] enums  = Enum.GetNames(  typeof( chapters )); 

        // get object array of the values ordered by value
		// previously, an array of object
		//          object [] values = Enum.GetValues( todo.GetType() );
		Array values = Enum.GetValues( todo.GetType() ); 

	    Console.WriteLine( "The chapters enum has {0} members:\n", enums.Length );
		for ( int ix = 0; ix < enums.Length; ++ix ) 
		{
			  if ( enums[ix].Equals( "current" ))
				   continue;

			  Console.WriteLine( "\n\t{0} :: {1} ", 
					             enums[ix], values.GetValue(ix).ToString() );

			 statusIndex( (chapters)values.GetValue(ix) );
		}

		// get enum string from enumeration value
		Console.WriteLine( "\nThe current chapter working on is {0}", 
			                Enum.GetName( todo.GetType(), todo ));

		Console.WriteLine();
	}
	
}
