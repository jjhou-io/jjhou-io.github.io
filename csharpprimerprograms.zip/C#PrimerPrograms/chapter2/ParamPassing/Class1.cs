using System;

public class EntryPoint
{

	static public void byOut( out string s )
    {
		Console.WriteLine( "\nInside byOut -- parameter assumed to be unassigned!" );
		s = "The Last Unicorn";
		Console.WriteLine( "\nInside byOut: modified parameter: \n\t" + s );
    }

	static public void byRef( ref string s )
    {
		Console.WriteLine( "\nInside byRef: original parameter: \n\t" + s );
		s = s.ToUpper();
		Console.WriteLine( "\nInside byRef: modified parameter: \n\t" + s );
    }

    static public void byValue( string s )
    {
		Console.WriteLine( "\nInside byValue: original parameter: \n\t" + s );
		s = s.ToUpper();
		Console.WriteLine( "\nInside byValue: modified parameter: \n\t" + s );
    }

    public void message(){ Console.WriteLine( "message()" ); }
    public void message( char ch ){ Console.WriteLine( "message( {0} )", ch ); }
    public void message( string msg, params object[] args )
		{ Console.WriteLine( "string, params object[]" ); 
	Console.WriteLine( msg );
	if ( args.Length != 0 )
	     foreach ( object o in args )
                Console.WriteLine( "{0}", o.ToString() );

	}
    public void message( string msg, params int[] args )   
		{ Console.WriteLine( "string, params int[]" );}
    public void message( string msg, params double[] args )
		{ Console.WriteLine( "string, params double[]" );}
	public void message( params  object[] args ) {}
									

	static public void call_message()
	{
		EntryPoint ep = new EntryPoint();
		ep.message();
		ep.message( 'a' );
		int ival= 10, dval = 0;
		ep.message( "hello", 10, ival, dval, 1024 );
		double d1 = 3.14, d2 = 3.14159;
		ep.message( "hello", d1, d2, 3.1 );
		ep.message( "hello", ival, d1, d2, dval );
		ep.message( "hello", false, ep );
		// message( 1024 );
		// message( "hello" );
	}

    public static void Main()
    {
        string str = "A fine and private place";

		Console.WriteLine( "string to be passed by value: \n\t" + str );
		byValue( str );
		Console.WriteLine( "\nback from call -- string: \n\t" + str );

		Console.WriteLine( "\nstring to be passed by ref: \n\t" + str );
		byRef( ref str );
		Console.WriteLine( "\nback from call -- string: \n\t" + str );

		string newstr;
		Console.WriteLine( "\nstring to be passed by out: uninitialized" );
		byOut( out newstr );
		Console.WriteLine( "\nback from call -- string: \n\t" + newstr );
		call_message();

    }
 
}
