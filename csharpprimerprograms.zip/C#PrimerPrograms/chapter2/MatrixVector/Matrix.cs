#define DEBUG

using System;


namespace Mathlib
{
  public class foobar
  {
		public static matrix m1 = new matrix(2,2), m2;
		static foobar()
		{
			Console.WriteLine( "static foobar()" );
			m2 = new matrix(4,4);
		}
  }

  public struct matrix
  {
    public static readonly matrix zero = new matrix( new double[4,4]);
	public static readonly matrix identity;

	private const int ms_defaultRowSize = 4;
	private const int ms_defaultColSize = 4;

    private static int ms_objectCount;
	static public  int ObjectCount{ get { return ms_objectCount; }}
	
	static matrix()
	{
		identity = new matrix( new double[,] {
			{ 1, 0, 0, 0 },
			{ 0, 1, 0, 0 },
			{ 0, 0, 1, 0 },
			{ 0, 0, 0, 1 }});
	}

	public matrix( int row, int col )
	{
		m_row = ( row <= 0 ) ? 1 : row;
		m_col = ( col <= 0 ) ? 1 : col;

		m_mat = new double[ m_row, m_col ];
		ms_objectCount++;
	}

    // structs cannot contain a default constructor
	// public matrix() : this( ms_defaultRowSize, ms_defaultColSize ) {}

	  // to show the difference between object equality
	  // and value equality -- explain the difference 
	  // between Object.Equal and the value equal of the
	  // array class -- two items with identity would be
	  // 

    public matrix( double [,] mat )
	{ 
		m_row = mat.GetLength( 0 );
		m_col = mat.GetLength( 1 );

		// deep copy
		m_mat = new double[ m_row, m_col ];
		for ( int ix = 0; ix < m_row; ++ix )
			  for ( int iy = 0; iy < m_col; ++iy)
					m_mat[ ix, iy ] = mat[ ix, iy ];
		
		ms_objectCount++;
	}

    // structs may not have destructors ...
	// public ~matrix(){ ms_objectCount--; }
    public void Dispose() { ms_objectCount--; } 

	public static matrix operator*( matrix m1, matrix m2 )
	{
	    check_row_and_col( m1, m2 );
		matrix mat = new matrix( m1.rows, m2.cols );

        for ( int ix = 0; ix < m1.rows; ix++ )
              for ( int iy = 0; iy < m2.cols; iy++ )
                    for ( int k = 0; k < m1.cols; k++ )
						  mat[ ix, iy ] += m1[ ix, k ] * m2[ k, iy ];

        return mat;
	}

	public static matrix multiplyByDouble( matrix m1, double dval )
	{
		matrix mat = new matrix( m1.rows, m1.cols );

        for ( int ix = 0; ix < m1.rows; ix++ )
              for ( int iy = 0; iy < m1.cols; iy++ )
					mat[ ix, iy ] = m1[ ix, iy ] * dval;

        return mat;
	}

	public static matrix operator*( matrix m1, double dval )
	{
		matrix mat = new matrix( m1.rows, m1.cols );

        for ( int ix = 0; ix < m1.rows; ix++ )
              for ( int iy = 0; iy < m1.cols; iy++ )
					mat[ ix, iy ] = m1[ ix, iy ] * dval;

        return mat;
	}

    public static matrix operator*( double dval, matrix m )
	{
		return m*dval;
	}

	public static matrix operator+( matrix m1, matrix m2 )
	{
		check_both_rows_cols( m1, m2 );
		matrix mat = m1;

        for ( int ix = 0 ; ix < m1.rows; ix++ )
			  for ( int ij = 0; ij < m1.cols; ij++ )
				    mat[ ix, ij ] += m2[ ix, ij ];

        return mat;
    }

	
	public static matrix operator-( matrix m1, matrix m2 )
	{
		check_both_rows_cols( m1, m2 );
		matrix mat =  m1;

		for ( int ix = 0 ; ix < m1.rows; ix++ )
			for ( int ij = 0; ij < m1.cols; ij++ )
				  mat[ ix, ij ] -= m2[ ix, ij ];

		return mat;
	}

	public void transpose()
	{
		double [,] m = new double[ m_col, m_row ];  

		for ( int ix = 0; ix < m_row; ix++ )
			  for ( int iy = 0; iy < m_col; iy++ )
                    m[ iy, ix ] = m_mat[ ix, iy ];

		m_mat = m;

		if ( m_row != m_col ){
		     int t = m_row;
		     m_row = m_col;
			 m_col = t; 
		}
	}

	static public void transpose( /*ref*/ matrix mat )
	{
		double [,] m = new double[ mat.m_col, mat.m_row ];  

		for ( int ix = 0; ix < mat.m_row; ix++ )
			  for ( int iy = 0; iy < mat.m_col; iy++ )
                    m[ iy, ix ] = mat.m_mat[ ix, iy ];

		mat.m_mat = m;

		if ( mat.m_row != mat.m_col ){
		     int t = mat.m_row;
		     mat.m_row = mat.m_col;
			 mat.m_col = t; 
		}

		mat.display( "within transpose as static method" );
	}


	public vector get_col( int c )
	{
		check_index( c, m_col );
		vector vec = new vector( m_row );
		
		for ( int ix = 0; ix < m_row; ix++ )
		      vec[ ix ] = m_mat[ ix, c ];

		return vec;
	}

	public vector get_row( int r ) 
	{
	    check_index( r, m_row );
		vector vec = new vector( m_col );

	    for ( int ix = 0; ix < m_row; ix++ )
	          vec[ ix ] = m_mat[ r, ix ];

	    return vec;
	}

  
   public void set_col( int c, vector vec )
	{
		check_index( c, m_col );
		check_size( vec.Size, m_row );
		
		for ( int ix = 0; ix < m_row; ix++ )
		      m_mat[ ix, c ] = vec[ ix ];
	}


	public void set_row( int r,  vector vec )
	{
	    check_index( r, m_row ); 
	    check_size( vec.Size, m_col );

	    for ( int ix = 0; ix < m_row; ix++ )
	          m_mat[ r, ix ] = vec[ ix ];
	}


	private static void check_row_and_col( matrix m1, matrix m2 ) 
    { 
		// we'll create our own matrix exception hierarchy later
		if ( m1.rows != m2.cols )
	         throw new Exception( "Sorry, cannot perform matrix operation -- left row: " +
			                       m1.rows.ToString() + " must equal right column: " +
			                       m2.cols.ToString() ); 
	}

	private static void check_both_rows_cols( matrix m1, matrix m2 )
    { 
		if ( m1.cols != m2.cols || m1.rows != m2.rows )
			 throw new Exception( "Sorry, cannot perform matrix operation -- " +
								  " row & columns must be equal: (" +
								  m1.rows.ToString() + ", " + m1.cols.ToString() + ") " +
								  m2.rows.ToString() + ", " + m2.cols.ToString() + ") " );
	}

	private void check_bounds( int row, int col )
	{
		if ( row < 0 || row >= m_row ||
			 col < 0 || col >= m_col )
			throw new IndexOutOfRangeException( "invalid matrix indices: " + 
					                   row.ToString() + " " + col.ToString() );
	}

	public int rows{ get{ return m_row; }}
	public int cols{ get{ return m_col; }}

	public double this[ int row, int col ]
	{
		get{ check_bounds( row, col ); return m_mat[ row, col ];  }
		set{ check_bounds( row, col ); m_mat[ row, col ] = value; }
	}

	public void display( string msg )
	{
		Console.WriteLine( "\n{0} :: ( {1}, {2} )", msg, m_row, m_col );
		Console.WriteLine( "{" );
		
		for ( int ix = 0; ix < m_row; ++ix )
		{
			Console.Write( "\t{ " );
			for ( int iy = 0; iy < m_col; ++iy )
				  // Console.Write( "{0:F3} ", m_mat[ ix, iy ] );
				  Console.Write( "{0} ", m_mat[ ix, iy ] );
			Console.WriteLine( "}" );
		}
		Console.WriteLine( "}" );
	}

	public void check_size( int size, int expected_size ) 
	{
		if ( size != expected_size ) 
             throw new Exception( "Invalid matrix size : " + size.ToString() +
						          " -- expecting : " + expected_size.ToString());
    }

	public void check_index( int index, int upper_bound ) 
	{
		if ( index < 0 || index >= upper_bound )
		{
			string msg = "Invalid index: " + index.ToString() +
				" -- expecting something between 0 and " +
				upper_bound.ToString();

			throw new Exception( msg );
		}	 					   
	}    
		
	public static bool operator true( matrix m )
	  { return m.m_mat != null; }

	public static bool operator false( matrix m )
	  { return m.m_mat == null; }

	private double[,] m_mat;
	private int m_row;
	private int m_col;

} // struct matrix

} // namespace mathlib

