using System;
using Mathlib;
		  
class matTest
{
	public static void Main( string [] args )
	{
		if ( args.Length == 0 )
		{
			Console.WriteLine( "usage: MatrixVector -m -v" );
			Console.WriteLine( "executing Matrix tests by default" );
			matrixTest();
			return;
		}

		foreach ( string arg in args )
		{
			switch( arg )
			{
				case "-m":
					Console.WriteLine( "Beginning Matrix tests ... " );
					matrixTest();
					Console.WriteLine( "Ending Matrix tests ... " );
					break;

				case "-v":
					Console.WriteLine( "Beginning Vector tests ... " );
					matrixTest();
					Console.WriteLine( "Ending Vector tests ... " );
					break;

				default:
					Console.WriteLine( "Sorry, unrecognized option: {0}", arg );
					break;
			}
		}
	}
	
	static public void matrixTest()
	{
		try {
			matrix m1 = new matrix( 4, 4 );
			m1[ 0,0 ] = 1.0;
			m1[ 1,1 ] = 1.0;
			m1[ 2,2 ] = 1.0;
			m1[ 3,3 ] = 1.0;
			m1.display( "m1.matrix" );

			matrix m2 = new matrix( 4, 4 );
			for ( int ix = 0; ix < 4; ++ix )
				for ( int iy = 0; iy < 4; ++iy )
					  m2[ ix, iy ] = ix * iy + ix + iy;

			m2.display( "m2 matrix" );

			matrix m3 = m1 * m2;
			m3.display( "m3 matrix" );

			// implicitly defined
			m3 *= m2;
			m3.display( "m3 matrix" );

			matrix m4 = m1 + m2;
			m4.display( "m4 matrix" );

			matrix m5 = m4 + m3;
			m5.display( "m5 matrix" );

			matrix m6 = new matrix( 4, 5 );
			int icnt = 1;
			for ( int ix = 0; ix < 4; ++ix )
				for ( int iy = 0; iy < 5; ++iy )
					  m6[ ix, iy ] = icnt++;
			
			m6.display( "before transpose" );
			matrix.transpose( /*ref*/ m6 );
			// m6.transpose();
			m6.display( "after transpose" );

			matrix mat = matrix.multiplyByDouble( m6, 2 );
			mat.display( "after m6 multiplied by 2" );

			mat = m6 * 2;
			mat = 2 * m6;

			Console.WriteLine( "\nOK: About to generate an Exception" );
			m1[ 8,8 ] = 1.0;
		}
		catch ( IndexOutOfRangeException e )
		{
			Console.WriteLine( "OK: caught exception" );
			Console.WriteLine( e.Message );
		}
	}

	static public void vectorTest()
	{
		vector vec = new vector( 4 );
		vec[ 0 ] = 0.8; vec[ 1 ] = 0.3; vec[ 2 ] = 1; vec[ 3 ] = 0.659;
		vec.display( "initial vector" );
		Console.WriteLine();

		vector v2 = vec;
		v2.normalize();
		v2.display( "normalize vector" );
		Console.WriteLine();

		vector v3 = vec.normalize_copy();
		v3.display( "normalize_copy() " );
		Console.WriteLine();

		vector vec2 = new vector( 4 );
		vec2[ 0 ] = 1.8; vec2[ 1 ] = 2.5; vec2[ 2 ] = 0.89; vec2[ 3 ] = 1.59;
		double dotprod = vec.dot( vec2 );
		Console.WriteLine( "dot product of vec with vec2: {0:F5}", dotprod );

		vector v5 = vec.interpolate( vec2, dotprod ); 

		v5.display( "interpolate vector" );
		Console.WriteLine();

		matrix mat = new matrix( 4, 4 );
		mat[0,0] = 0.145; mat[0,1] = 0.145; mat[0,2] = 0.145; mat[0,3] = 0.145;
		mat[1,0] = 1.145; mat[1,1] = 1.145; mat[1,2] = 1.145; mat[1,3] = 1.145;
		mat[2,0] = 2.145; mat[2,1] = 2.145; mat[2,2] = 2.145; mat[2,3] = 2.145;
		mat[3,0] = 3.145; mat[3,1] = 3.145; mat[3,2] = 3.145; mat[3,3] = 3.145;

		vector v6 = mat.get_row( 2 );
		v6.display( "row two of matrix" );

		mat.set_row( 1, vec2 );
		mat.display( "row 1 set" );

	}

	public static void miscTest()
	{
		// this is only interesting if it is a class. need to make this
		// a class 
		/// TODO :: make Matrix a class ...
		/// 
		Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
		matrix m1 = new matrix( 3, 32 );
		Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
		{
			matrix m2 = new matrix( 2, 3 );
			Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
		}
		
		matrix m3 = m1;
		Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
		matrix m4 = new matrix( 32, 32 );
		Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
		matrix m5 = m1 + m3;
		Console.WriteLine( "number of objects: {0}", matrix.ObjectCount );
	}

	
}
