#define DEBUG

using System;

namespace Mathlib
{
    public struct vector 
	{

		public static bool operator true( vector v )
		{ return v.m_elem != null; }

		public static bool operator false( vector v )
		{ return v.m_elem == null; }

		private double [] m_elem;
		private int       m_size;

		public  int       Size { get{ return m_size; }}
		public  double    this[ int index ]
		{
			get{ confirm_index( index ); return m_elem[ index ];  }
			set{ confirm_index( index ); m_elem[ index ] = value; }
		}
	
		public vector( int sz )
		{
			m_size = ( sz <= 0 ) ? 1 : sz;
			m_elem = new double[ m_size ];
		}

		public vector( matrix mat ) 
		{
			m_size = mat.rows;
			m_elem = new double[ m_size ];
			for ( int ix = 0; ix < m_size; ++ix )
				  m_elem[ ix ] = mat[ ix, 0 ];
		}

		public void display( string msg )
		{
			Console.Write( msg + "\n{ " );
    
			for ( int ix = 0; ix < m_size; ++ix )
				  Console.Write( "{0:F4} ", m_elem[ix] );

			Console.WriteLine( "}" );
		}

		public bool   same_size( vector vec )
		     { return m_size == vec.m_size; }

		public double length()
		     { return Math.Sqrt( length_() ); }

		public double distance( vector v ) 
		     { return Math.Sqrt( distance_( v )); }

		public static vector operator/(  vector v, double dval )
		{
			vector vec = v;

			for ( int ix = 0; ix < vec.m_size; ix++ )
				  vec[ ix ] /= dval;

			return vec;
		}

		public static vector operator*(  matrix mat,  vector vec )
		{
			mat.check_size( vec.m_size, mat.cols );
			vector nvec = new vector( mat.rows );

			for ( int ix = 0; ix < mat.rows; ix++ )
				  for ( int iy = 0; iy < mat.cols; iy++ )
					    nvec.m_elem[ ix ] = mat[ ix, iy ] * vec[ iy ];

			return nvec;
		}

		public static vector operator*(  vector vec, matrix mat  )
		{
			mat.check_size( vec.m_size, mat.cols );
			vector nvec = new vector( mat.rows );

			for ( int ix = 0; ix < mat.rows; ix++ )
				  for ( int iy = 0; iy < mat.cols; iy++ )
					    nvec.m_elem[ ix ] = mat[ ix, iy ] * vec[ iy ];

			return nvec;
		}

		public bool normalize()
		{
			double len = length();

			if ( (int)len == 0 ) 
				  return false;

			for ( int ix = 0; ix < m_size; ix++ )
				  m_elem[ ix ] /= len;

			return true;
		}

		public vector normalize_copy() 
		{
			double len = length();
		 
			if ( (int)len == 0 ) 
				  return new vector( m_size );

			vector vec = this;
			for ( int ix = 0; ix < m_size; ix++ )
				  vec.m_elem[ ix ] /= len;

			return vec;
		}

		public double dot(  vector vec ) 
		{
			if ( ! same_size( vec ))
			     throw new Exception( "dot product requires vectors to be the same sizes" );
			
			double dotty = 0.0;
			for ( int ix = 0; ix < m_size; ix++ )
			      dotty += m_elem[ ix ] * vec.m_elem[ ix ];

			return dotty;
		}

		public vector 
		interpolate( vector vec, double dval ) 
		{
		    if ( ! same_size( vec ))
		         throw new Exception( "interpolate requires vectors to be the same sizes" );

		    vector newVec = this;

		    for ( int ix = 0; ix < m_size; ix++ ) 
		          newVec.m_elem[ix] += ( vec.m_elem[ ix ] - m_elem[ ix ] ) * dval;

		    return newVec;
		}

	    private double length_()
		{
			double len = 0.0;

			for ( int ix = 0; ix < m_size; ix++ )
				  len += m_elem[ ix ] * m_elem[ ix ];

			return len;
		}

		private double distance_( vector p ) 
		{
			double dist, dSquared = 0.0;
			if ( m_size == p.m_size ) 
			{
				for ( int ix = 0; ix < m_size; ix++ ) 
				{
					dist = m_elem[ ix ] - p.m_elem[ ix ];
					dSquared += dist * dist;
				}
			}
			return dSquared;
		}
		
		private void confirm_index( int index )
		{
			if ( index < 0 || index >= m_size )
			{
				string message = "Invalid index for vector object -- " +
								 "vector size: " + m_size + " index: " + index;

				throw new ArgumentOutOfRangeException( message );
			}	 
		}

		public static vector operator+( vector v1, vector v2 )
		{
			if ( ! v1.same_size( v2 ))
		         throw new Exception( "The two vectors to add must be of the same length");

		    vector vec = v1;

		    for ( int ix = 0; ix < vec.Size; ix++ )
		          vec[ ix ] += v2[ ix ];

		    return vec;
		}

		public static vector operator-(  vector v1, vector v2 )
		{
		    if ( ! v1.same_size( v2 ))
		         throw new Exception( "The two vectors to subtract must be of the same length");

		    vector vec = v1;
		    for ( int ix = 0; ix < vec.Size; ix++ )
		          vec[ ix ] -= v2[ ix ];

		    return vec;
		}

		public static vector operator-( vector v )
		{
		    vector vec = new vector( v.Size );

		    for ( int ix = 0; ix < vec.Size; ix++ )
		          vec[ ix ] = -v[ ix ];
		 
		    return vec;
		}

		public static vector operator*( vector v, double dval )
		{
		    vector vec = v;

		    for ( int ix = 0; ix < vec.Size; ix++ )
		          vec[ ix ] *= dval;

		    return vec;
		}

		public static vector operator*( double dval, vector v )
		   { return  v*dval; }



}
}