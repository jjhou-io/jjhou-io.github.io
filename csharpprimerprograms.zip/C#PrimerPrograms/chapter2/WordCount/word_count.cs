
using System;
using System.IO;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;    // for Application class
						       // need to add reference

public class WordCount
{
	public enum traceFlags { turnOff, toConsole, toFile };

	private string         m_file_name;
	private string         m_file_output;

	public string OutFile
	{
		get{ return m_file_output; }
		set{ 
			if ( value.Length != 0 )
			     m_file_output = value; 
		}
	}

	public int this[ string index ]
	{
		get
		{
			if ( index.Length == 0 )
				 throw new ArgumentException( "WordCount: Empty string as index" );
			
			if ( m_words == null )
			     throw new Exception( "WordCount: Have not processed a file yet!" );

			return (int) m_words[ index ];
		}
	}

	private bool           m_spy;
	private traceFlags     m_trace;

	private ArrayList      m_times;
	private ArrayList      m_text;

	private Hashtable      m_words;
    private string [][]    m_sentences;

	private StreamReader   m_reader;
	private StreamWriter   m_writer;
	private StreamWriter   m_tracer;

	private TextWriterTraceListener cout;

	static private char [] ms_separators = new char [] 
	      { ' ', '\n', '\t', '.', '\"', ';', ',', '?', '!',
		    ')', '(', '<', '>', '[', ']' };

	public WordCount( string file_name )
		 : this( file_name, false, traceFlags.turnOff ) {} 
	
	public WordCount( string file_name, bool spy, traceFlags trace )
	{
		m_file_name = file_name;
		m_spy = spy; 
		m_trace = trace;

		if ( m_spy )
			 m_times = new ArrayList();
	}

	public void processFile()
	{
		try 
		{
			openFiles();
			readFile();
			countWords();
			writeWords();
			Dispose();
		}
		catch ( Exception e )
		{
			Console.WriteLine( "Oops: Exception:\n" + e.Message );
		}
	}
	
	private void Dispose()
	{
		if ( m_trace != traceFlags.turnOff )
		     Trace.Listeners.Remove( cout );

		m_reader.Close();
		m_writer.Close();

		if ( m_tracer != null )
			 m_tracer.Close();
	}

	private void countWords()
	{
		Trace.WriteLine( "!!! WordCount.countWords: " +
			                  m_text.Count + " lines\n" );

		timer tt = null;
		
		m_sentences = new string[ m_text.Count ][];
		m_words     = new Hashtable();
		string str;
     
		// let's get rid of punctuation as well
		char [] separators = { ' ', '\n', '\t', '.', '\"', ';', ',', '?', '!',
		                       ')', '(', '<', '>', '[', ']' };

		if ( m_spy )
		{
			tt = new timer();
			tt.context = "Time to countWords ";
			tt.start();
		}

		for( int ix = 0; ix < m_text.Count; ++ix )
		{
			 str = ( string )m_text[ ix ];
			 m_sentences[ ix ] = str.Split( separators );

			 Trace.WriteLine( "!!! There are " + 
				               m_sentences[ ix ].Length.ToString() +
							   " words in line " + ( ix+1 ).ToString() );

			 foreach ( string st in m_sentences[ ix ])
			 {
				 string s = st.ToLower();
				 if ( m_words.Contains( s ) == false )
				 {
					 m_words.Add( s, 1 );
					 Trace.WriteLine( "!!! Adding " + s );
				 }  
				 else 
				 {
					 m_words[ s ] = (int) m_words[ s ] + 1;
					 Trace.WriteLine( "!!! Incrementing " + s + " : " +
									   m_words[ s ].ToString() );
				 }
			 }
		}
		
		if ( m_spy )
		{
			tt.stop();
			m_times.Add( tt.ToString() );
		}
	}

	private void readFile()
	{
		m_text = new ArrayList();

		timer  tt = null; 
		string text_line;

		Trace.WriteLine( "!!! WordCount.readFile: " + m_file_name + "\n"  );

		if ( m_spy )
		{
			tt = new timer();
			tt.context = "Time to read file ";
			tt.start();
		}

		while (( text_line = m_reader.ReadLine() ) != null )
		{
			if ( text_line.Length == 0 )
			{
				Trace.WriteLine( "\n" );
				continue;
			}

			Trace.WriteLine( "! " + text_line );
			m_text.Add( text_line );
		}

		if ( m_spy )
		{
			tt.stop();
			m_times.Add( tt.ToString() );
		}
	}

	private void openFiles()
	{
		Trace.WriteLine( "!!! WordCount.openFiles: " + m_file_name );
		timer tt = null; 

		if ( m_spy )
		{
			tt = new timer();
			tt.context = "Time to open files ";
			tt.start();
		}

		if ( m_file_name == null )
			 throw new ArgumentNullException();

		if ( ! File.Exists( m_file_name ))
		{
			string msg = "File does not exist: " + m_file_name;
	        throw new ArgumentException( msg );
	    }

		if ( ! m_file_name.EndsWith( ".txt" ))
		{
	        string msg = "Sorry. ";
            string ext = Path.GetExtension( m_file_name );
          
	        if ( ext == String.Empty )
		         msg += "We currenly do not support " + 
                         ext + " files.";

	        msg = "\nCurrenly we only support .txt files.";
	        throw new Exception( msg );
	    }

        m_reader = File.OpenText( m_file_name );

		string startupPath = Application.StartupPath;
		Trace.WriteLine( "!!! startupPath = " + startupPath );

		m_file_output = startupPath + @"\diag.txt";
		m_writer      = File.CreateText( m_file_output );

		if ( m_spy )
		{
			tt.stop();
			m_times.Add( tt.ToString() );
		}
		
		if  ( m_trace != traceFlags.turnOff )
			  switch ( m_trace )
			  {
				  case traceFlags.toConsole:
					   cout = new TextWriterTraceListener( Console.Out );
					   Trace.Listeners.Add( cout );
				  break;

				  case traceFlags.toFile:
					   m_tracer = File.CreateText(startupPath + @"\trace.txt");
					   cout = new TextWriterTraceListener( m_tracer );
					   Trace.Listeners.Add( cout );
				  break;
			 }
	}

	private void writeWords()
	{
		Trace.WriteLine( "!!! WordCount.writeWords: " + m_file_output );
		timer tt = null;

		if ( m_spy )
		{
			tt = new timer();
			tt.context = "Time to write file ";
			tt.start();
		}

		ArrayList aKeys = new ArrayList( m_words.Keys );
		aKeys.Sort();
		foreach ( string key in aKeys )
		{
			m_writer.WriteLine( "{0} : {1}", key, m_words[ key ] );
			Trace.WriteLine( "!!! " + key + " : " + m_words[ key ].ToString() );
		}	  
    
		if ( m_spy )
		{
			tt.stop();
			m_times.Add( tt.ToString() );
		}
	}

	[Conditional( "DEBUG" )]
	private void displayWordCount()
	{
		foreach ( DictionaryEntry de in m_words )
			      Console.WriteLine( "word: {0} :: occurrences: {1}", de.Key, de.Value );
	}
}
