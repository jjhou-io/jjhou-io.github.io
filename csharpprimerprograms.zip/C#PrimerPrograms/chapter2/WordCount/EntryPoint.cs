using System;
using System.IO;
using System.Collections;

public class WordCountEntry
{
	static public void display_usage()
	{
		string usage = 
			@"Usage: 
 
WordCount [-s] [-t|-tf] [-h] textfile.txt
	where [] indicates an optional argument
	-s  prints a series of performance measurements
	-t  prints a trace of the program to Console
	-tf prints a trace of the program to trace.txt
	-h  prints this message and exits 
";

        Console.WriteLine( usage );
	}

	static public void Main( string [] args )
	{
		Console.WriteLine( "Beginning WordCount program ... " );

		string m_login =
 	        Environment.OSVersion.Platform == PlatformID.Win32NT
	          ? Environment.GetEnvironmentVariable( "USERNAME" )
              : "Guest";

		Console.WriteLine( "m_login: " + m_login );

		if ( args.Length == 0 )
		   { display_usage(); return; }

		WordCount.traceFlags traceOn = WordCount.traceFlags.toConsole; // for now
		bool   spyOn     = false;
		string file_name = null;

		foreach ( string option in args )
			switch ( option )
			{
				case "-t":
					traceOn = WordCount.traceFlags.toConsole; 
					break;

				case "-tf":
					traceOn = WordCount.traceFlags.toFile; 
					break;

				case "-s":
					spyOn = true; break;

				case "-h":
					{ display_usage(); return; }

				default:
					file_name = option; break;
			}

		if ( file_name == null )
		   { display_usage(); return; }

		WordCount theObj = new WordCount( file_name, spyOn, traceOn );
		theObj.processFile();

		// theObj = new WordCount();

		Console.WriteLine( "Ending WordCount program ... " );
	}
}