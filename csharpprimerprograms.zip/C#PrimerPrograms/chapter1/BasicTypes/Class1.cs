 using System;
using System.Globalization;
   
 public class EntryPoint
 {
	 public static void testMisc()
	 {
		 int imaxval = int.MaxValue;
		 int iminval = int.MinValue;

		 string display = iminval.ToString();
		 display += " to ";
		 display += imaxval.ToString();
		 display += " are the min/max integer values.";

		 Console.WriteLine( display );
		 NumberStyles ns = NumberStyles.AllowLeadingWhite;
		 ns |= NumberStyles.AllowCurrencySymbol;
		 ns |= NumberStyles.AllowThousands;
		 ns |= NumberStyles.AllowDecimalPoint;

		 string bonus = "$  12,000.79";
			
		 double ibonus = double.Parse( bonus, ns );
		 Console.WriteLine( "\nthe string {0} parsed as double: {1}",
			 bonus, ibonus ); 

		 // notice it rounds
		 int ival1 = Convert.ToInt32( ibonus );
		 int ival2 = (int) ibonus; 

		 Console.WriteLine( "\n{0} to int \n\tby conversion: {1} \n\tby cast: {2}",
			 ibonus, ival1, ival2 );

		 Console.WriteLine( "Type a number, please." );
		 string text = Console.ReadLine();
		 Console.WriteLine( text );
		 int ival = Convert.ToInt32( text ) * 2;
		 Console.WriteLine( "double value: " + ival.ToString() );
          
	 }

	 public static void ToString( object o )
	 { 
		 Type t = o.GetType();
		 Console.WriteLine( "object: {0} � type name: {1}",
			 o.ToString(), t.Name ); 
	 }

	 static private void display2DimArray( float [,] mat )
	 {
		 int [] dimensions = new int[ mat.Rank ];

		 for ( int lo = 0, hi = mat.Rank; lo < hi; ++lo )
			   dimensions[ lo ] = mat.GetLength( lo );
		
		 Console.WriteLine( "Total Length of array: {0}", mat.Length ); 
		 Console.WriteLine( "Array is {0} dimension(s)", mat.Rank );

		 Console.Write( "Array lengths are { " );
		 foreach ( int ilen in dimensions )
			 Console.Write( "{0} ", ilen );
		 Console.WriteLine( "}" );

		 Console.Write( "\t{ " );
		 int rank =  mat.Rank;
		 int length = dimensions[ rank - 1 ];
		 int i = 0;
		 
		 foreach ( float val in mat )
		 { 
			 if (( i++ % length ) == 0 ) 
			     { Console.WriteLine(); Console.Write( "\t" ); }

			 Console.Write( "{0} ", val );
		 }
		 Console.WriteLine( "\n\t}" );
	 }

	 static public void testArray()
	 { 
		float [,] mat = new float[4,5]
		{
			{ 1f, 0f, 0f, 0f, 0f },
			{ 0f, 1f, 0f, 0f, 0f },
			{ 0f, 0f, 1f, 0f, 0f },
			{ 0f, 0f, 0f, 1f, 0f }
		};
	 
	    display2DimArray( mat );

		// illustration of initializing a 3-dimensional array
		float [,,] mat2 = new float[4,2,3]
		{
			{ 
				{ 1f, 0f, 0f },
				{ 0f, 0f, 1f }
			},
			{ 
				{ 1f, 0f, 0f },
				{ 0f, 0f, 1f }
			},
			{ 
				{ 1f, 0f, 0f },
				{ 0f, 0f, 1f }
			},
			{ 
				{ 1f, 0f, 0f },
				{ 0f, 0f, 1f }
			}
		};
    }

    public static void testObject()
	{
		int ival = 10;
		JulianCalendar jc = new JulianCalendar();
		string str = "hello, world";

		ToString( ival );
		ToString( jc );
		ToString( str );
		ToString( 1024 );
		ToString( new int[5] );
		ToString( false );
	 }

	 
	 enum days_of_week 
	 { sunday, monday, tuesday, wednesday, thursday, friday, saturday, sentinel = 7 };

	 static public void testEnum()
	 {
		 char m_ch = (char)95;
		 for ( int ix = 0, xi = 10; ix != xi; ++ix, --xi ) ;

		 days_of_week dw = days_of_week.sunday;
		 for ( ; ; )
		 {
			 Console.WriteLine( dw.ToString() );
			 if ( ++dw == days_of_week.sentinel )
			 {
				 Console.WriteLine( "found sentinel: terminating loop" );
				 break;
			 }
		 }

		 int [] ia = new int[8]; 
		 ia[ 0 ] = ia[ 1 ] = 1;

		 Console.Write( "1 1 " );
		 for ( int ix = 2; ix < ia.Length; ++ix )
		 {	  
			 ia[ ix ] = ia[ ix-2 ] + ia[ ix-1 ];
			 Console.Write( "{0} ", ia[ ix ] );
		 }

		 Console.WriteLine();
	 }

	 public static void Main()
     {
			testMisc();
		    testObject();
		    testArray();
		    testEnum();
    }
}
