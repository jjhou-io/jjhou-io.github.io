using System;
using System.Collections;
using System.IO;

public class TestArray
{
	private static string [] test_array = 
	{
		"Master Timothy Gnome left home one morning",
		"gripping a short shovel in his small, chubby fist",
		"made of sparkling gold and a carved ivory handle",
		"in which a tree with white popcorn blossoms grew.",

		"Around his waist loosely knotted in a bow-tie that hung",
		"like the floppy ears of a dog, he wore a quilted orange",
		"and brown apron with his name, Timothy, stitched on it",
		"in bold red letters, and on which a sturdy brown tree",
		"with white popcorn blossoms grew.",

		"He wore his whirring spin cap stitched together from the",
		"wrinkled lime-tinted skin of dragon lizards, its propeller",
		"made of milk-moon silver fairy wings gotten through trade",
		"for the white popcorn blossoms of the brown sturdy Gnome tree."
	};

	public static void test_methods()
	{
		Array.Reverse( test_array );
		display( "reversed: ", test_array );
		Array.Sort( test_array );
		display( "sorted: ", test_array );
	}

	public static void display( string message, object [] oa )
	{
		Console.WriteLine( "{0} :: {1} elements.", message, oa.Length );
		foreach ( object o in oa )
			Console.WriteLine( "\t{0}", o.ToString() );
	}

	public static void display( string message, int [] ia )
	{
		Console.WriteLine( "{0} :: {1} elements.", message, ia.Length );
		foreach ( int val in ia )
			Console.WriteLine( "\t{0}", val );
	}

	public static void search_withArray()
	{
		int [] ivalues = new int[]{ 14, 8, 2, 16, 8, 7, 14, 0 };

		int search_value = 8;
		int index = -1, cnt = 0;
		int [] found = new int[ ivalues.Length ];

		while( true )
		{
			index = Array.IndexOf( ivalues, search_value, index+1 );
			if ( index == -1 )
				 break;
			found[ cnt++ ] = index;
		}

		Console.Write( "{0} occurrences of {1} found at ", cnt, search_value );
		for( int ix = 0; ix < cnt; ix++  )
		          Console.Write( "{0} ", found[ ix ] );
		Console.WriteLine();
	}

	public static void search()
	{
		string [] shake = { 
			"O, beware, my lord, of jealousy",
			"It is the green-eyed monster, which doth mock",
			"The meat it feeds on." 
		};

		ArrayList speare = new ArrayList( shake ); 

		Console.WriteLine( "capacity: {0} :: count: {1}", speare.Capacity, speare.Count );
		// speare.Add( "Out, out, brief candle" );
		speare.Insert( speare.Count, "Out, out, brief candle" );
		Console.WriteLine( "capacity: {0} :: count: {1}", speare.Capacity, speare.Count );

		foreach ( string s in speare )
			Console.Write( "{0} ", s );
		Console.WriteLine();

		string [] shake_too = {
			@"Life's but a walking shadow; a poor player,",
			"That struts and frets his hour upon the stage",
			"And then is heard no more: it is a tale",
			"Told by an idiot, full of sound and fury,"  
		};

		speare.AddRange( shake_too ); 
		Console.WriteLine( "capacity: {0} :: count: {1}", speare.Capacity, speare.Count );

		speare.Clear(); 
		Console.WriteLine( "capacity: {0} :: count: {1}", speare.Capacity, speare.Count );

		int [] ivalues = new int[]{ 14, 8, 2, 16, 8, 7, 14, 0 };

		int search_value = 8;
		int index = -1, cnt = 0;
		ArrayList found = new ArrayList( ivalues.Length );

		while( true )
		{
			index = Array.IndexOf( ivalues, search_value, index+1 );
			if ( index == -1 )
				 break;
			found.Add( index );
		}

		Console.Write( "{0} occurrences of {1} found at ", found.Count, search_value );
		foreach ( int ix in found )
		          Console.Write( "{0} ",  ix );
		Console.WriteLine();
	}

	static float [,] mat_identity = new float[4,5]
	{
		 { 1f, 0f, 0f, 0f, 0f },
		 { 0f, 1f, 0f, 0f, 0f },
         { 0f, 0f, 1f, 0f, 0f },
         { 0f, 0f, 0f, 1f, 0f }
    };

	static float [,] mat_zero = new float[ 4,5 ];

	static public void display_mat()
	{
		int rank = mat_identity.Rank;
		Console.WriteLine( "Array of {0} dimensions", rank );

		int dim = 1,  ix ;
		for ( ix = 0; ix < rank; ++ix )
		{
			dim = mat_identity.GetLength(ix);
		    Console.WriteLine( "size of dimension {0} is {1} elements", ix, dim );
		}

	    ix = 0;
		foreach ( float f in mat_identity )
		{
			if ( ( ix++ % dim ) == 0 )
				   Console.WriteLine();

			Console.Write( "{0:f} ", f );
		}

		Console.WriteLine();

		ix = 0;
		foreach ( float f in mat_zero )
		{
			if ( ( ix++ % dim ) == 0 )
				   Console.WriteLine();

			Console.Write( "{0:f} ", f );
		}
		Console.WriteLine();
	}

	public static void test_copy()
	{
		int [] ia = new int[]{1,1,2,3,5,8};
		int [] ia2 = new int[6];
		ia.CopyTo(ia2,0);
		foreach ( int ix in ia2 )
		    Console.Write( "{0} ", ix );
	}

    public static void Main()
    {
		test_copy();
		test_sort();
		test_methods();
		display_mat();
		search();
	}

	public static void test_sort()
	{
		
		string[] sa = new string[ 5 ]  
		{ 
		  "OpenGL Programming",
		  "Advanced Renderman",
		  "Inside the C++ Object Model",
		  "Modern English Usage",
		  "Rilke: Selected Poems"
		};  

		int []   ia = new int[ 5 ] {  2, 1, 3, 5, 4 };

		display( "original string array: ", sa );
		Array.Sort( ia, sa );
		display( "key integer array: ", ia );
		display( "key sorted string array: ", sa );
		Array.Sort( sa );
		display( "ordinary string sort array: ", sa );
    }
}
