using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;

// provide state: allow multiple values and clear
public class Message
{
	static public void display( string msg1, string msg2, int val )
	{
		Console.WriteLine( "{0} : {1} : {2}", msg1, msg2, val );
	}

	static public void display( string msg, int val )
	{
		Console.WriteLine( "{0} : {1} ", msg, val );
	}

	static public void display( string msg, DateTime val )
	{
		Console.WriteLine( "{0} : {1} ", msg, val );
	}

	static public void display( string wherefrom, string msg )
	{
		Console.WriteLine( "{0} : {1}", wherefrom, msg );
	}

	static public void display( string msg )
	{
		Console.WriteLine( msg );
	}

	static public void indent_tab( int count )
	{
		while ( count-- > 0 )
			Console.Write( "\t" );
	}

	static public void newline()
	{
		Console.WriteLine();
	}
	
	static public void newline( int count )
	{
		while ( count-- > 0 )
			Console.WriteLine();
	}
}

public class Dir
{	
	public Dir()
	{ 
		m_path   = null; 
		m_dir    = null; 
		m_trace  = false; 
		m_action = null;
	}

	public Dir( string path )
	{ 
		m_path   = path; 
		m_dir    = new DirectoryInfo( path );
		m_trace  = false;
		m_action = null;
	}

	public delegate void Action();
	public Action action
	{
		set{ m_action = value; }
		get{ return m_action;  }
	}

	public bool trace
	{
		set{ m_trace = value; }
		get{ return m_trace;  }
	}

	public DirectoryInfo directory
	{
		set { m_dir = value; }
		get { return m_dir;  }
	}

	public string path
	{
		set { m_path = value; }
		get { return m_path;  }
	}

	private bool           m_trace;
	private string         m_path;
	private DirectoryInfo  m_dir;
	private Action         m_action;

	public void do_action()
	{
		if ( m_action != null )
			m_action();
	}

	// public actions
	public void list_subdirectories()
	{ list_subdirectories( m_path ); }

	public void list_files()
	{ list_files( m_path, 1 ); }

    public void recur_list_subdirectories()
	{
		string wherefrom = "Dir.recur_list_subdirectories()";
		if ( trace == true ) 
			 Message.display( wherefrom  );
		
		string [] sub_dir = Directory.GetDirectories( m_path );
		if ( sub_dir.Length == 0 )
			 return;

		Message.newline();
		Message.display( m_path, ": Recursive listing of all subdirectories" );
		Message.newline();

		foreach ( string dname in sub_dir )
		{
			string fullName = m_path + "/" + dname;
			list_files( fullName, 2 );
			recur_subdirectories( fullName, 2 );
		}
	}
	
	// private implementations of actions ...
	private void list_files( string path, int indent )
	{
		string wherefrom = "Dir.list_files()";
		if ( trace == true ) 
		     Message.display( wherefrom  );

		string [] cur_files = Directory.GetFiles( path );
		string    cur_dir   = m_dir.FullName;
		int       file_cnt  = cur_files.Length;

		Message.newline();
		Message.display( cur_dir, "# of files :", file_cnt );
		
		if ( file_cnt != 0 )
			 foreach ( string fname in cur_files )
			 {
				Message.indent_tab( indent ); Message.display( fname );
			 }
	}

	private void list_subdirectories( string path )
	{
		string wherefrom = "Dir.list_subdirectories()";
		if ( trace == true ) 
			 Message.display( wherefrom  );

		string [] sub_dirs = Directory.GetDirectories( path );
		string    cur_dir  = m_dir.FullName;
		int       dir_cnt  = sub_dirs.Length;

		Message.newline();
		Message.display( cur_dir, "# of subdirectories :", dir_cnt );

		if ( dir_cnt != 0 )
			 foreach ( string dname in sub_dirs )
			 {
				Message.indent_tab( 1 ); Message.display( dname );
			 }
	}

	private void recur_subdirectories( string path, int indent )
	{
		string wherefrom = "Dir.recur_subdirectories()";
		if ( trace == true ) 
			 Message.display( wherefrom, "indent: ", indent  );
		
		string [] sub_dir = Directory.GetDirectories( path );
		foreach ( string dname in sub_dir )
		{
			Message.indent_tab( indent ); Message.display( dname );
			recur_subdirectories( path + "\\" + dname, indent+1 );
		}

		list_files( path, indent+1 );
	}
}

public class DirTest
{
	public static void Main()
	{
		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

		test1();
		testDirProperties( thisDir );
		testFileMethods(thisDir + @"..\..\textfiles\word.txt" );
	}

	public static void testDirProperties( string workDir )
	{
		DirectoryInfo d = new DirectoryInfo( workDir );
		if ( d.Exists )
		{
			Message.display( "Directory full name ", d.FullName );

			d.Refresh();

			DateTime createTime = d.CreationTime;
			DateTime lastAccess = d.LastAccessTime;
			DateTime lastWrite  = d.LastWriteTime;

			Message.display( "Creation Time    ", createTime );
			Message.display( "Last Access Time ", lastAccess );
			Message.display( "Last Write Time  ", lastWrite );

			DirectoryInfo parent = d.Parent;
			DirectoryInfo root   = d.Root;

			Message.display( "Parent Directory ", parent.FullName );
			Message.display( "Root Directory   ", root.FullName );

			FileInfo [] has_files = d.GetFiles();
			DirectoryInfo [] has_directory = d.GetDirectories();

			Message.display( "Contains files ", has_files.Length );
			Message.display( "Contains dirctories ", has_directory.Length );
		}
		else Message.display( workDir, "Does not exist" );
	}

	public static void displayFileAttributes( FileInfo fd )
	{
		FileAttributes fs = fd.Attributes;
		Message.display( "\nFile Attributes", fd.Name );

		if (( fs & FileAttributes.Archive ) != 0 )
			 Message.display( "\tFile is Archived" );
		else Message.display( "\tFile is Not Archived" );

		if (( fs & FileAttributes.ReadOnly ) != 0 )
			 Message.display( "\tFile is Read Only" );
		else Message.display( "\tFile is Not Read Only" );

		Message.newline();
	}

	public static void testFileProperties( string workFile )
	{
		FileInfo fd = new FileInfo( workFile );
		if ( fd.Exists )
		{
			Message.display( "File full name ", fd.FullName );

			fd.Refresh();

			displayFileAttributes( fd );


			DateTime createTime = fd.CreationTime;
			DateTime lastAccess = fd.LastAccessTime;
			DateTime lastWrite  = fd.LastWriteTime;

			Message.display( "Creation Time       ", createTime );
			Message.display( "Last Access Time    ", lastAccess );
			Message.display( "Last Write Time     ", lastWrite );

			long fileLength = fd.Length;
			Message.display( "File Size in Bytes  ", (int)fileLength );

			Message.newline();
		}
		else Message.display( workFile, "Does not exist" );
	}

	public static void testFileMethods( string workFile )
	{
		FileInfo fd;
		if ( ! File.Exists( workFile ))
			 return;
		else fd = new FileInfo( workFile );
		testFileProperties( workFile ); 

		string pathname = Path.GetDirectoryName( fd.FullName );
		string filename = Path.GetFileName( fd.FullName );

		Message.display( "pathname", pathname );
		Message.display( "filename", filename );

		string newfilename = pathname + @"\Copy" + filename;
		FileInfo fd2 = fd.CopyTo( newfilename );

		fd2.Attributes -= FileAttributes.ReadOnly;
		Message.newline();
		testFileProperties( newfilename ); 
		fd2.Delete();

		Message.display( "Deleted", newfilename );
		testFileProperties( newfilename );
	}

	
	public static void test1()
	{
		string wherefrom = "DirTest.Main()";
		Message.display( wherefrom, "Beginning Test of Dir Class" );
		Message.newline(1);

		string [] logical_drives = Directory.GetLogicalDrives();
		if ( logical_drives.Length == 0 )
		{
			Message.display( "There are no logical drives on your machine!" );
			return;
		}

		try 
		{
			Dir d = new Dir();
			d.action += new Dir.Action( d.list_files );
			d.action += new Dir.Action( d.list_subdirectories );

			foreach ( string dir in logical_drives )
			{
				Message.newline( 1 );
				try {
					d.path = dir;
				    d.directory = new DirectoryInfo( d.path );
					if ( d.directory.Exists == false ){
						Message.display( dir, ": is unavailable -- skipping." );
					    continue;
					}
				}
				catch ( Exception )
				{
					Console.WriteLine( "Unable to open {0}", dir );
					continue;
				}

				d.do_action(); // d.list_files();
			}
		}
		catch ( IOException )
		{
			Console.WriteLine( "oops, unable to open directory" );
			return;
		}
	}
}