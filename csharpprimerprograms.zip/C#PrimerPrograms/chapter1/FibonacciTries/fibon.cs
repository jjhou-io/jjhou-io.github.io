
using System;

// for a `better' Fibonacci implementation, see Chapter 4
 class Fibonacci
{
	const int max_pos = 128;
	const string what_am_i = "Fibonacci Series";
	static readonly object nil = new Fibonacci();

    static private bool m_check = false;
	static public  bool CheckCalcs { set{m_check = value;} get{ return m_check;}}

	private const int x = y + z/2;
	private const int y = z*2;
	private const int z = 4;

	private static decimal [] elems; 
	private decimal [] m_elems ;

	public decimal this[ int index ]
	{
		get{ return m_elems[ index ]; }
		set{ m_elems[ index ] = value; }
	}

	public int Length() { return max_pos; }

	static Fibonacci()
	{ 
		// Console.WriteLine( " static Fibonacci constructor!" );
		
		elems = new decimal[ max_pos ];
		elems[ 0 ] = elems[ 1 ] = 1;
    	
    	for ( int ix = 2; ix < max_pos; ++ix ) 
				elems[ ix ] = elems[ ix-2 ] + elems[ ix-1 ];
	}

	public Fibonacci()
	{
		m_elems = new decimal[ max_pos ];
	}

	static public void display()
	{
		Console.WriteLine( "{0} Fibonacci Elements", max_pos );
		foreach ( decimal el in elems )
		{
			if ( el == 0 ) break;
			Console.WriteLine( "{0} ", el );
		}
	}

	static public
	int version_one( int pos )
	{
    		if ( pos == 1 || pos == 2 )
         	     return 1;

    		int elem = 0; 
    		int n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) {
			    
		 	    if ( CheckCalcs == true )
				   {{ checked { elem = n_2 + n_1 ; n_2 = n_1; n_1 = elem; }}}
				else { elem = n_2 + n_1 ; n_2 = n_1; n_1 = elem; }
    		}  
	
    		return elem;
    }

	static public
	bool version_handleOverflow( int pos, out int elem )
	{
    		if ( pos == 1 || pos == 2 ){ elem = 1; return true; }

    		elem = 0; 
    		int n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) 
				try {
				    { checked { elem = n_2 + n_1 ; n_2 = n_1; n_1 = elem; }}
				}
				catch ( Exception ex )
					  { return false; } 
	
    		return true;
    }

	static public 
	uint version_uint( int pos )
	{
    		if ( pos == 1 || pos == 2 )
         	     return 1;

    		// still here, need to calculate the element 
    		uint elem = 0; // holds return value
    		uint n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) 
    		{
				// Console.Write( "{0}, ", elem );
		 		elem = n_2 + n_1;
		 		n_2 = n_1; n_1 = elem;
    		}  
	
    		return elem;
      }

	static public 
	ulong version_ulong( int pos )
	{
    		if ( pos == 1 || pos == 2 )
         	     return 1;

    		// still here, need to calculate the element 
    		ulong elem = 0; // holds return value
    		ulong n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) 
    		{
				// Console.Write( "{0}, ", elem );
		 		elem = n_2 + n_1;
		 		n_2 = n_1; n_1 = elem;
    		}  
	
    		return elem;
      }

	static public 
	decimal version_decimal( int pos )
	{
    		if ( pos == 1 || pos == 2 )
         	     return 1;

    		// still here, need to calculate the element 
    		decimal elem = 0; // holds return value
    		decimal n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) 
    		{
				// Console.Write( "{0}, ", elem );
		 		elem = n_2 + n_1;
		 		n_2 = n_1; n_1 = elem;
    		}  
	
    		return elem;
      }

	static public 
	double version_double( int pos )
	{
    		if ( pos == 1 || pos == 2 )
         	     return 1;

    		// still here, need to calculate the element 
    		double elem = 0; // holds return value
    		double n_2 = 1, n_1 = 1;

    		for ( int ix = 3; ix <= pos; ++ix ) 
    		{
				// Console.Write( "{0}, ", elem );
		 		elem = n_2 + n_1;
		 		n_2 = n_1; n_1 = elem;
    		}  
	
    		return elem;
      }

	static public 
	decimal fibon_elem( int pos )
	{
		if ( pos <= 0 || pos > max_pos )
			throw new Exception( "Fibonacci: invalid position: " + pos );

		return elems[ pos-1 ];
    }
} 

