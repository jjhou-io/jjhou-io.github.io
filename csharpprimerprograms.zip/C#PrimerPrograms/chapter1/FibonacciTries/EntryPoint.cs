using System;

class MainObj
{
	static public void Main()
	{
		Fibonacci fib = new Fibonacci();
		testIndexer( fib, 14 );
		testchecked();
		testhandleOverflow();
	}

	static void testIndexer( Fibonacci f, int pos )
	{
		f[ 0 ] = f[ 1 ] = 1;
    	
		for ( int ix = 2; ix < pos; ++ix ) 
			f[ ix ] = f[ ix-2 ] + f[ ix-1 ];

		for ( int ix = 0; ix < pos; ++ix )
			  Console.Write( "{0}{1}", f[ ix ], 
				              ( ix != 0 ) && ( ix % 8 == 0 ) ? '\n' : ' ' );
		Console.WriteLine();
	}
			  

	static void test1()
	{
		unchecked 
		{
			byte b  = (byte) -1;
			byte b2 = (byte) 256;
			Console.WriteLine( "b: {0}, b2: {1}", b, b2 );
		}

		short pos = 8;
		try 
		{
		    
			Console.WriteLine( "Fibonacci Element #{0} : (int) : {1} ", pos, Fibonacci.version_one( pos ));
			Console.WriteLine( "Fibonacci Element #{0} : (uint) : {1} ", pos, Fibonacci.version_uint( pos ));
			Console.WriteLine( "Fibonacci Element #{0} : (ulong) : {1} ", pos, Fibonacci.version_ulong( pos ));
			Console.WriteLine( "Fibonacci Element #{0} : (decimal) : {1} ", pos, Fibonacci.version_decimal( pos ));
			Console.WriteLine( "Fibonacci Element #{0} : (double) : {1} ", pos, Fibonacci.version_double( pos ));
			

			Console.WriteLine( "Fibonacci Element #{0} : (int) : {1} ", pos, Fibonacci.fibon_elem( pos ));
			Fibonacci.display();
		}
		catch( Exception ex )
		{
			Console.WriteLine( ex );
		}
	}

	static void testchecked()
	{
		short pos = 135;
		try 
		{
			Console.WriteLine( "Unchecked Overflow Calculations\n\n" );
			Console.WriteLine( "unchecked: Fibonacci Element #{0} : (int) : {1} ", 
				pos, Fibonacci.version_one( pos ));
			
			Console.WriteLine( "unchecked: Fibonacci Element #{0} : (uint) : {1} ", 
				pos, Fibonacci.version_uint( pos ));

			Console.WriteLine( "unchecked: Fibonacci Element #{0} : (ulong) : {1} ", 
				pos, Fibonacci.version_ulong( pos ));

			Console.WriteLine( "unchecked: Fibonacci Element #{0} : (decimal) : {1} ", 
				pos, Fibonacci.version_decimal( pos ));

			Console.WriteLine( "unchecked: Fibonacci Element #{0} : (double) : {1} ", 
				pos, Fibonacci.version_double( pos ));
		
			Fibonacci.CheckCalcs = true;
			Console.WriteLine( "\nChecked: Same Overflow Calculation" );
			Console.WriteLine( "checked: Fibonacci Element #{0} : (int) : {1} ", 
				pos, Fibonacci.version_one( pos ));
		}
		catch( Exception ex )
		{
			Console.WriteLine( "\n!!! Exception Caught!\n\n{0}", ex );
		}
	}

	static void testhandleOverflow()
	{
		int [] position = { 1, 8, 12, 16, 20, 32, 64, 128, 256, 512, 1024 };
		int elem;
		bool ok;
		bool fail = false;
		foreach ( int pos in position )
		{
			ok = Fibonacci.version_handleOverflow( pos, out elem );
			if ( ok )
				Console.WriteLine( "Fibonacci Element #{0} : {1} ", pos, elem );
			else 
			{
				Console.WriteLine( "Fibonacci Element #{0} : sorry, unable to calculate ", pos );
				if ( fail == false )
					fail = true;
				else break;
			}
		}
	}
}
