using System;
using System.Collections;
using System.Windows.Forms;
using System.IO;

public class EntryPoint
{
	public static void simpleTests()
	{
		string s1 = "Pooh";
		Console.WriteLine( "s1 after initialization: {0}", s1 );
		s1.ToUpper(); // new string object discarded
		Console.WriteLine( "s1 after s1.ToUpper(): {0}", s1 );
		string s2 = s1.ToLower(); // "pooh"
		Console.WriteLine( "s2 = s1.ToLower(): s2: {0} s1: {1}", s2, s1 );

		char [] filter = { '.', ',', '\'', '\"', ';', ':' };
		string textline;
		while (( textline = Console.ReadLine() ) != null )
		{
			textline = textline.TrimEnd( filter );
			Console.WriteLine( "textline after trim: {0} ", textline );
		}
	}

	public static void Main()
	{
		StringTrial.testVerbatim();
        StringTrial.testStringLiteral();
		StringTrial st = new StringTrial();
		st.retrieve_text();
		st.testSplit();
		st.display_text( true );
		st.testTrimAndIndex();
		st.display_text( true );
		st.testComparesEquals();
	
		string line = "Master Timothy Gnome left home one morning";  
		string [] words = line.Split( null );
  		for ( int ix = 0; ix < words.Length; ++ix )
			  for ( int iy = ix; iy < words.Length; ++iy )
			  {
					string s = words[ ix ];
					string t = words[ iy ];

					if ( String.Equals( s,t )) 
						 continue;

					if ( s.CompareTo( t ) > 0 )
					{	 			   
						 string temp = words[ ix ];
						 words[ ix ] = words[ iy ];
						 words[ iy ] = temp;
					}
			  }

		Console.WriteLine( "original line: {0}", line );
		Console.Write( "sorted line (ignoring case): " );
		foreach ( string s in words )
				  Console.Write( "{0} ", s );
		Console.WriteLine();

		// string textline = Console.ReadLine();
		// if ( textline[ 0 ] == '.' ) // ok: read access
			 // textline[ 0 ] = '_'; // error: write access not supported

	}
}

public class StringTrial
{
	private ArrayList  m_text;
	private string[][] m_sentences;

	public void display_text( bool display_sentences )
	{
		Console.WriteLine( "string values read: {0}", m_text.Count );
		int index = 0;

		foreach ( string ss in m_text ) 
		{
			Console.WriteLine( "{0}:\t{1}", ss.Length, ss );
			if ( display_sentences )
			{
				 Console.WriteLine(); 
				 Console.WriteLine( "\tThere are {0} words in this line.", 
					                m_sentences[ index ].Length );
				 Console.Write( "\t" );
				 foreach ( string s in m_sentences[ index ])
					       Console.Write( "{0} ", s );			  
			}
			index++;
			Console.WriteLine( "\n" );
		}
		Console.WriteLine();
	}
        
	public void retrieve_text()
	{
		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );
		retrieve_text( thisDir + "gnome.txt" ); 
	}

    public void retrieve_text( string file_name )
	{
		string str;
		m_text = new ArrayList();

		FileStream   fin   = new FileStream( file_name, FileMode.Open );
		StreamReader ifile = new StreamReader( fin );

        while (( str = ifile.ReadLine()) != null )
			   { str = str.Trim(); if ( str != String.Empty ) m_text.Add( str );  }
    }

	public void testSplit()
	{
		m_sentences = new string[ m_text.Count ][];
		string str;

		for( int ix = 0; ix < m_text.Count; ++ix ){
			 str = ( string )m_text[ ix ];
			 m_sentences[ix] = str.Split( null );
		}
	}

	public void testTrimAndIndex()
	{
		char [] filter = new char[]{ '.', ',', '\'', '\"', ';', ':' };

		for( int ix = 0; ix < m_text.Count; ++ix ){
			 for ( int ij = 0; ij < m_sentences[ix].Length; ++ij )
				   // note: in an earlier release, IndexOf accepted the char[]
				   //       IndexOfAny was introduced in a later release ...
				   if ( m_sentences[ix][ij].IndexOfAny( filter ) >= 0 )
				        m_sentences[ix][ij] = m_sentences[ix][ij].TrimEnd( filter );
		}
	}

	public void testComparesEquals()
	{ 
		ArrayList m = new ArrayList();
		m.AddRange( m_sentences[ 0 ] );

		foreach ( string str in m ) Console.Write( "{0} ", str );
        Console.WriteLine();

		for ( int ix = 0; ix < m.Count; ++ix )
		{
			  for ( int iy = ix; iy < m.Count; ++iy )
			  {
				    string s = (string) m[ix];
				    string t = (string) m[iy];
				    
				    if ( String.Equals( s, t ))
						 continue;

				    Console.WriteLine( "Comparing {0} with {1}", s, t );

				    if ( s.CompareTo( t ) > 0 )
					{
						 Console.WriteLine( "swapping!" );
						 string temp = (string) m[ ix ];
						 m[ ix ] = m[ iy ];
						 m[ iy ] = temp;
						 foreach ( string str in m ) Console.Write( "{0} ", str );
						 Console.WriteLine();
					}
			  }
		}	
   
		foreach ( string str in m )Console.Write( "{0} ", str );
		Console.WriteLine();
	}
			
	static public void testVerbatim()
	{
		string VAliceEmma = @"
	Alice Emma has long flowing red hair. 

	Her Daddy says when the wind blows through her hair, 
		it looks almost alive, like a fiery bird in flight. 

	A beautiful fiery bird, he tells her, magical but untamed. 

	""Daddy, shush, there is no such creature,"" she tells him, 
		at the same time wanting him to tell her more.

	Shyly, she asks, ""I mean, Daddy, is there?""
	";

		Console.WriteLine( "\n\nAliceEmma verbatim:\n{0}", VAliceEmma );

		string RAliceEmma = "\nAlice Emma has long flowing red hair. \n\n"   + 
	           "Her Daddy says when the wind blows through her hair,\n"    + 
		       "\t it looks almost alive, like a fiery bird in flight. \n\n" +
			   "A beautiful fiery bird, he tells her, magical but untamed. \n\n" +
	           "\"Daddy, shush, there is no such creature,\" she tells him, \n" + 
		       "\t at the same time wanting him to tell her more.\n\n" +
			   "Shyly, she asks, \"I mean, Daddy, is there?\"";
	

	    Console.WriteLine( "\n\nAliceEmma regular:\n{0}", RAliceEmma );
	}	
	
	static public void testStringLiteral()
	{
		string s1 = "Pooh";
		Console.WriteLine( "s1: {0}", s1 );

		string s2 = s1.ToUpper();
		Console.WriteLine( "s1.ToUpper: {0}", s2 );

		string s3 = s1.ToLower();
		Console.WriteLine( "s1.ToLower: {0}", s3 );

		Console.WriteLine();
		for ( int ix = 0; ix < s1.Length; ++ix )
			  Console.Write( s1[ix] );
        Console.WriteLine();

		if ( s1 != String.Empty ) 
			 s2 = s1;

		if ( s1.Length != 0 )
			 s3 = s1;
						

		// C:\csharp\programs\strings\string.cs(130): 
		// foreach statement cannot operate on variables of type 'string' 
		// because 'string' does not contain a definition for 'GetEnumerator', 
		// or it is inaccessible
		// foreach ( char ch in s1 )
		//  	     Console.Write( ch );
		// Console.WriteLine();

		// string s2 = new string( "Pooh" );
		// s2 = String.Copy( "Pooh" );

		
		// s2[ 0 ] = 'p';
	}
}
