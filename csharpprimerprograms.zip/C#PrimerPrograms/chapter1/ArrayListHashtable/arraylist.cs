using System.Collections;
using System;

public class testArrayList
{
	static private ArrayList ms_alist;
	
	public void test()
	{
		string prefix = " OK: ArrayList tests ... ";
		string test1  = " test of basic functionality ... ";
		string test2  = " exercise of capacity ... ";

		Console.WriteLine( "{0} : {1}", prefix, test1 );
		testBasics();

		Console.WriteLine( "{0} : {1}", prefix, test2 );
		testCapacity();
	}

	static public void displayList()
	{
		Console.WriteLine();
		// foreach ( string str in ms_alist ) Console.WriteLine( str );

		for ( int ix = 0; ix < ms_alist.Count; ++ix )
			Console.WriteLine( ms_alist[ ix ] );

		Console.WriteLine();
	}

	static private void testTrim()
	{
		Console.WriteLine( "\nAbout to trim arraylist to size" );

		Console.WriteLine( "Before trim: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		ms_alist.TrimToSize();

		Console.WriteLine( "After trim: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "Now about to Add an element" );
		ms_alist.Add( 0 );

		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "OK: About to re-trim arraylist" );

		ms_alist.TrimToSize();

		Console.WriteLine( "After re-trim: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );
	}

	static private void removeElements( int count )
	{
		if ( count > ms_alist.Count || count < 1 )
			count = ms_alist.Count;

		Console.WriteLine( "\nAbout to remove {0} elements", count );

		Console.WriteLine( "Before removals: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		ms_alist.Remove( ms_alist[ --count ] );

		Console.WriteLine( "Remove a single object: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		ms_alist.RemoveAt( --count );

		Console.WriteLine( "RemoveAt a single index: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		ms_alist.RemoveRange( 0, count );

		Console.WriteLine( "RemoveRange: Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

	}

	static private void addElements()
	{
		int capacity = ms_alist.Capacity;

		for ( int ix = 0; ix < 10000; ++ix )
		{
			ms_alist.Add( ix );
			if ( ms_alist.Count > capacity )
			{
				capacity = ms_alist.Capacity;
				Console.WriteLine( "Count: {0} Capacity: {1}",
					ms_alist.Count, ms_alist.Capacity );
			}
		}
	}

	static public void testCapacity()
	{
		Console.WriteLine( "!! Begin: testArrayList.testCapacity()\n" );
		ms_alist = new ArrayList();

		Console.WriteLine( "Default capacity for empty ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		addElements();
		testTrim();
		removeElements( 100 );

		ms_alist.Clear();
		Console.WriteLine( "\nClear ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		addElements();

		const int fixedCapacity = 512;
		ms_alist = new ArrayList( fixedCapacity );

		Console.WriteLine( "\nExplicit capacity set for empty ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		addElements();

		Console.WriteLine( "\n!! End:   testArrayList.testCapacity()\n" );
	}

	static public void testBasics()
	{
		Console.WriteLine( "!! Begin: testArrayList.testBasics()\n" );

		string [] s = { 
						  "O, beware, my lord, of jealousy",
						  "It is the green-eyed monster, which doth mock",
						  "The meat it feeds on." };

		string [] t = {
						  @"Life's but a walking shadow; a poor player,",
						  "That struts and frets his hour upon the stage",
						  "And then is heard no more: it is a tale",
						  "Told by an idiot, full of sound and fury,"
					  };

		// initialize ArrayList from a built-in array
		ms_alist = new ArrayList( s ); displayList();

		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "adding one element: note capacity!" );
		ms_alist.Add( "Out, out, brief candle" );

		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );
		
		Console.WriteLine( "adding range of 4 elements: note capacity!" );
		ms_alist.AddRange( t ); 

		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );
		displayList();

		Console.WriteLine( "ArrayList.Reverse(): " );
		ms_alist.Reverse(); displayList();

		Console.WriteLine( "ArrayList.Sort(): " );
		ms_alist.Sort(); displayList();

		string st = t[ 1 ];
		if ( ms_alist.Contains( st ))
			Console.WriteLine( "found at index "  +
				ms_alist.IndexOf( st ).ToString() + 
				" : " + st );
		
		Console.WriteLine( "\nAbout to turn ArrayList into Array" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
			ms_alist.Count, ms_alist.Capacity );
		Array newArray = ms_alist.ToArray( st.GetType() );
		Console.WriteLine( "ToArray: {0} elements", newArray.Length );

		Console.WriteLine( "\nAbout to generate a fixed size ArrayList" );
		ms_alist.TrimToSize();
		ArrayList newList = ArrayList.FixedSize( ms_alist );
		Console.WriteLine( "Count: {0} Capacity: {1}",
			newList.Count, newList.Capacity );

		Console.WriteLine( "\n!! End:   testArrayList.testBasics()" );
	}
	
}
 