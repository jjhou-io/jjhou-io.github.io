using System.Collections;
using System;

public class testHashtable
{
	static private Hashtable ms_ahash;
	private static readonly string [] ms_words = s.Split( null );

	public void test()
	{
		string prefix = " OK: Hashtable tests ... ";
		string test1  = " test of basic functionality ... ";

		Console.WriteLine( "{0} : {1}", prefix, test1 );
		testBasics();
	}

	private const string s = @"MooCat is a long-haired white kitten with large black patches 
like a cow looks only he is a kitty poor kitty Alice says cradling MooCat in her arms 
pretending he is not struggling to break free MooCat is a present to Alice from her 
parents so that Alice does not feel so alone since their move here from New York City 
to Tucson only she does Aice Emma has long flowing red hair her father says when the 
wind blows through her hair it looks almost alive like a fiery bird in flight a beautiful 
fiery bird he tells her magical but untamed Daddy shush there is no such thing she tells 
him at the same time wanting him to tell her more shyly she asks I mean Daddy is there";

	private static void displayTableSort()
	{
		ArrayList aKeys = new ArrayList( ms_ahash.Keys );
		aKeys.Sort();
		foreach ( string key in aKeys )
			Console.WriteLine( "{0} :: {1}", key, ms_ahash[ key ] );
	}

	private static void displayTable()
	{
		Console.WriteLine( "Hashtable has {0} entries", ms_ahash.Count );
		IDictionaryEnumerator ie = ms_ahash.GetEnumerator();

		while ( ie.MoveNext() )
			Console.WriteLine( "{0} :: {1}", ie.Key, ie.Value );
	}

	static public void testBasics()
	{
		Console.WriteLine( "!! Begin: testHashtable.testBasics()\n" );

		Console.WriteLine( "word count: {0}", ms_words.Length );

		ms_ahash = new Hashtable();
		
		foreach( string s in ms_words )
		{
			if ( s == String.Empty )
				continue;

			if ( ms_ahash[ s ] == null )
				ms_ahash[ s ] = 1;
			else ms_ahash[ s ] = (int)ms_ahash[ s ] + 1; 
			/*
						if ( ! ms_ahash.Contains( s ))
							   ms_ahash[ s ] = 1; 
							// or:  ms_ahash.Add( s, 1 );
						else   ms_ahash[ s ] = (int)ms_ahash[ s ] + 1; 
			*/
			
		}
      
		Console.WriteLine( "Display key/value pair in hash order" );
		displayTable();

		Console.WriteLine( "Display key/value pair in key sorted order" );
		displayTableSort();

		Array tabl = Array.CreateInstance( typeof(object), ms_ahash.Count );
		ms_ahash.CopyTo( tabl, 0 );
		
		Console.WriteLine( "\n!! End:   testHashtable.testBasics()" );
	}
}