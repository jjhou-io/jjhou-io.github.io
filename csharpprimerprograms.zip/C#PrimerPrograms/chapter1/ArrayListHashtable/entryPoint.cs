using System;

class EntryPoint
{
	static public void Main()
	{
		string message = 
@" 
OK: ArrayList and Hashtable examples: 
    Enter 1 for examples of ArrayList use
          2 for examples of ArrayList capacity
          3 for examples of Hashtable use
             anything else to quit.";

		while ( true )
		{
			Console.WriteLine( message );
			Console.Write( "    ==> " );
			string response = Console.ReadLine();

			switch ( response )
			{
				case "1" :
					testArrayList.testBasics(); 
					break;

				case "2" :
					testArrayList.testCapacity(); 
					break;

				case "3" :
					testHashtable.testBasics(); 
					break;

				default:
					Console.WriteLine( "OK: you've chosen to quit the program. Bye" );
					return;
			}
		}
	}
}