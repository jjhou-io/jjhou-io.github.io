using System;
using System.IO;
using System.Windows.Forms;    // for Application class

public class gcDemo
    {
		static int ctor_cnt = 0;
		static int dtor_cnt = 0;
	    static gcDemo c1;
	    public static StreamWriter ofile;
	    static int iterations;

	    static public int Iterations { 
			set { iterations = value; }
			get { return iterations; }
		}

	    static gcDemo()
		{
			 string startupPath;
             startupPath = Application.StartupPath;
			 ofile = new StreamWriter( startupPath + @"\trace.txt" );
			 Console.WriteLine( "All trace output at " + startupPath + @"\trace.txt" );
             ofile.WriteLine("Startup Path is {0}", startupPath);
		}

        public gcDemo()
        {
            ofile.WriteLine( "gcDemo Class Constructor: {0}", ++ctor_cnt );
        }

		~gcDemo()
		{
			ofile.WriteLine( "gcDemo Class Destructor: {0}", ++dtor_cnt );
		}

		void test()
		{
			while (( c1 = new gcDemo() ) != null ) 
					 ;
		}

		static public void genObjs()
		{
			for ( int ix = 0; ix < gcDemo.Iterations; ++ix ) 
		          c1 = new gcDemo();

			Console.WriteLine( "There were {0} constructors invoked", ctor_cnt );
			Console.WriteLine( "There were {0} destructors invoked",  dtor_cnt );
		}

        public static int Main(string[] args)
        {
			gcDemo.Iterations = 100;
			gcDemo.genObjs();

			gcDemo.Iterations = 500;
			gcDemo.genObjs();

			gcDemo.Iterations = 1000;
			gcDemo.genObjs();

			gcDemo.Iterations = 1500;
			gcDemo.genObjs();

			gcDemo.Iterations = 10000;
			gcDemo.genObjs();

			gcDemo.Iterations = 20000;
			gcDemo.genObjs();

			gcDemo.Iterations = 35000;
			gcDemo.genObjs();

			gcDemo.Iterations = 50000;
			gcDemo.genObjs();

			gcDemo.Iterations = 100000;
			gcDemo.genObjs();

			gcDemo.Iterations = 500000;
			gcDemo.genObjs();

			gcDemo.Iterations = 1000000;
			gcDemo.genObjs();
			
			gcDemo.ofile.Close();
            return 0;
        }
    }
