using System;
using System.Text;
using System.Collections;

public sealed class BitVector : ICollection, IEnumerable, ICloneable
{
	private BitArray m_array;

	public BitVector( int size ): this( size, false ) {}
	public BitVector( int size, bool initValue )
	     { m_array = new BitArray( size, initValue ); 
	       Console.WriteLine( "BitArray: toString: " + m_array.ToString()); }

	override public string ToString()
	{
		StringBuilder sb = new StringBuilder( m_array.Count );
		for ( int ix = m_array.Count-1; ix >= 0; --ix )
			  sb.Append( m_array[ ix ] == true ? '1' : '0' );

		return sb.ToString();
	}

	public ulong ToUlong()
	{
		ulong bv = 0ul;
		for ( int ix = 0; ix < m_array.Count; ++ix )
		{
			if ( m_array[ix] ) 
			{
				 ulong bv2 = 1;
				 bv2 <<= ix;
				 bv += bv2;
			}
			Console.WriteLine( "{0} :: {1}", ix, bv );
		}
		return bv;
			  
	}

	public static implicit operator BitArray ( BitVector bv ){ return bv.m_array; }

	public bool this[ int ix ]
	{
		get{ return m_array[ ix ]; }
		set{ m_array[ ix ] = value;  }
	}

    // ICollection
	public int Count           { get { return m_array.Count;          }}
	public bool IsReadOnly     { get { return m_array.IsReadOnly;     }}
	public bool IsSynchronized { get { return m_array.IsSynchronized; }}
    public object SyncRoot     { get { return m_array.SyncRoot;       }}
	public void CopyTo( Array array, int index ) { m_array.CopyTo( array, index ); }

	// IEnumerable
	public IEnumerator GetEnumerator(){ return m_array.GetEnumerator(); }

	// ICloneable
	public object Clone(){ 
		BitVector bv = new BitVector( m_array.Count );
		bv.m_array = (BitArray)m_array.Clone();
		return bv;
	}
}

public class EntryPoint
{
	public static BitArray copyBitArray( BitArray bat )
	{
		BitArray lbat = new BitArray( bat.Count );
		for ( int ix = 0; ix < bat.Count; ++ix )
			  lbat.Set(ix, bat[ ix ] );

		bool b1 = lbat[ 0 ];
		bool b2 = lbat.Get( 0 );

		return lbat;	
	}

	public static void DisplayBitArray( BitArray ba )
	{
		foreach ( bool b in ba )
		Console.Write( " {0} ", b );
	}

	public static void DefaultCopy()
	{
		BitArray m_array = new BitArray( 10, false ); 
		m_array[ 2 ] = m_array[ 4 ] = true;
		DisplayBitArray( m_array );
		BitArray ma2 = m_array;
		m_array[ 1 ] = m_array[ 3 ] = true;
		Console.WriteLine( "\nOriginal BitArray" );
		DisplayBitArray( m_array );
		Console.WriteLine( "\nDefault Copied BitArray" );
		DisplayBitArray( ma2 );
	}

	public static void CloneCopy()
	{
		BitArray m_array = new BitArray( 10, false ); 
		m_array[ 2 ] = m_array[ 4 ] = true;
		DisplayBitArray( m_array );
		BitArray ma2 = (BitArray) m_array.Clone();
		m_array[ 1 ] = m_array[ 3 ] = true;
		Console.WriteLine( "\nOriginal BitArray" );
		DisplayBitArray( m_array );
		Console.WriteLine( "\nCloned BitArray" );
		DisplayBitArray( ma2 );
	}

	public static void Main()
	{
		BitVector bv = new BitVector( 24, false );
		for ( int ix = 0; ix < 10; ix++ )
			if (( ix %2 ) == 1 )
			{
				
			  bv[ ix ] = true;
			  Console.WriteLine( "{0} :: {1}", bv.ToString(), bv.ToUlong() );
			}
		Console.WriteLine( "bv: {0}", bv.ToString()); 

		// Console.WriteLine ("\n********\nCloneCopy: " );
		// CloneCopy();

		// Console.WriteLine ("\n********\nDefaultCopy: " );
		// DefaultCopy();
		// Console.WriteLine();
	}


		
}