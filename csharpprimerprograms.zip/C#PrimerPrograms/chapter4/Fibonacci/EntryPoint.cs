using System;
using System.Collections;

class EntryPoint
{
	public static void iterate( object o )
	{
		if ( o is IEnumerable )
		{
		    IEnumerable ie = (IEnumerable) o;
		    IEnumerator iter = ie.GetEnumerator();
			while ( iter.MoveNext() )
				Console.WriteLine( "{0} ", iter.Current.ToString() );
		}
	}

	public static void Main()
	{
		Fibonacci fib  = new Fibonacci();
	    const int pos1  = 8, pos2 = 47;
		decimal       elem = fib[ pos1 ];

		int length = fib.Length;

		Console.WriteLine( "The length of the INumericSequence is {0}", length );
		Console.WriteLine( "Element {0} of the Fibonacci Sequence is {1}", 
			                pos1, elem );

		fib.display();

		iterate( fib );

		NSEnumerator nse = (NSEnumerator) fib.GetEnumerator();
		while ( nse.MoveNext() != false )
		{
			 decimal el = nse.Current;
		}

		INumericSequence ins = fib;

		elem = ins[ pos2 ];
		length = ins.Length;

		Console.WriteLine( "The length of the INumericSequence is {0}", length );
		Console.WriteLine( "Element {1} of the Fibonacci Sequence is {0}", elem, pos2 );

		ins.display( 44, 47 );
	}
}


