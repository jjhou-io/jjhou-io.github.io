using System;
using System.Collections;

public interface INumericSequence : IEnumerable
{
		// a method
		bool generate_sequence( int position );

		// a set of overloaded methods
		void display();
		void display( int first );
		void display( int first, int last );

		// a property
		int Length { get; }
		
		// a one-dimensional indexer
		decimal this[ int position ]{ get; }
}

class NSEnumerator : IEnumerator
{
    decimal [] m_elems;
    int        m_count;
    int        m_curr;

    public NSEnumerator( decimal [] array, int count )
    {
        // these are exceptions defined within System
		if ( array == null )
		     throw new ArgumentNullException( "null array" );

        if ( count <= 0 )
             throw new ArgumentOutOfRangeException(
                                          count.ToString() );
                    
	  m_elems = array;
	  m_count = count;
	  m_curr  = -1; // required semantics!
    }

	private void checkIntegrity()
	{
		if ( m_curr == -1 || m_curr >= m_count )
			throw new 
				InvalidOperationException( ToString() );
	}

	public decimal Current
	     { get{ checkIntegrity(); return m_elems[ m_curr-1 ]; }}

	object IEnumerator.Current
	     { get{ checkIntegrity(); return m_elems[ m_curr-1 ]; }}

	public bool MoveNext()
	{ return m_count < ++m_curr;}

	public void Reset(){ m_curr = -1; }
}
