using System;
using System.Collections;

public sealed class Fibonacci : INumericSequence
{
	private static decimal  [] m_elements;
	private static short       m_count;
	private const  short       m_capacity = 128;

	static Fibonacci() 
	{
		m_elements = new decimal[ m_capacity ];
		m_elements[ 0 ] = m_elements[ 1 ] = 1;
		m_count = 2;
	}

	public IEnumerator GetEnumerator()
	     { return new NSEnumerator( m_elements, m_count ); }

	private bool check_pos( int pos )
	{
		if ( pos <= 0 )
			 return false;

		return true;
	}

	private bool check_pos( ref int pos )
	{
		if ( pos <= 0 )
		   { pos = 1; return true; }

		if ( pos >= m_capacity )
			 return false; 

		if ( m_count < pos )
			 return generate_sequence( pos );

		return true;
	}

	// a method
	public bool generate_sequence( int pos )
	{
		if ( ! check_pos( pos ))
			 return false;

		decimal n_2 = m_elements[ m_count - 2 ];
		decimal n_1 = m_elements[ m_count - 1 ]; 
		
    	for ( ; m_count < pos; ++m_count ) 
    		{
				m_elements[ m_count ] = n_2 + n_1;
				n_2 = n_1; n_1 = m_elements[ m_count ];
				// Console.WriteLine( "n: {0}, n_1: {1}, n_2: {2}", m_elements[ m_count ], n_1, n_2 );
    		} 
 
		return true;
	}

	public void  display()           
	           { display( 0, m_count );     }

	public void  display( int first )
	           { display( first, m_count ); }

	public void  display( int first, int last )
	{
		 if ( first > last )
			  return;

		 int start = first==0?1:first;
		 Console.WriteLine( "Elements {0} to {1} of the Fibonacci Sequence:", 
							 start, last );

		 Console.Write( "\t " );
		 for( int ix = start-1; ix < last; ++ix )
			  Console.Write( "{0} ", m_elements[ ix ] );

		 Console.WriteLine();
	}

	// off by 1 because of dummy first element ...
	public int Length { get{ return m_count; }}
		
	// a one-dimensional indexer
	public decimal this[ int position ]{ 
		   get{ 
			   check_pos( ref position ); 
			   return m_elements[ position-1 ]; 
		   }
	}
}