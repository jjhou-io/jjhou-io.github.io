using System;
using System.Collections;

public abstract class NumericSequence : INumericSequence
{ 
	// type-dependent method remains abstract
	public abstract bool generate_sequence( int pos );

	unsafe protected NumericSequence( decimal [] container, ref int count ) 
	{
		m_elements = container;
		fixed ( int *p = &count ) m_count = p;
	}

	unsafe public IEnumerator GetEnumerator()
	     { return new NSEnumerator( m_elements, *m_count ); }


	// concrete infrastructure of shared state
	private const int m_maxpos = 128;
	static public int MaxPosition { get{ return m_maxpos; }}
	
	unsafe public int Length { get { return *m_count; }}

	// a one-dimensional indexer
	public decimal this[ int position ]{ 
		   get{ 
			   // check_pos( position ); 
			   return m_elements[ position-1 ]; 
		   }
	}

	private decimal []  m_elements;
	private unsafe int* m_count;

	unsafe public void  display()           
	           { display( 0, *m_count );     }

	unsafe public void  display( int first )
	           { display( first, *m_count ); }

	public void  display( int first, int last )
	{
		 if ( first > last )
			  return;

		 int start = first==0?1:first;
		 Console.WriteLine( "Elements {0} to {1} of the {2} Sequence:", 
							 start, last, ToString() );

		 Console.Write( "\t " );
		 for( int ix = start-1; ix < last; ++ix )
			  Console.Write( "{0} ", m_elements[ ix ] );

		 Console.WriteLine();
	}
}

class Fibon : NumericSequence 
{
	static private decimal [] elem_container = new decimal[ 128 ];
	static private int elem_count;
 
	public override bool generate_sequence( int pos ) {return true;}

	static Fibon() 
	{
		elem_count = 2;
		elem_container[0] = elem_container[1] = 1;
	}



	public Fibon() : base( elem_container, ref elem_count ) {}
	
}