using System;
using System.Collections;
using System.Diagnostics;

public class BTree
{
	private Type      m_elemType;
	private BTreeNode m_root;
	private Action    m_nodeAction;

	public Action NodeAction
	{
		get{ return m_nodeAction;  }
		set{ m_nodeAction = value; }
	}

	public BTree( IEnumerator elems ) 
	{
		while ( elems.MoveNext() )
			insert( elems.Current );
	}

	public BTree(){}
	

	public BTreeNode  Root     { get{ return m_root; }}
	public Type       TreeType { get{ return m_elemType; }}

	public void debug_turnon() { if ( m_root != null ) m_root.debug_turnon();  }
	public void debug_turnoff(){ if ( m_root != null ) m_root.debug_turnoff(); }

	public bool empty()     { return m_root == null; }

	public void inorder()   { if ( NodeAction != null ) m_root.inorder( m_root, NodeAction );   }
	public void postorder() { if ( NodeAction != null ) m_root.postorder( m_root, NodeAction ); }
	public void preorder()  { if ( NodeAction != null ) m_root.preorder( m_root, NodeAction );  }

	public BTreeNode find( object elem )
	{
		if ( m_root == null )
			return null;

		confirm_type( elem );
		return m_root.find_value( elem );
	}

	private void confirm_type( object elem )
	{
		if ( elem.GetType().Equals( m_elemType ) != true )
		{
			string msg = "This binary tree instance handles elements of type " +
				m_elemType.Name + ".\n\tEither create a new tree of type " +
				elem.GetType().Name + " or explicitly convert " + elem.ToString();

			throw new Exception( msg );
		}
	}

	private IComparable confirm_comparable( object elem )
	{
		IComparable ic = elem as IComparable;
		if ( ic == null )
		{
			string msg = "BTree only supports types that implement IComparable \n\t:: " +
				elem.GetType().Name + " does not currently do so!";
			throw new Exception( msg );  
		}
		return ic;
	}

	public void insert( object elem )
	{
		if ( m_root == null )
		{
			confirm_comparable( elem );
			m_elemType = elem.GetType();
			m_root = new BTreeNode( elem );
		}
		else 
		{
			confirm_type( elem );
			m_root.insert_value( elem );
		}
	}

	public bool remove( object elem )
	{
		if ( m_root == null )
			return false;

		IComparable ic = confirm_comparable( elem );
		confirm_type( elem );
		
		if ( ic.CompareTo(  m_root.NodeValue ) == 0 ) 
			return remove_root();

		return m_root.remove_value( elem, ref m_root );
	}

	private bool remove_root()
	{
		BTreeNode tmp = m_root;

		if ( m_root.rchild != null )
		{
			m_root = m_root.rchild;
			BTreeNode lc    = tmp.lchild;
			BTreeNode newlc = m_root.lchild;

			// if left child of root is non-null
			// attach it as leaf to left subtree
			if ( lc != null )
				if ( newlc == null )
					m_root.lchild = lc;
				else BTreeNode.lchild_leaf( lc, newlc );
		}
		else m_root = m_root.lchild;
		return true;
	}

	// public void clear(){ clear( m_root ); m_root = null; }  // remove entire tree ...
}

