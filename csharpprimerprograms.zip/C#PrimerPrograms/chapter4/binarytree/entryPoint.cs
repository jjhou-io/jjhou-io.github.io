using System;
using System.Collections;

public class mainBTree 
{
	public static void test1()
	{
		BTree btree = new BTree();
		btree.insert( "Into" );
		btree.debug_turnon();
		btree.insert( "Into" );
	}

	public static void test2()
	{
		BTree bt = new BTree();
		bt.insert( "Piglet" );
		bt.insert( "Eeyore" );
		bt.insert( "Roo" );

		bt.insert( "Tigger" );
		bt.insert( "Chris" );
		bt.insert( "Pooh" );
		bt.insert( "Kanga" );

		bt.NodeAction = new Action( BTreeNode.PrintAction );

		Console.WriteLine( "preorder traversal" );
		bt.preorder();

		Console.WriteLine( "\ninorder traversal" );
		bt.inorder();

		Console.WriteLine( "\npostorder traversal" );
		bt.postorder();

		Console.WriteLine( "\nAbout to search for Tigger" );
		BTreeNode result = bt.find( "Tigger" );
		Console.WriteLine( "Tigger is {0}!", result == null ? "not found" : "found" );
	}

	public static void test3()
	{
		BTreeNode m = new BTreeNode( 10 );
		Console.WriteLine( "BTreeNode ToString(): {0}", m.ToString() );

		// the two BTreeNodes containing 10 are not equal!
		// the two BTreeNodes containing 10 are equal!

		BTreeNode n = new BTreeNode( 10 ); // default not equal
		if ( m == n ) 
			Console.WriteLine( "the two BTreeNodes containing 10 are equal!" );
		else Console.WriteLine( "the two BTreeNodes containing 10 are not equal!" );

		m = n; // default: now equal
		if ( m == n )
			Console.WriteLine( "the two BTreeNodes containing 10 are equal!" );
		else Console.WriteLine( "the two BTreeNodes containing 10 are not equal!" );

		m.debug_turnon();
		m.insert_value( 20 );
		m.insert_value( 10 );
		m.insert_value( 0 );

		try 
		{
			m.insert_value( "foo" );
		}
		catch ( Exception e )
		{ 
			Console.WriteLine( "Exception at insertion: {0}", e.ToString() );
		}
	}

	public static void test4()
	{
		BTree m = new BTree();
		m.debug_turnon();
		m.insert( 20 );
		m.insert( 0 );
		m.insert( 8 );
		m.insert( 30 );
		m.insert( 16 );
		m.insert( 4 );

		m.NodeAction = new Action( BTreeNode.PrintAction );

		Console.WriteLine( "original tree in preorder" );
		m.preorder();
		m.remove( 8 );

		Console.WriteLine( "\ntree in preorder with removal of element value 8" );
		m.preorder();

		m.remove( 20 );
		Console.WriteLine( "\ntree in preorder with removal of root element value 20" );
		m.preorder();
	}

	public static void test5()
	{
		byte b = 5;
		short s = 10;
		int i = 20;
		long l = 40;
		float f = 3.0f;
		double d = 4.7;

		BTree m = new BTree();
		try 
		{
			m.insert( b );
			// should fail here ...
			m.insert( s );
			m.insert( i );
			m.insert( l );
			m.insert( f );
			m.insert( d );
		}
		catch( Exception e )
		{
			Console.WriteLine( "Exception caught, as expected. Message:" );
			Console.WriteLine( e.Message );
			return;
		}

		m.NodeAction = new Action( BTreeNode.PrintAction );

		Console.WriteLine( "original tree in preorder" );
		m.preorder();
	}

	public static void test6()
	{
		BTree bt = new BTree();
		bt.insert( "pooh" );

		bt = new BTree();
		try
		{
			bt.insert( 10 );
			bt.insert( "pooh" );
		}
		catch( Exception e )
		{
			Console.WriteLine( "Exception caught, as expected. Message:" );
			Console.WriteLine( e.Message );
			return;
		}
	}

	public static void test7()
	{
		BTree bt = new BTree();
		bt.insert( 10 );

		BTree bt2 = new BTree();
		bt2.insert( 20 );

		BTree btree = new BTree();
		try
		{
			btree.insert( bt );
			btree.insert( bt2 );
		}
		catch( Exception e )
		{
			Console.WriteLine( "Exception caught, as expected. Message:" );
			Console.WriteLine( e.Message );
			return;
		}
	}

	public static void test8()
	{
		string [] words = 
		{
			"riverrun", "past", "Eve", "and", "Adams"
		};

		BTree btree      = new BTree( words.GetEnumerator() );
		btree.NodeAction = new Action( BTreeNode.PrintAction );

		Console.WriteLine( "initialized with collection" );
		btree.inorder();

	}

	public static void Main()
	{
		while ( true )
		{
			Console.WriteLine( "Enter test number, 1-8, or anything else to quit" );
			string entry = Console.ReadLine();
			switch( entry )
			{
				case "1": test1(); break;
				case "2": test2(); break;
				case "3": test3(); break;
				case "4": test4(); break;
				case "5": test5(); break;
				case "6": test6(); break;
				case "7": test7(); break;
				case "8": test8(); break;
				default: return;
			};
			Console.WriteLine( "\nOK: test {0} ran\n", entry );
		}
	}
}