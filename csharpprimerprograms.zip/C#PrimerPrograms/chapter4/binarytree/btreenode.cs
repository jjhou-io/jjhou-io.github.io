using System;
using System.Collections;
using System.Diagnostics;


public delegate void Action( ref BTreeNode node);

public sealed class BTreeNode 
{
	private int          m_occurs;
	private object       m_nval;
	private BTreeNode    m_lchild, m_rchild;
	static  private bool m_debug = true;

	static public void PrintAction( ref BTreeNode n )
	{
		Console.WriteLine( n.m_nval.ToString() );
	}

	public BTreeNode( object val ) 
	{ 
		m_nval   = val; 
		m_occurs = 1;
		m_lchild = null; 
		m_rchild = null; 
	}

	public object NodeValue { get{ return m_nval;  }    set{ m_nval = value; }}
	public int    Occurs    { get{ return m_occurs; }}

	public BTreeNode lchild { get{ return m_lchild; } set{ m_lchild = value; }}
	public BTreeNode rchild { get{ return m_rchild; } set{ m_rchild = value; }}

	public void debug_turnon() { m_debug = true; }
	public void debug_turnoff(){ m_debug = false; }

	public IComparable confirm_type( object elem )
	{
		if ( elem == null )
			return null;

		IComparable ic = elem as IComparable;
		if ( ic == null )
			throw new Exception( "Unable to handle objects: no IComparable interface" );  

		if ( elem.GetType().Equals( m_nval.GetType() ) != true )
		{
			string msg = "Unable to handle element: " + elem.ToString() +
				"\n\tbinary tree holds values of type " + m_nval.GetType().Name +
				"\n\tnot of type " + elem.GetType().Name;

			throw new Exception( msg );
		}

		return ic;
	}

	public override string ToString(){ return m_nval.ToString(); }
	public override bool Equals( object obj )
	{
		// if ( obj is BTreeNode )
		if ( obj == null )
			return false;

		BTreeNode bt = (BTreeNode) obj;
		if ( bt.m_nval.GetType().Equals( m_nval.GetType() ) != true )
			return false;

		return m_nval.Equals( bt.m_nval );
	}

	public static bool operator==( BTreeNode rhs, BTreeNode lhs )
	{ 
		if (( ((Object)rhs) == null ) && ( ((Object)lhs) == null ))
			return true;

		return rhs.Equals( lhs ); 
	}

	// requires != or won't compile
	public static bool operator!=( BTreeNode rhs, BTreeNode lhs )
	{ return ( rhs == lhs ) == false; }

	public static void lchild_leaf( BTreeNode leaf, BTreeNode subtree ) 
	{
		if ( m_debug )
			Console.WriteLine( "BTreeNode.lchild_leaf " ); 

		while ( subtree.m_lchild != null )
		{
			if ( m_debug )
				Console.WriteLine( "BTreeNode.lchild_leaf -- subtree {0}, lchild: {1} ",
					subtree.m_nval.ToString(), subtree.m_lchild.m_nval.ToString()); 
			subtree = subtree.m_lchild;
		}
		subtree.m_lchild = leaf;         
	}

	public bool remove_value( object val, ref BTreeNode prev )
	{
		if ( m_debug )
			Console.WriteLine( "BTreeNode.remove_value: {0}", val ); 

		// presumption that BTree has confirmed this ...
		IComparable ic = val as IComparable;	 
		if ( ic.CompareTo( m_nval ) == 0 ) 
		{
			if ( m_rchild != null )
			{
				prev = m_rchild;
				if ( m_lchild != null )
					if ( prev.m_lchild == null )
						prev.m_lchild = m_lchild;
					else BTreeNode.lchild_leaf( m_lchild, prev.m_lchild );
			}
			else prev = m_lchild;
		}
			 
		if ( ic.CompareTo( m_nval ) < 0 )
		{
			if ( m_lchild == null )
				return false;
			return m_lchild.remove_value( val, ref m_lchild ); // hit with confirm_type. fix
		}
	
		if ( m_rchild == null )
			return false;

		return m_rchild.remove_value( val, ref m_rchild ); // hit with confirm_type. fix
	}

	public void insert_value( object val )
	{
		if ( m_debug )
			Console./*Debug.*/WriteLine( "BTreeNode.insert_value: {0}", val ); 

		// IComparable ic = confirm_type( val );
		// presumption that BTree has confirmed this ...
		IComparable ic = val as IComparable;	

		// if ( val == m_nval ) // oops ...
		if ( ic.CompareTo(  m_nval ) == 0 )
		{ 
			m_occurs++;
			if ( m_debug )
				Console.WriteLine( "BTreeNode.insert_value: Match, increment count: {0} ", m_occurs ); 
			return; 
		}
		else 
			if ( m_debug )
			Console.WriteLine( "BTreeNode.insert_value: no match {0} ", m_nval ); 

		if ( ic.CompareTo(  m_nval ) < 0 )
		{
			if ( m_lchild == null )
			{
				m_lchild = new BTreeNode( val );
				if ( m_debug )
					Console.WriteLine( "BTreeNode.insert_value at left child" );		 
			}
			else m_lchild.insert_value( val );
		}
		else 
		{
			if ( m_rchild == null )
			{
				m_rchild = new BTreeNode( val );
				if ( m_debug )
					Console.WriteLine( "ok: BTreeNode.insert_value at right child" );	 
			}
			else m_rchild.insert_value( val );
		}
	}

	public BTreeNode find_value( object val ) 
	{ 
		// IComparable ic = confirm_type( val );
		// presumption that BTree has confirmed this ...
		IComparable ic = val as IComparable;	
		 
		if ( ic.CompareTo(  m_nval ) == 0 ) 
			return this;
			 
		if ( ic.CompareTo(  m_nval ) < 0 )
		{
			if ( m_lchild == null )
				return null;
			return m_lchild.find_value( val ); // hit with confirm_type. fix
		}
	
		if ( m_rchild == null )
			return null;

		return m_rchild.find_value( val ); // hit with confirm_type. fix
	}

	public void preorder( BTreeNode node, Action todo ) 
	{
		if ( node == null ) return;

		// add and execute the delegates
		// Console.WriteLine( node.NodeValue.ToString() );
		todo( ref node );

		if ( node.m_lchild != null )
			preorder( node.m_lchild, todo );

		if ( node.m_rchild != null )
			preorder( node.m_rchild, todo  );
	}

	public void inorder( BTreeNode node, Action todo  ) 
	{
		if ( node == null ) return;

		if ( node.m_lchild != null )
			inorder( node.m_lchild, todo  );

		// add and execute the delegates
		// Console.WriteLine( node.NodeValue.ToString() );
		todo( ref node );

		if ( node.m_rchild != null )
			inorder( node.m_rchild, todo  );
	}

	public void postorder( BTreeNode node, Action todo ) 
	{
		if ( node == null ) return;

		if ( node.m_lchild != null )
			postorder( node.m_lchild, todo  );

		if ( node.m_rchild != null )
			postorder( node.m_rchild, todo  );
		
		// add and execute the delegates
		// Console.WriteLine( node.NodeValue.ToString() );
		todo( ref node );
	}
}

