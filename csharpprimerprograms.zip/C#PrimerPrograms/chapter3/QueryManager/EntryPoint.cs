using System;

public class EntryPoint
{
	public static void Main()
	{
		Console.WriteLine( "TextQuery: begin()" );
		
		TextManager tm = new TextManager();
		tm.main();
			
		Console.WriteLine( "TextQuery: end()" );
	}
}
