using System;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.IO;

abstract public class Query 
{
	protected static int    ms_lines_of_text;
	protected static int [] ms_workplace;

	protected StreamWriter m_outfile;
	protected byte         m_tabcnt;
	protected byte		   m_lparen;
	protected byte		   m_rparen;

	public static void init_workplace( int lines_of_text )
	{
		if ( lines_of_text > 0 )
		{
			 ms_lines_of_text = lines_of_text;
			 ms_workplace = new int[ lines_of_text + 1 ];
		}
	}

	public byte RParen {
		get{ return m_rparen;  }
		set{ m_rparen = value; }}

	public byte LParen {
		get{ return m_lparen;  }
		set{ m_lparen = value; }}

    // m_solutions is an ascending list of line numbers
	// in which the query node is true
	protected ArrayList m_solution;

	public ArrayList SolutionSet {
		get{ return m_solution;  }
		set{ m_solution = value; }}

	abstract public void eval();
	abstract public bool add_op( Query op );
	abstract public void print();

	protected Query( ArrayList locs ) { m_solution = locs; }
	protected Query() : this( null ) {}

    protected void print_lparen( short cnt ) 
	{
		while ( cnt-- != 0 )
			    Console.Write( '(' );

		Console.Write( ' ' );
	}

	protected void print_rparen( short cnt ) 
	{
		Console.Write( ' ' );
		while ( cnt-- != 0 )
			    Console.Write( ')' );
	}

	protected void gen_lparen( ref StringBuilder srep, short cnt ) 
	{
		while ( cnt-- != 0 )
			    srep.Append( '(' );

		srep.Append( ' ' );
	}

	protected void gen_rparen( ref StringBuilder srep, short cnt ) 
	{
		srep.Append( ' ' );
		while ( cnt-- != 0 )
			    srep.Append( ')' );
	}

	protected void display_partial_solution()
	{
		Console.Write( "\n\t" );
		print();
		int count = m_solution != null ? m_solution.Count : 0;
		if ( count != 0 )
		{
			Console.Write( "\n\t\t{0} line(s) match: [ ",  count );
			foreach ( int ix in m_solution ) Console.Write( "{0} ", ix );
			Console.WriteLine( "]" );
		}
		else Console.WriteLine( "\n\t\t0 line(s) match: [ ] "  );
	}
	
	[Conditional( "DEBUG_TRACE" )]
	public void display_solution_set( string whereFrom )
	{
		Console.WriteLine( "{0} solution set: {1}\n", 
			                whereFrom, m_solution.Count );

		foreach ( int ix in m_solution )
			      Console.Write( "{0} ", ix );
	}
}

class OrQuery : Query 
{
	private Query m_lop;
	private Query m_rop;

	public OrQuery( Query lop ) 
		 { m_lop =  lop; }
	
	override public void eval()
	{
		if ( m_lop == null || m_rop == null )
			 throw new Exception( "Internal Error: OrQuery missing an operand!" );

		m_lop.eval();
		m_rop.eval();

		OrSolutions();
		display_partial_solution();
	}

	override public bool add_op( Query op )
	{
		bool status = false;

		if ( m_lop == null )
		   { m_lop = op; status = true; }
		else
		if ( m_rop == null )
		   { m_rop = op; status = true; }

		return status;
	}

	override public void print()
	{
		if ( m_lparen != 0 )
			 print_lparen( m_lparen );

		m_lop.print();
		Console.Write( " || " );
		m_rop.print();

		if ( m_rparen != 0 )
		     print_rparen( m_rparen );
	}

	override public string ToString()
	{
		StringBuilder sb = new StringBuilder( 8 );

		if ( m_lparen != 0 )
			gen_lparen( ref sb, m_lparen );

		sb.Append( m_lop.ToString() );
		sb.Append( " || " );
		sb.Append( m_rop.ToString() );

		if ( m_rparen != 0 )
			gen_rparen( ref sb, m_rparen );

		return sb.ToString();
	}


	private void OrSolutions()
	{
		Array.Clear( ms_workplace, 0, ms_workplace.Length );

		if ( m_lop.SolutionSet != null ) foreach ( int ix in m_lop.SolutionSet ) ms_workplace[ ix ]++;
		if ( m_rop.SolutionSet != null ) foreach ( int ix in m_rop.SolutionSet ) ms_workplace[ ix ]++;

		m_solution = new ArrayList();
        for ( int ix = 1; ix < ms_workplace.Length; ++ix )
		      if ( ms_workplace[ ix ] != 0 )
				   m_solution.Add( ix );

		display_solution_set( "OrSolutions" );
	}
}

class AndQuery : Query 
{
	private Query m_lop;
	private Query m_rop;

	public AndQuery( Query lop ) 
		 { m_lop =  lop; }
	
	override public void eval()
	{
		if ( m_lop == null || m_rop == null )
			 throw new Exception( "Internal Error: AndQuery missing an operand!" );

		m_lop.eval();
		m_rop.eval();

		AndSolutions();
		display_partial_solution();
	}

	override public bool add_op( Query op )
	{
		bool status = false;

		if ( m_lop == null )
		   { m_lop = op; status = true; }
		else
		if ( m_rop == null )
		   { m_rop = op; status = true; }

		return status;
	}

	override public void print()
	{
		if ( m_lparen != 0 )
			 print_lparen( m_lparen );

		m_lop.print();
		Console.Write( " && " );
		m_rop.print();

		if ( m_rparen != 0 )
		     print_rparen( m_rparen );
	}

	private void AndSolutions()
	{
		Array.Clear( ms_workplace, 0, ms_workplace.Length );

		if ( m_lop.SolutionSet != null ) foreach ( int ix in m_lop.SolutionSet ) ms_workplace[ ix ]++;
		if ( m_rop.SolutionSet != null ) foreach ( int ix in m_rop.SolutionSet ) ms_workplace[ ix ]++;
		
		m_solution = new ArrayList();
        for ( int ix = 1; ix < ms_workplace.Length; ++ix )
		      if ( ms_workplace[ ix ] == 2 )
				   m_solution.Add( ix );

		display_solution_set( "AndSolutions" );
	}
}

class NameQuery : Query 
{
	private string m_name;
	
	public NameQuery( string name ) : this( name, null ){}
	public NameQuery( string name, ArrayList loc )
		: base( loc ){ m_name = name; }
	
	override public void eval(){ display_partial_solution(); }
    override public bool add_op( Query op ){ return true; }

	override public void print()
	{
		if ( m_lparen != 0 )
			 print_lparen( m_lparen );

		Console.Write( m_name + " " );
		
		if ( m_rparen != 0 )
		     print_rparen( m_rparen );
	}
}

class NotQuery : Query 
{
	private Query m_op;
	private static int ms_max_lines;

	public static int MaxLines {
		get { return ms_max_lines;  }
		set { ms_max_lines = value; }}
	
	override public void eval()
	{
		if ( m_op == null )
			 throw new Exception( "Internal Error: NotQuery missing its operand!" );

		m_op.eval();

		NotSolutions();
		display_partial_solution();
	}
	
    override public bool add_op( Query op )
	{
		bool status = false;

		if ( m_op == null )
		   { m_op = op; status = true; }

		return status;
	}

	override public void print()
	{
		Console.Write( " ! " );
		
		if ( m_lparen != 0 )
			 print_lparen( m_lparen );

		m_op.print();

		if ( m_rparen != 0 )
		     print_rparen( m_rparen );
	}

	private void NotSolutions()
	{
		Array.Clear( ms_workplace, 0, ms_workplace.Length );

		if ( m_op.SolutionSet != null ) foreach ( int ix in m_op.SolutionSet ) ms_workplace[ ix ]++;
		
		m_solution = new ArrayList();
        for ( int ix = 1; ix < ms_workplace.Length; ++ix )
		      if ( ms_workplace[ ix ] == 0 )
				   m_solution.Add( ix );

		display_solution_set( "NotSolutions" );
	}
}


	

	

	

