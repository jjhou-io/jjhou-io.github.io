using System;
using System.Collections;
using System.Text;

public class QueryManager 
{
	public QueryManager( ArrayList text, Hashtable words, Hashtable lines )
	{
		m_text = text;
		m_words = words;
		m_lines = lines;
		m_query_stack = new Stack(); 
		m_current_op  = new Stack();
		m_buffer = new StringBuilder();

		Query.init_workplace( text.Count );
	}

	// query operand and operator stacks for 
	// processing the user query
	private Stack         m_query_stack;
	private Stack         m_current_op;

	// the actual query string entered by user
    private string        m_query;

	// a buffer to build up name operands
    private StringBuilder m_buffer;

	// the actual Query hierarchy built up 
	private Query         m_parsed_query;

	// handle parentheses within the query
    private byte          m_paren;
    private byte          m_rparenOn;
    private byte          m_lparenOn;
 
	// the actual text stored by line
	private ArrayList     m_text;

	// the hash table of words and line occurrences
	// built up from the processing of the text file
	private Hashtable m_words;
	public  Hashtable WordDictionary {
		    get{ return m_words;  }
		    set{ m_words = value; }}

	private Hashtable m_lines;
	public  Hashtable LineDictionary {
		    get{ return m_lines;  }
		    set{ m_lines = value; }}

	
	public Query EvalQuery( string query )
	{
		// Console.WriteLine( "EvalQuery: {0}", query );
		m_query = query;

		if ( ! ParseQuery() )
		{
			Console.WriteLine( "Sorry, unable to evaluate the query: {0}", query );
			return null;
		}

		m_parsed_query.eval();
		return m_parsed_query;
	}

	private void handle_word()
	{
		if ( m_buffer.Length == 0 )
			 return;

		string name = m_buffer.ToString();
		// Console.WriteLine( "handle_buffer: {0}", name );

		NameQuery nq;
		if ( m_words == null || 
		     m_words.Contains( name ) == false )
		{
				// Console.WriteLine( "{0} not present", name );
				nq = new NameQuery( name );
		}
		else {
				ArrayList solution = (ArrayList)m_lines[ name ];
				nq = new NameQuery( name, solution );

				// Console.WriteLine( "ok: {0} present", name );
				// Console.Write( " at lines: " );
				// foreach ( int ln in solution )
				//		  Console.Write( " {0}", ln );
				// Console.WriteLine();
		}

		nq.RParen = m_rparenOn; m_rparenOn = 0;
		nq.LParen = m_lparenOn; m_lparenOn = 0;

		if ( m_current_op.Count <= m_paren )
		{
			// Console.WriteLine( "current operator stack size: {0}", m_current_op.Count );
			// Console.WriteLine( "is less than or equal paren: {0}", m_paren );
			// Console.WriteLine( "push {0} on query stack", name );
			m_query_stack.Push( nq );
		}
		else 
		{
			// Console.WriteLine( "current operator stack size: {0}", m_current_op.Count );
			// Console.WriteLine( "is greater than paren: {0}", m_paren );
			// Console.WriteLine( "pop current operator, add word, then push {0} on query stack", name );

			if ( m_current_op.Count == 0 )
				 throw new Exception( "Internal Error: Empty operator stack!" );

			Query op = (Query) m_current_op.Pop();
			op.add_op( nq );
			m_query_stack.Push( op );
		}
					
		m_buffer.Remove( 0, m_buffer.Length );
	}

	private bool ParseQuery()
	{
		if ( m_query == null )
			 return false;
		
        for ( int ix = 0; ix < m_query.Length; ++ix )
		{
			switch( m_query[ ix ] )
			{
				case '(' :
				    handle_word();
					++m_paren;
					++m_lparenOn;
					Console.WriteLine( "*** Found a left paren" );
					break;

				case ')':
				{
				    handle_word();
					--m_paren;
					++m_rparenOn;
				    
					Console.WriteLine( "*** Found a right paren -- count: {0}", m_paren );
					// Console.WriteLine( "Current op size: {0}", m_current_op.Count );

				    if ( m_paren < m_current_op.Count )
					{
						// Console.WriteLine( "ok: paren count less than current_op size" );
						// Console.WriteLine( "pop query stack, get current op" );
						// Console.WriteLine( "add query to current_op, push on query stack" );

						if ( m_query_stack.Count == 0 || m_current_op.Count == 0 )
						     throw new Exception( "Internal Error: Empty query or operator stack for closing right paren!" );

						Query operand = (Query) m_query_stack.Pop();
						Query op      = (Query) m_current_op.Pop();

						op.add_op( operand );
						m_query_stack.Push( op );
					}
					break;
				}

				case '!' :
				{
				    handle_word();
					// Console.WriteLine( "Found a Not(!) -- pushing into current_op stack" );

					NotQuery nq = new NotQuery();
				    nq.RParen = m_rparenOn; m_rparenOn = 0;
					nq.LParen = m_lparenOn; m_lparenOn = 0;

					m_current_op.Push( nq );

					break;
				}

				case '&' :
				{
				    handle_word();

					if ( m_query[ ++ix ] != '&' )
						 throw new Exception( "ill-formed And query: expecting (&) found: (" +
							                   m_query[ix] + ")" );

					// Console.WriteLine( "Found an And(&&) -- popping query stack" );
				    // Console.WriteLine( "adding operand, pushing on current_op stack" );
				    
					if ( m_query_stack.Count == 0 )
						 throw new Exception( "Internal Error: Empty query stack for binary && operator!" );

					Query     q = (Query) m_query_stack.Pop();
					AndQuery aq = new AndQuery( q );

				    aq.RParen = m_rparenOn; m_rparenOn = 0;
					aq.LParen = m_lparenOn; m_lparenOn = 0;

					m_current_op.Push( aq );

					break;
				}

				case '|' :
				{
				    handle_word();

					if ( m_query[ ++ix ] != '|' )
						 throw new Exception( "ill-formed Or query: expecting (|) found: (" +
							                   m_query[ix] + ")" );

					// Console.WriteLine( "Found an Or(||) -- popping query stack" );
				    // Console.WriteLine( "adding operand, pushing on current_op stack" );
				    
					if ( m_query_stack.Count == 0 )
						 throw new Exception( "Internal Error: Empty query stack for binary || operator!" );

					Query    q = (Query) m_query_stack.Pop();
					OrQuery oq = new OrQuery( q );

				    oq.RParen = m_rparenOn; m_rparenOn = 0;
					oq.LParen = m_lparenOn; m_lparenOn = 0;

					m_current_op.Push( oq );
					break;
				}

				case ' ':
					// Console.WriteLine( "Found a blank" );
				    handle_word();
					break;

				default:
					// Console.WriteLine( "Found a default char: {0}", m_query[ ix ] );
				    m_buffer.Append( m_query[ ix ] );
					break;
			}
		}

		handle_word();
        integrity_check();
		
		m_parsed_query = (Query) m_query_stack.Pop();
		m_parsed_query.RParen = m_rparenOn; m_rparenOn = 0;

		return true;
	}
	
	private void integrity_check()
	{
		if ( m_current_op.Count != 0 )
			 throw new Exception( "Internal Error: NonEmpty operator stack for at end of processing!" );

		if ( m_query_stack.Count != 1 )
			 throw new Exception( "Internal Error: Query stack should be at 1, not " +
				                   m_query_stack.Count.ToString() + "!" );
	}
}