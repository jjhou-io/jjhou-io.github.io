#define DEBUG

using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Collections;

public class TextManager
{
	public enum trace_modes { no_trace = 0, trace, debug, debug_verbose }

	private Hashtable        m_words           = new Hashtable();
	private Hashtable        m_lines           = new Hashtable();

	private ArrayList        m_text            = new ArrayList();
	private static ArrayList m_supported_files = new ArrayList();

	private trace_modes      m_trace           = trace_modes.debug;
	private ArrayList        m_times		   = new ArrayList();

	private string           m_text_file       = null;
    private StreamWriter     m_diag_file       = null;

	static private Hashtable ms_common_words;
	static private Hashtable ms_s_words;
	static private Hashtable ms_special_words;

	static TextManager()
	{
		init_supported_extensions();
		ms_common_words = new Hashtable();
		ms_s_words = new Hashtable();
		ms_special_words = new Hashtable();

		ms_common_words.Add( "I'm", 0 );  ms_common_words.Add( "It's", 0 ); 
		ms_common_words.Add( "I'll", 0 ); ms_common_words.Add( "I've", 0 );
		ms_common_words.Add( "the", 0 );  ms_common_words.Add( "and", 0  );  
		ms_common_words.Add( "but", 0 );  ms_common_words.Add( "that", 0 );
		ms_common_words.Add( "i'm", 0 );  ms_common_words.Add( "it's", 0 ); 
		ms_common_words.Add( "i'll", 0 ); ms_common_words.Add( "i've", 0 );

		ms_s_words.Add( "has", 0 );		  ms_s_words.Add( "yes", 0 );
		ms_s_words.Add( "was", 0 );       ms_s_words.Add( "mrs", 0 );
		ms_s_words.Add( "perhaps", 0 );	  ms_s_words.Add( "always", 0 );
		ms_s_words.Add( "james", 0 );     ms_s_words.Add( "thomas", 0 );
		ms_s_words.Add( "themselves", 0 ); 

		// to show another hashtable
		// although this rule seems constant
		ms_special_words.Add( "shelves", "shelf" ); 
		ms_special_words.Add( "halves",  "half" );
		ms_special_words.Add( "dwarves", "dwarf" );
	}

	static public void add_common_words( string word )
	{
		if ( ! ms_common_words.ContainsKey( word ))
			   ms_common_words.Add( word, 0 );
	}

	static public void add_common_words( string [] words )
	{
		foreach ( string word in words )
			 if ( ! ms_common_words.ContainsKey( word ))
			      ms_common_words.Add( word, 0 );
	}
	
	public TextManager()
	{
		FileStream fout = new FileStream( "out.txt", FileMode.Create );
	    m_diag_file = new StreamWriter( fout );
	}

	public trace_modes trace
	{
		get{ return m_trace; }
		set{ m_trace = value; }
	}
	
	public string text_file
	{
		get{ return m_text_file; }
		set{ m_text_file = value; }
	}

	private bool process_text()
	{
		// #if DEBUG_TEXT_HANDLING
#if DEBUG
		// text_file = @"c:\C#ProgramsRefine\QueryManager\alice_emma.txt";
		text_file = @"c:\C#ProgramsRefine\QueryManager\little_cloud.txt";
#else
		if ( request_text_file() == false )
			 return false;
#endif

		if ( read_text() == false )
			 return false;

		if ( trace != trace_modes.no_trace )
		     display_text();

		
		// separate_words();
		enter_words();

		if ( trace >= trace_modes.debug )
		{
			display_word_htable();
			display_lines_htable();
		}

		Console.WriteLine();
		foreach ( string s in m_times )
			Console.WriteLine( s );

		return true;
	}

	private void Close(){ m_diag_file.Close(); }

	public void main()
	{
		if ( process_text() )
		     query_text();

		Close();
	}

	private bool request_text_file()
	{
		bool       file_check = false;
		byte       tries = 0;
		const byte max_tries = 3;
		
		while (( tries++ < max_tries ) && 
			   ( file_check == false ))
		{
			Console.Write( "please enter path of file: " );
			text_file = Console.ReadLine();

			if ( text_file == String.Empty )
			{
				 Console.WriteLine( "Sorry, invalid entry: empty string. Please try again." );
				 continue;
			}

			file_check = File.Exists( text_file );
			if ( file_check == false )
			{
				 if ( Directory.Exists( text_file ))
					  return handle_directory();

				 Console.WriteLine( "Sorry, invalid file: {0}: does not exist!",
					                 text_file );
				 continue;
			}
			
			if ( Path.HasExtension( text_file ) == false )
			{
				 Console.WriteLine( "Sorry, require file with one of the following extensions: " );
				 foreach ( string ext in m_supported_files )
					 Console.Write( "{0} ", ext );
				 Console.WriteLine();
				 return false;
			}

			file_check = supported_extension( text_file );
		}

		if ( file_check == false )
			 Console.WriteLine( "Sorry, maximum tries exhausted -- bailing out!" );

		return file_check;
	}

	private bool handle_directory()
	{
		m_diag_file.WriteLine( "handle_directory begin()" );

		try {
			// if unable to open for any reason, throws exception
		    DirectoryInfo dir = new DirectoryInfo( text_file );

			ArrayList candidate_files = new ArrayList();
			FileInfo [] curr_files;

			foreach ( string ext in m_supported_files )
			{
				// Returns a file list from the current directory matching 
				// the given searchCriteria, such as "*.txt".
				curr_files = dir.GetFiles( "*" + ext );
				candidate_files.AddRange( curr_files );
				m_diag_file.WriteLine( "{0}: {1} :: found: {2}", 
					                    dir, ext, curr_files.Length );
			}

			DirectoryInfo [] directories = dir.GetDirectories();
			foreach ( DirectoryInfo d in directories ){
				foreach ( string ext in m_supported_files )
				{
				    curr_files = d.GetFiles( "*" + ext );
				    candidate_files.AddRange( curr_files );
				    m_diag_file.WriteLine( "{0}: {1} :: found: {2}", 
							                d.Name, ext, curr_files.Length );
				}
			}

			if ( candidate_files.Count == 0 ){
				 Console.WriteLine( "Sorry, no supported files found in that location" );
				 return false;
			}

			Console.Write( "The following {0} files were found.\n\n", 
				            candidate_files.Count );

			int select = 1;
			foreach ( FileInfo f in candidate_files ){
				Console.WriteLine( "{0} :: {1}", select++, f.FullName );
				Console.WriteLine( "\t Length: {0},\n\t last accessed: {1},\n\t last written:  {2}\n",
					               f.Length, f.LastAccessTime, f.LastWriteTime );
			}
			
			Console.Write( "\nPlease select one: " );
            string selection = Console.ReadLine();
			select = Convert.ToInt32( selection ) - 1;

			if ( select < candidate_files.Count )
				 text_file = ((FileInfo)candidate_files[ select ]).FullName;

			Console.WriteLine( "You selected: {0} {1}", selection, text_file );
			
			return true;
		}
		catch ( IOException )
		{
			Console.WriteLine( "Sorry, unable to open {0}", text_file );
			return false;
		}
	}

	static public void init_supported_extensions()
	{
		// add to this as appropriate ...
		m_supported_files.Add( ".txt" );
	}

	static public bool supported_extension( string file )
	{
		string ext = Path.GetExtension( file );
		bool   supported = m_supported_files.Contains( ext );

		if ( supported == false )
			 Console.WriteLine( "Sorry, the {0} file extension is not currently supported.",
			                    ext );

		return supported;
	}

	private bool read_text()
	{
		try {
			Console.WriteLine( "Reading file {0} -- please wait!", text_file );
			timer Counter = new timer();
			Counter.context = "\t Time to read text file ";
			Counter.start();

			StreamReader text = File.OpenText( text_file );
			string textline;

			while (( textline = text.ReadLine() ) != null ) 
			{
				// just a newline ...
				if ( textline == String.Empty )
					 continue;
				
				if ( trace >= trace_modes.debug )
				     m_diag_file.WriteLine( "line read: {0} -- Length: {1}", textline, textline.Length );

				m_text.Add( textline );
			}

			Counter.stop();
			m_times.Add( Counter.ToString() );

			Console.WriteLine( "Reading file {0} -- ok, done!", text_file );
			Console.WriteLine( "\nThe text file {0}\n\t contains {1} lines in {2} bytes.", 
			                     Path.GetFileName( text_file ), 
			                     m_text.Count, text.BaseStream.Length );

			return true;
		}

		catch ( FileNotFoundException )
		{ 
			Console.WriteLine( "Sorry, unable to open {0} -- bailing out!", text_file );
			return false; 
		}
	}

	private void separate_words()
	{
		Console.WriteLine( "Separating text into words -- please wait!" );
		timer Counter = new timer();
		Counter.context = "\t Time to separate words ";
		Counter.start();

		int line_cnt = 0;
	    foreach( string st in m_text )
		{
			if ( trace >= trace_modes.debug )
				 m_diag_file.WriteLine( "new line: {0}",  line_cnt+1 );
				              
			int pos = 0, prev_pos = 0;
			line_cnt++;

            // then show a collection of white space
			while (( pos = st.IndexOf( ' ', pos )) != -1 )
			{
				string new_string = retrieve_word( st, pos, prev_pos );
				enter_word_in_dictionary( new_string, line_cnt );
				prev_pos = ++pos;
			}

			if ( trace >= trace_modes.debug )
			{
				m_diag_file.WriteLine( "out of loop: last word?" );
                m_diag_file.WriteLine( "prev_pos:{0} -- length: {1}", 
				                    prev_pos, st.Length );
			}

			if ( prev_pos < st.Length )
			{
				string new_string = retrieve_word( st, st.Length, prev_pos );
				enter_word_in_dictionary( new_string, line_cnt );
			}
		}

		Counter.stop();
		m_times.Add( Counter.ToString() );

		Console.WriteLine( "separating text into words -- ok: done!" );
	}

	private void suffix_s( ref StringBuilder theWord )
	{
		m_diag_file.WriteLine( "suffix_s( {0} )", theWord );

		string word = theWord.ToString();

        if ( word.EndsWith( "ous" ) || word.EndsWith( "ss" )  || 
		     word.EndsWith( "is" )  || word.EndsWith( "ius" ))
			      return;

        if ( word.EndsWith( "ies" )){
             theWord.Replace( "ies", "y", theWord.Length-3, 3 );
			 m_diag_file.WriteLine( "Changing {0} to {1}", word, theWord );
             return;
        }
	
		if ( word.EndsWith( "sses" ) || word.EndsWith( "shes" )){
             theWord.Remove( theWord.Length-2, 2 );
			 m_diag_file.WriteLine( "Changing {0} to {1}", word, theWord );
             return;
        }

		if ( ms_s_words.ContainsKey( word ))
			 return;

		if ( ms_special_words.ContainsKey( word )){
			 theWord.Replace( word, (string) ms_special_words[ word ] );
			 m_diag_file.WriteLine( "Changing {0} to {1}", word, theWord );
			 return;
		}

		theWord.Remove( theWord.Length-1, 1 );
		m_diag_file.WriteLine( "suffix_s: Changing {0} to {1}", word, theWord );
    }

	private ArrayList filter_words( string st )
	{
		/// TODO: add some support for aggregating time spent in here
		/// 

		const int min_length = 3;
		m_diag_file.WriteLine( "filter_words - begin: {0}", st );

		// by default, separates with white space
		// string [] words = st.Split( null );

		// let's get rid of punctuation as well
		char [] separators = { ' ', '\n', '\t', '.', '\"', ';', ',', '?', '!',
		                       ')', '(', '<', '>', '[', ']' };

		string [] words = st.Split( separators );
		ArrayList new_words = new ArrayList();

	    for ( int ix = 0; ix < words.Length; ++ix ) 
		{
			if ( words[ ix ] == String.Empty || 
				 words[ ix ].Length < min_length ||
				 ms_common_words.ContainsKey( words[ ix ] ))
				    continue;

			if ( trace >= trace_modes.debug )
				  m_diag_file.WriteLine( "filter word: {0}",  words[ ix ] );

			StringBuilder word = new StringBuilder( words[ ix ].ToLower() );
			if ( word[ 0 ] == '-' )
			{
				m_diag_file.WriteLine( "found leading hyphen: {0}", word );
				word.Remove(0,1);
				m_diag_file.WriteLine( "found leading hyphen: {0}", word );
			}

			if ( word[ word.Length-2 ] == '\'' )
			{
				m_diag_file.WriteLine( "found next to last apostrophe: {0}", word );
				switch( word[ word.Length-1 ] )
				{
					
					case 's':
						word.Remove( word.Length-2, 2 );
					    if (( word.Length >= min_length ) &&
						    ( ! ms_common_words.ContainsKey( word )))
						      new_words.Add( word.ToString() );
						break;

					case 't':
						if ( word[ word.Length-3 ] == 'n' )
						{
							 word.Remove( word.Length-3, 3 );

							 if (( word.Length >= min_length ) && 
								 ( ! ms_common_words.ContainsKey( word )))
							       new_words.Add( word.ToString() );

							 // ok: remember on a single instance of word is created
							 if ( ! ms_common_words.ContainsKey( "not" ))
							      new_words.Add( "not" );
						}
						break;

					case 'd':
						// discarding: hmph ...
						break;

					default:
					    if ( ! ms_common_words.ContainsKey( word.ToString() ))
						     m_diag_file.WriteLine( "*** yo, not handled: {0}", word );
						break;
				}
							 
				m_diag_file.WriteLine( "found next to last apostrophe: {0}", word );
				continue;
			}

			switch( word[ word.Length-1 ] )
			{
				case 's':
					 suffix_s( ref word );
				     break;

				case 'd':
				     /// TODO: suffix_ed( ref word );
				case 'g':
					 /// TODO: suffix_ing( ref word );
				case 'n':
					 /// TODO: suffix_en( ref word );
					 /// 
					m_diag_file.WriteLine( "suffix: {0} -- not implemented yet!",
						          word[ word.Length-1 ] );
				    break;
			}

			if ( ! ms_common_words.ContainsKey( word.ToString() ))
			     new_words.Add( word.ToString() );

		}

		m_diag_file.Write( "filter_words - end: " );
		foreach ( string str in new_words )
			      m_diag_file.Write( "{0} ", str );
		m_diag_file.WriteLine();

		return new_words;
	}

	private void enter_words()
	{
		Console.WriteLine( "\nentering text into dictionary -- please wait!" );

		timer Counter = new timer();
		Counter.context = "\t Time to enter text into dictionary ";
		Counter.start();

		int line_cnt = 0;
	    foreach( string st in m_text )
		{
			if ( trace >= trace_modes.debug )
				 m_diag_file.WriteLine( "new line: {0}",  line_cnt+1 );
				              
			line_cnt++;
			ArrayList words = filter_words( st );
			
			foreach ( string word in words )
			{
				if ( word == String.Empty )
					 continue;

				if ( trace >= trace_modes.debug )
				     m_diag_file.WriteLine( "enter word: {0}", word );
				
				enter_word_in_dictionary( word, line_cnt );
			}
		}

		Counter.stop();
		m_times.Add( Counter.ToString() );

		Console.WriteLine( "entering text into dictionary -- ok: done!" );
	}

	private string retrieve_word( string str, int pos, int prev_pos )
	{
			int length = pos - prev_pos;

			if ( trace == trace_modes.debug_verbose )
			     m_diag_file.WriteLine( "prev_pos: {0} -- pos: {1} -- length: {2}", 
				                         prev_pos, pos, length );
			
			string new_string = str.Substring( prev_pos, length );

			if ( trace >= trace_modes.debug_verbose )
			     m_diag_file.WriteLine( "new_string: {0} -- length: {1}", 
				                         new_string, new_string.Length );

			return new_string;
	}

	public void display_word_htable()
	{
		m_diag_file.WriteLine( "Word and Occurrence Count in text: " );

		// until there is an Enumerator for the Dictionary
		foreach ( DictionaryEntry de in m_words )
			      m_diag_file.WriteLine( "word: {0} :: occurrences: {1}", de.Key, de.Value );
	}

	public void display_lines_htable()
	{
		m_diag_file.WriteLine( "Word and Line Occurrences in text: " );

		// until there is an Enumerator for the Dictionary
		foreach ( DictionaryEntry de in m_lines )
		{
			m_diag_file.Write( "\tword: {0} :: lines: ", de.Key  );
			ArrayList lc = (ArrayList)de.Value;
			foreach ( int line in lc )
				m_diag_file.Write( "{0} ", line );
			m_diag_file.WriteLine();
		}
	}

	private void enter_word_in_dictionary( string new_string, int line_cnt )
	{
		if ( new_string != String.Empty )
			if ( m_words.Contains( new_string ) == false )
			{
				if ( trace >= trace_modes.debug_verbose )
				     m_diag_file.WriteLine( "inserting {0} into hashtable", 
					                         new_string );

				m_words.Add( new_string, 1 );

				ArrayList lines = new ArrayList();
				lines.Add( line_cnt );
				m_lines.Add( new_string, lines );
			}
			else {
				int cnt = (int) m_words[ new_string ] + 1;
				ArrayList lines = (ArrayList) m_lines[ new_string ];
				if ( lines.Contains( line_cnt ) == false )
				     lines.Add( line_cnt );

				if ( trace >= trace_modes.debug_verbose )
				     m_diag_file.WriteLine( "incrementing {0} in hashtable to {1}", new_string, cnt );

				m_words[ new_string ] = cnt;
			}
	}

	private void query_text()
	{
		QueryManager qm = new QueryManager( m_text, m_words, m_lines );

		while ( true )
		{
			Console.WriteLine();
			Console.Write( @"Please enter a query or 'q' to Quit: " );
			string query = Console.ReadLine();

			if ( query.CompareTo( "q" ) == 0 ){
				 Console.WriteLine( "Ok, bye!" );
				 break;
			}

			Query result = qm.EvalQuery( query );
			display_text( result.SolutionSet );
		}
	}
	
	private void display_text( ArrayList solution )
	{
		if ( solution == null || solution.Count == 0 ){
			Console.WriteLine( "\nSorry, there are no matches for this query" );
			return;
		}

		Console.WriteLine();
		foreach ( int line in solution )
				  Console.WriteLine( "\t[{0}]: {1}", line, m_text[line-1] );

		Console.WriteLine();
	}

	private void display_text()
	{
		m_diag_file.WriteLine( "\nThe text {0}\n\t contains {1} lines.", 
			       Path.GetFileName( text_file ), m_text.Count );

		int line_cnt = 1;
		foreach( string st in m_text )
			     m_diag_file.WriteLine( "{0}: {1}", line_cnt++, st );
	}
}
