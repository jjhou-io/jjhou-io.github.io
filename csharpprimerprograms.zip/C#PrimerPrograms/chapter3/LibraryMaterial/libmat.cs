
using System;
using System.Diagnostics;
using System.Reflection;
using System.Globalization;


class testLibrary
{
	public delegate void Test();

	static private Test m_test; 
	static public Test test
	{
		set{ m_test = value; }
		get{ return m_test;  }
	}

	public static void init_test()
	{
		test += new  Test( test1 );
		test += new  Test( test2 );
	}

	public static void Main()
	{
		init_test();
		if ( test != null )
			test();
	}

	public static void display( LibMat m )
	{
		m.print();
		DateTime dt = m.loan_period;
		Console.WriteLine( "DueDate: {0}", dt.ToString());
		bool ok = m.renew( ref dt );
		Console.WriteLine( "Renewable: {0} :: DueDate: {1}", 
			ok, dt.ToString() );
	}

	public static void test1()
	{
		LibMat m;
		
		Console.WriteLine( "About to Create a Book object\n" );
		m = new Book( "The Castle", "Franz Kafka" );
		display( m );
	    
		Console.WriteLine();
		Console.WriteLine( "About to Create an AudioBook object\n" );
		m = new AudioBook( "Man Without Qualities", 
			"Robert Musil", "Dr. Kenneth Meyer" );
		display( m );
	}

	public static void test2()
	{
		LibMat [] m_array = new LibMat[ 5 ];
		m_array[0] = new Book( "Mason & Dixon", "Thomas Pynchon" );
		m_array[1] = new AudioBook( "Six Easy Pieces", 
			"Richard Feynman", "Jeffrey Greenberg" );

		foreach( LibMat m in m_array )
		{
			if ( m == null ) 
				continue;

			Type t = m.GetType();
			Console.WriteLine( "\nAbout to Print an Object of Type {0}",
				t.FullName );
			display( m );
		}
	}
}

abstract class LibMat 
{
	public struct location
	{
		public location( byte mc1, byte mc2, byte mc3, byte mc4 )
		{
			LibMat.wherefrom( 
				"location::location( " + mc1.ToString() + ", " + 
				mc2.ToString() + ", " + mc3.ToString() + ", " +
				mc4.ToString() + " )" );
				   
			m_cat1 = mc1; m_cat2 = mc2;
			m_cat3 = mc3; m_cat4 = mc4; 
		}

		private byte	m_cat1;
		private byte	m_cat2;
		private byte    m_cat3;
		private byte    m_cat4;

		public string loc_id
		{
			get
			{
				return 
					 m_cat1.ToString() + "." + m_cat2.ToString() + "." + 
					 m_cat3.ToString() + "." + m_cat4.ToString(); }
		}
	}

	private location m_loc;
	public string Location { get{ return m_loc.loc_id; }}

	public LibMat( byte mc1, byte mc2, byte mc3 )
	{
		wherefrom( "LibMat::LibMat( " + mc1.ToString() + ", " + 
			mc2.ToString() + ", " + mc3.ToString() + " )" );
				   
		m_loc = new location( mc1, mc2, mc3, unique_id );
	}

	public LibMat() : this( 0, 0, 0 )
	{ wherefrom( "LibMat::LibMat()" ); }

	[Conditional("DEBUG")]
	static public void wherefrom(  string where )
	{ Console.WriteLine( " *** :: {0}\n", where ); }

	public virtual void print() 
	{
		wherefrom( "LibMat::print() -- I am now an abstract LibMat subobject" );
		Console.WriteLine( "Library material location: {0}", Location );
	}

	internal static byte unique_number = 1;
	internal byte unique_id
	{ get{ return unique_number++; }}

	private static double loan_period_default = 7.0;
	public virtual DateTime loan_period 
	{ 
		get 
		{ 
			DateTime dt = DateTime.Today;
			return dt.AddDays( loan_period_default ).AddHours(12); 
		}
	}

	protected abstract double renewal_period {  get; }
	public abstract bool renew( ref DateTime dt ); 
};

class Book : LibMat 
{
	private string m_title, m_author;
	public string title
	{ 
		get{ return m_title; }
		set{ m_title = value; }
	}

	public string author
	{ 
		get{ return m_author; }
		set{ m_author = value; }
	}

	public Book( string Title,  string Author )
		: base( 173, 255, 47 )
	{
		wherefrom( "Book::Book(" + Title + ", " + 
			Author + " )" );
				   
		title = Title; author = Author;
	}

	public override void print() 
	{
		wherefrom( "Book::print() -- I am now a Book object!" );
		base.print();
		Console.WriteLine( "The title is:  {0}", title );
		Console.WriteLine( "The author is: {0}", author );
		
	}

	public override DateTime loan_period 
	{ 
		get
		{ 
			DateTime dt = DateTime.Today;
			return dt.AddDays( 21.0 ).AddHours(12); 
		}
	}

	protected override double renewal_period 
	{  get{ return 21.0; }}

	public override bool renew( ref DateTime dt )
	{
		dt = dt.AddDays( renewal_period );
		return true; 
	} 
}

class AudioBook : Book 
{

	public AudioBook( string Title, 
		string Author, string Narrator )
		: base( Title, Author )
	{ 
		wherefrom( "AudioBook::AudioBook(" + Title + ", " + 
			Author + ", " + Narrator + " )" );

		narrator = Narrator; 
	}

	public override void print() 
	{
		wherefrom( "AudioBook::print() -- I am now an AudioBook object!" );
		base.print();
		Console.WriteLine( "The narrator is:  {0}", narrator );
	} 

	private string m_narrator;
	public string  narrator
	{ 
		get{ return m_narrator; }
		set{ m_narrator = value; }
	}

	public override DateTime loan_period 
	{ 
		get
		{ 
			DateTime dt = DateTime.Today;
			return dt.AddDays( 14.0 ).AddHours(12); 
		}
	}

	protected override double renewal_period 
	{  get{ return 7.0; }}

	public override bool renew( ref DateTime dt )
	{
		return false; 
	}

}