using System;
using System.IO;
using System.Threading;
using System.Collections;


class EntryPoint
{
	public static void Main() 
	{
		pingPong();
	}
	
	public static void pingPong()
	{
		PingPong p1 = new PingPong( "ping", 33 );
		Thread t1   = new Thread( new ThreadStart( p1.play ));

		Console.WriteLine( "OK: About to start ping thread" );
		t1.Start();

		while ( ! t1.IsAlive ) Console.Write( "." );
		Console.WriteLine( "OK: ping thread is now alive!" );

		Console.WriteLine( "OK: ping is now running in parallel" );
		Console.Write( "OK: " );
		for( int ix = 0; ix < 20; ++ix )
			 Console.Write( "{0} ", ix );
		Console.WriteLine();

		Console.WriteLine( "OK: Creating PONG object." );
		PingPong p2 = new PingPong( "PONG", 100 );

		Console.WriteLine( "OK: Creating PONG thread object." );
		Thread t2  = new Thread( new ThreadStart( p2.play ));

		Console.WriteLine( "OK: About to start PONG thread" );
		t2.Start();

		Console.WriteLine( "OK: ping and PONG are now running in parallel" );
		Console.Write( "OK: " );
		for( int ix = 0; ix < 20; ++ix )
			 Console.Write( "{0} ", ix );
		Console.WriteLine();

        // ok: let's rest this puppy for 600 milliseconds
		Console.WriteLine( "OK: About to sleep main thread for 600 milliseconds" );
		Thread.Sleep( 600 );

		Console.WriteLine( "OK: here after sleep." );
		Console.WriteLine( "OK: about to wait to join(400) ping" );

		// ok: both are active. wait for ping thread to complete
		//          or until 400 milliseconds pass
		//     pong is unaffected
		t1.Join(400); 

		Console.WriteLine( "OK: back now -- hi." );
		Console.WriteLine( "Let's see where we are." );

		Console.WriteLine( "OK: ping count: {0}", p1.Count );
		Console.WriteLine( "OK: PONG count: {0}", p2.Count );

		Console.WriteLine( "Suspending PONG" );	
		t2.Suspend();

		Console.WriteLine( "OK: here is some more main process output: " );
		Console.Write( "OK: " );
		for( int ix = 0; ix < 48; ++ix )
			 Console.Write( "{0} ", ix );
		Console.WriteLine();

		Console.WriteLine( "OK: Resuming PONG thread" );
		t2.Resume();

		Console.WriteLine( "OK: Unconditionally wait for PONG to complete" );
		t2.Join(); // wait for PONG to complete

		Console.WriteLine( "\nOK: PONG is complete now as well." );
		Console.WriteLine( "OK: ping count: {0}", p1.Count );
		Console.WriteLine( "OK: PONG count: {0}", p2.Count );
	}
}

class PingPong
{
	string  theWord;
	int     theDelay;
	int     theCount;

	public int Count { get { return theCount; } }
	const  int theMax = 100;

	public PingPong( string word, int delay )
		   { theWord = word; theDelay = delay; }

	public void play()
	{
		Console.WriteLine( "Within PingPong.play() for " + theWord + "!!!" );
		for ( ; ; ) {
			Console.Write( theWord+ " " );
			Thread.Sleep( theDelay );
			if ( ++theCount == theMax )
				 return;
		}
	}
} 