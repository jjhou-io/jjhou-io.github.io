using System;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Windows.Forms;

class EntryPoint
{
	public static void Main()
	{
		string path = Application.StartupPath + @"\..\..\";

		XslTransform xslt = new XslTransform();
		xslt.Load( path + "calories.xslt" ); 

		XPathDocument xmldocument = new XPathDocument( path +  "food.xml");

		XmlTextWriter writer = new XmlTextWriter(Console.Out);
		writer.Formatting=Formatting.Indented;
		
		// this line can replace the two above ...
		// TextWriter writer = Console.Out;

		xslt.Transform( xmldocument, null, writer );
	}
}
