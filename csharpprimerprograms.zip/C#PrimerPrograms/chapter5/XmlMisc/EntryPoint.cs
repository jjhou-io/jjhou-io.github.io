using System;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;

using System.IO;
using System.Collections;
using System.Xml.Serialization;

using System.Data;
using System.Data.OleDb; 
using System.Data.SqlClient;

using System.Windows.Forms;

class app
{
	public static void Main()
	{
		// Sorry. No automation here.
		// Just uncomment whichever method you wish to execute

		Console.WriteLine( "Beginning executing XmlSerializePoint.serializePoint() ... " );
		XmlSerializePoint.serializePoint();
		Console.WriteLine( "Ending executing XmlSerializePoint.serializePoint() ... " );

		Console.WriteLine( "Beginning executing nutrition.sql() ... " );
		nutrition.sql();
		Console.WriteLine( "Ending executing nutrition.sql() ... " );

		Console.WriteLine( "Beginning executing nutrition.xml() ... " );
		nutrition.xml();
		Console.WriteLine( "Ending executing nutrition.xml() ... " );
		
		Console.WriteLine( "Beginning executing nutrition.access() ... " );
		nutrition.access();
		Console.WriteLine( "Ending executing nutrition.access() ... " );

		Console.WriteLine( "Beginning executing MealEntry.genDoc() ... " );
		MealEntry.genDoc();
		Console.WriteLine( "Ending executing MealEntry.genDoc() ... " );
	}
}

