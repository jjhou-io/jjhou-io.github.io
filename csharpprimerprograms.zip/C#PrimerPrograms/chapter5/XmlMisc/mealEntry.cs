using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Collections;
using System.Windows.Forms;
using System.Reflection;

class MealEntry
{
	public enum MealTime 
	{
		NotSure, Breakfast, Lunch, Dinner, 
		SnackMorning, SnackAfternoon, SnackEvening,
		SnackNight 
	};

	public static void genDoc()
	{
		string client = "Alice Emma Weeks";
		ArrayList foods = new ArrayList();
		foods.Add( "banana" ); 
		foods.Add( "bread, whole wheat" );
		foods.Add( "Ben & Jerry, Quart, RockyRoad" );
	    MealTime mealType = MealTime.SnackNight;
		genMealEntry( client, mealType, foods );
	}

	public static void genMealEntry( string client, MealTime mt, ArrayList foods )
	{
		/*
		 * 
			<?xml version="1.0" encoding="IBM437"?>
			<!--Alice Emma Weeks:1/20/2002-->
			<?nutrition diabetes heart?>
			<k:nutrition xmlns:k="urn:nutrition">
			<client>Alice Emma Weeks</client>
			<meal>SnackNight</meal>
			<item0>banana</item0>
			<item1>bread, whole wheat</item1>
			<item2>Ben &amp; Jerry, Quart, RockyRoad</item2>
			</k:nutrition>
		*/

		// instantiate the document
		XmlDocument doc = new XmlDocument();
		XmlNode node;

		// create an xml declaration
		node = doc.CreateXmlDeclaration( "1.0", null, null );
		doc.AppendChild( node );

		// create a comment/pi and append
		node = doc.CreateComment( client+":"+DateTime.Now.ToShortDateString() ); 
		doc.AppendChild(node);
		node = doc.CreateProcessingInstruction("nutrition", "diabetes heart");
		doc.AppendChild(node);

		// create the root element ...
		node = doc.CreateElement("mt", "nutrition", "urn:nutrition");
		doc.AppendChild(node);

		// ok: let's populate this puppy
		node = doc.CreateElement( "client" );
		node.InnerText = client;

		doc.DocumentElement.AppendChild( node );
		node = doc.CreateElement( "meal" );
		node.InnerText = mt.ToString();
		doc.DocumentElement.AppendChild( node );

		for( int ix = 0; ix < foods.Count; ++ix ){
			node = doc.CreateElement( "item" + ix.ToString() );
			node.InnerText = (string) foods[ ix ];
			doc.DocumentElement.AppendChild( node );
		}

		// serialize the document to the console
		XmlTextWriter theWriter = new XmlTextWriter( Console.Out );
		theWriter.Formatting = Formatting.Indented;
		doc.Save( theWriter ); Console.WriteLine();
	}
}