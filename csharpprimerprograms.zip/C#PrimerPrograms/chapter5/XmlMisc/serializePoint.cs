using System;
using System.IO;
using System.Windows.Forms;

using System.Xml;
using System.Xml.Serialization;

[XmlRoot("class Point")]
public struct Point 
{
	public float  m_x, m_y, m_z;
	public string m_now;

	public Point( float x, float y, float z ) 
	{
		m_x = x; m_y = y; m_z = z;
		m_now = DateTime.Now.ToString();
	}
}

class XmlSerializePoint 
{
	public static void serializePoint() 
	{
		Point         pt = new Point( 0.5f, 1.5f, 4.5f );
		XmlSerializer xs = new XmlSerializer( typeof( Point ));

		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

		FileStream fs = new FileStream( thisDir + "xs.xml", FileMode.Create );

		xs.Serialize( fs, pt );
		xs.Serialize( Console.Out, pt ); Console.WriteLine();

		fs.Close();
	}
}

