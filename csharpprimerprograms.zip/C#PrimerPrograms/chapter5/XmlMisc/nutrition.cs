using System;

using System.IO;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using System.Data;
using System.Data.OleDb; 
using System.Data.SqlClient;

using System.Windows.Forms;

class nutrition
{
	static public void access()
	{
		Console.WriteLine( "OK: about to access data" );

		string connect = "Provider=Microsoft.JET.OLEDB.4.0;" +
			@"data source=C:\nutrition\database\FOOD_DES.mdb";

		OleDbConnection  db_conn = new OleDbConnection( connect ); 
		OleDbDataAdapter adapter = new OleDbDataAdapter();

		string command = "SELECT * FROM FOOD_DES";
		adapter.SelectCommand = new OleDbCommand( command, db_conn );

		Console.WriteLine( "OK: about to set up data set" );

		DataSet ds = new DataSet();
		adapter.Fill( ds, "FOOD_DES" );
		db_conn.Close();

		Console.WriteLine( "OK: about to create an xml data doc" );

		XmlDataDocument xmlDoc   = new XmlDataDocument(ds);
		XmlNodeList nodeList;
		
		nodeList = xmlDoc.ChildNodes;
		Console.WriteLine( "OK: set up the XmlNodeList: {0}", nodeList.Count );

		int cnt = 0;
		foreach ( XmlNode myNode in nodeList )
		{
			foreach (XmlNode child in myNode.ChildNodes )
			{
				if ( ++cnt > 8 ) break;
				Console.WriteLine( "\n( {0} )", cnt );
				foreach (XmlNode childNode in child.ChildNodes )
					Console.WriteLine( "\t{0}", childNode.InnerText );
			}
		}
	}

	public static void xml()
	{
		Console.WriteLine( "OK: about to access data" );

		DataSet ds = new DataSet();
		ds.ReadXml( @"..\..\short_food.xml" );
		
		Console.WriteLine( "OK: about to create an xml data doc" );

		XmlDataDocument xmlDoc   = new XmlDataDocument(ds);
		XmlNodeList nodeList;

		XmlElement root = xmlDoc.DocumentElement;
		nodeList = root.SelectNodes( "/food_composition/food" );

		Console.WriteLine( "OK: set up the XmlNodeList: {0}", nodeList.Count );

		foreach (XmlNode myNode in nodeList)
		{
			Console.WriteLine( "\n{0}", myNode.Name );
			foreach (XmlNode childNode in myNode.ChildNodes )
				Console.WriteLine( "\t{0}", childNode.InnerText );
		}

		/// TODO
		/// show the dataset manipulation of the xml

	}
	public static void sql()
	{
		SqlConnection nwindConn = new SqlConnection("Data Source=localhost;Initial Catalog=northwind;Integrated Security=SSPI;");
		nwindConn.Open();

		DataSet myDataSet = new DataSet("CustomerOrders");

		SqlDataAdapter custDA = new SqlDataAdapter("SELECT * FROM Customers", nwindConn);
		custDA.Fill(myDataSet, "Customers");

		SqlDataAdapter ordersDA = new SqlDataAdapter("SELECT * FROM Orders", nwindConn);
		ordersDA.Fill(myDataSet, "Orders");

		SqlDataAdapter detailsDA = new SqlDataAdapter("SELECT * FROM [Order Details]", nwindConn);
		detailsDA.Fill(myDataSet, "OrderDetails");

		nwindConn.Close();

		myDataSet.Relations.Add("CustOrders",
			myDataSet.Tables["Customers"].Columns["CustomerID"],
			myDataSet.Tables["Orders"].Columns["CustomerID"]).Nested = true;

		myDataSet.Relations.Add("OrderDetail",
			myDataSet.Tables["Orders"].Columns["OrderID"],
			myDataSet.Tables["OrderDetails"].Columns["OrderID"], false).Nested = true;

		XmlDataDocument xmlDoc = new XmlDataDocument(myDataSet); 
		XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("descendant::Customers[* /OrderDetails/ProductID=43]");
      
		DataRow myRow;
		foreach (XmlNode myNode in nodeList)
		{
			myRow = xmlDoc.GetRowFromElement((XmlElement)myNode);
			if (myRow != null)
				Console.WriteLine(myRow[1]);
		}

		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

		myDataSet.WriteXml( thisDir + "northwind.xml" );
		myDataSet.WriteXmlSchema( thisDir + "northwind.xsd" );
	}
}

