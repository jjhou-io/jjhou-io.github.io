using System;
using System.IO;
using System.Text.RegularExpressions;

// Note: sorry, this is only a partial implementation.
//       it should illustrate Regular Expressions ...
    
public class CapsCamera
    {
		private delegate void method( string s );

		private string m_field;
		private string m_current_frame;
		private int    m_count_frames; 
		private int    m_frame;
		private int    m_fstart;

        private double m_xoffset1, m_xoffset2;  
		private double m_yoffset1, m_yoffset2;
		private double m_xps1,     m_xps2;

        private method [] m_methods;  
  
		private const int        ms_fps = 24;
		static private Regex  [] ms_terminals;
		static private Regex  [] ms_fields;
		
		static private string [] ms_field_names;

		public CapsCamera( int frameStart )
		{ 
			m_fstart = frameStart; 

			m_methods = new method[ 6 ];
			m_methods[ 0 ] += new method( process_level );
			m_methods[ 1 ] += new method( process_bez );
			m_methods[ 2 ] += new method( process_fix );
			m_methods[ 3 ] += new method( process_cpy );
			m_methods[ 4 ] += new method( process_last );
			m_methods[ 5 ] += new method( process_line );
		}

		public CapsCamera() : this( 1 ){}

		static CapsCamera()
		{
			ms_terminals = new Regex[5];
		    ms_terminals[ 0 ] = new Regex( "Level" );
			ms_terminals[ 1 ] = new Regex( "bez" );
			ms_terminals[ 2 ] = new Regex( "fix" );
			ms_terminals[ 3 ] = new Regex( "cpy" );
			ms_terminals[ 4 ] = new Regex( "!" ); 
 
			ms_fields = new Regex[4];
		    ms_fields[ 0 ] = new Regex( "FIELD" );
			ms_fields[ 1 ] = new Regex( "E/W PEG" );
			ms_fields[ 2 ] = new Regex( "E/W CAM" );
			ms_fields[ 3 ] = new Regex( "N/S CAM" );

			ms_field_names = new string[4];
			ms_field_names[ 0 ] =  "FIELD";
			ms_field_names[ 1 ] =  "PEG_OFF";
			ms_field_names[ 2 ] =  "EW";
			ms_field_names[ 3 ] =  "NS";
		}
		
		private void process_level( string line )
		{ 
			Console.WriteLine( "process_level( {0} )", line );

			// reset processing values
			m_count_frames = 1; m_frame = m_fstart;
			m_current_frame = "";
			m_xoffset1 = 0.0;   m_yoffset1 = 0.0; m_xps1 = 0.0;
			m_xoffset2 = 0.0;   m_yoffset2 = 0.0; m_xps2 = 0.0;

			int ix = 0;

			// should change this to an enum
			for ( ; ix < ms_fields.Length; ++ix )
			{
				  if ( ms_fields[ ix ].IsMatch( line ))
				  {
					   Console.WriteLine( "found: {0} :: {1}", 
						       ms_fields[ix].ToString(), ms_field_names[ ix ] );

					   m_field = ms_field_names[ ix ];
					   break;
				  }
			}
						   
			if ( ix == ms_fields.Length )
                 throw new Exception( "Unrecognized Label field: " + line );
		}

		private void process_bez( string line )
		{
			Console.WriteLine( "process_bez( {0} )", line );
			string filter = "(?<1>(-*\\d+\\.\\d+)|(-*\\d+))\\s\\'*\\s*bez\\((?<2>(-*\\d+\\.\\d+)|(\\d+)),(?<3>(-*\\d+\\.\\d+)|(\\d+)),(?<4>(-*\\d+\\.\\d+)|(\\d+)),(?<5>(-*\\d+\\.\\d+)|(\\d+))";
			
            Regex regex = new Regex( filter );
			Match match = regex.Match( line );

			if ( ! match.Success )
				 throw new Exception( "unexpected Bez format: " + line );

			bool verbose = true;

			if ( verbose )
            {
                Console.WriteLine( "camera location: {0}", match.Groups[1].ToString() );
				Console.WriteLine( "xoffset1: {0}", match.Groups[2].ToString() );
				Console.WriteLine( "yoffset1: {0}", match.Groups[3].ToString() );
				Console.WriteLine( "xoffset2: {0}", match.Groups[4].ToString() );
				Console.WriteLine( "yoffset2: {0}", match.Groups[5].ToString() );
            }

			float 
				loc = Convert.ToSingle( match.Groups[1].ToString() ),
				m_xoffset1 = Convert.ToSingle( match.Groups[2].ToString() ),
				m_yoffset1 = Convert.ToSingle( match.Groups[3].ToString() ),
				m_xoffset2 = Convert.ToSingle( match.Groups[4].ToString() ),
				m_yoffset2 = Convert.ToSingle( match.Groups[5].ToString() );

			if ( verbose )
            {
                Console.WriteLine( "location: {0:####.00}", loc );
				Console.WriteLine( "xoffset1: {0:####.00}", m_xoffset1 );
				Console.WriteLine( "yoffset1: {0:####.00}", m_yoffset1 );
				Console.WriteLine( "xoffset2: {0:####.00}", m_xoffset2 );
				Console.WriteLine( "yoffset2: {0:####.00}", m_yoffset2 );
            }

		}

		private void process_fix( string line )
		{
			Console.WriteLine( "process_fix( {0} )", line );
		}

		private void process_cpy( string line )
		{
			Console.WriteLine( "process_cpy( {0} )", line );
		}

		private void process_last( string line )
		{
			Console.WriteLine( "process_last( {0} )", line );
		}

		private void process_line( string line )
		{
			Console.WriteLine( "process_line( {0} )", line );
		}

		public void process_file()
		{
			process_file( @"c:\C#Programs\RegEx\cameraData.txt" );
		}

		public void process_file( string file_name )
		{
			if ( file_name == String.Empty ||
			   ( ! File.Exists( file_name )))
			{
				Console.WriteLine( "Oops: invalid file name: {0}", file_name );
				return;
			}
   
		    StreamReader ifile = File.OpenText( file_name );
			
			// generate_preface();

		    string textline;
		    while (( textline = ifile.ReadLine()) != null )
			{
		             Console.WriteLine( "text line read: {0}", textline );
					 int ix = 0;
					 for ( ; ix < ms_terminals.Length; ++ix )
					 {
						   if ( ms_terminals[ ix ].IsMatch( textline )){
							    Console.WriteLine( "found: {0}", ms_terminals[ix].ToString() );
							    m_methods[ ix ]( textline );
							    break;
						   }
					 }
						   
				     if ( ix == ms_terminals.Length ){
						  Console.WriteLine( "found: non-terminal line!" );
						  m_methods[ ix ]( textline );
					 }
			}
	    }
    }
public class CapsEntryPoint
{	
	public static void CapsTest()
	{
		Console.WriteLine( "CapsTest(): beginning" );
		CapsCamera caps = new CapsCamera();
		caps.process_file();
		Console.WriteLine( "CapsTest(): ending" );
	}

	public static void Main()
    {
			CapsTest();
		    exploreRegex();
    }

	public static void exploreRegex()
	{
		    string inputString = "bbbiibb";
		
            // string inputString = "a21d2";
			// string filter = "\\d";
			// string filter = "\\d+";
			//string filter = "\\d*";
		    string filter = "(a|e|i|o|u)+";

			// string inputString = "5040 bez(99,-3.94,43,8.84)";
			// string inputString = "5040 bez(99,-3.94,43,8.84)";

			// string filter = "(-*\\d+\\.\\d+|-*\\d+)\\s\\'*\\s*bez\\((-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+)";
			// string filter = "(-*\\d+\\.\\d+|-*\\d+)\\s";
			// string filter = "(?:<1>(-*\\d+\\.\\d+)|(-*\\d+))\\s";

			// string filter = "(?<1>(-*\\d+\\.\\d+)|(-*\\d+))\\s\\'*\\s*bez\\((?<2>(-*\\d+\\.\\d+)|(\\d+)),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+)";
			

			Console.WriteLine( "original string:  {0}", inputString );
			Console.WriteLine( "attempt to match: {0}", filter );

            Regex regex = new Regex( filter );
			Match match;

            // foreach (string subString in theRegex.Split(s1))

			for ( match = regex.Match( inputString );
				  match.Success; match = match.NextMatch() )
            {
                Console.WriteLine( "match #1: {0} at {1}", 
					                match.ToString(), match.Index );
									// match.Group(1).ToString(), match.Group(1).Index );
				// Console.WriteLine( "match #2: {0} at {1}",
									// match.Group(2).ToString(), match.Group(2).Index );

            }

            
        }

	public static void sampleReplace()
	{
		 // joining lines in multiline strings
    string t16 = @"I am       asking                   a   question?";
    string p16 = @"\s+";
    string r16 = Regex.Replace(t16, p16, " ");
    Console.WriteLine("r16=" + r16);

	}
}