using System;
using System.IO;
using System.Xml;
using System.Windows.Forms;
    
public class GenerateXML
{
        public static void Main()
		{
			string startupPath = Application.StartupPath;
			string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

			// this is what we'll use as data to populate our xml document
			/*
			 * cheese mozzarella 281 21.60 78 2.20 19.42 0
			 * cheese muenster 368 30.04 96 1.12 23.41 0
			 * cheese provolone 351 26.62 69 2.14 25.58 0
			 */

			StreamReader ifile = File.OpenText( thisDir + "dairy.txt" );

			// this will hold our generated XML document
			FileInfo xmloutput = new FileInfo( thisDir + "dairy.xml" );

			string entryline;
			string [] fields;

			// our XML document object 
			XmlDocument dairy = new XmlDocument();

			// our declaration and a simple comment
			XmlDeclaration xdecl = dairy.CreateXmlDeclaration("1.0", "utf-8", string.Empty );
			XmlComment     xcom  = dairy.CreateComment( "Illustration of building up an XmlDocument" );
			
			// our root element
			XmlElement  entry = dairy.CreateElement( "food_nutrition" );

		    while (( entryline = ifile.ReadLine()) != null )
			{
				// echo line to console
				Console.WriteLine( entryline );
				
				// separate string into individual elements
				fields = entryline.Split( new char[0] );

				// ok: let's print the individual elements to the Console
				//     just as a sanity check ...
				foreach ( string s in fields )
					      Console.WriteLine( s );

				// ok: now populate the document with the elements ...
				XmlElement family = dairy.CreateElement( "family" );
				family.InnerText = fields[ 0 ];

				XmlElement name = dairy.CreateElement( "name" );
				name.InnerText = fields[ 1 ];

				XmlElement calories = dairy.CreateElement( "calories" );
				calories.InnerText = fields[ 2 ];

				XmlElement fat = dairy.CreateElement( "fat" );
				fat.InnerText = fields[ 3 ];

				XmlElement cholestrol = dairy.CreateElement( "cholestrol" );
				cholestrol.InnerText = fields[ 4 ];

				XmlElement carbohydrates = dairy.CreateElement( "carbohydrates" );
				carbohydrates.InnerText = fields[ 5 ];

				XmlElement protein = dairy.CreateElement( "protein" );
				protein.InnerText = fields[ 6 ];

				XmlElement fiber = dairy.CreateElement( "fiber" );
				fiber.InnerText = fields[ 7 ];

				// ok: let's build up the hierarchy
				family.AppendChild( name );
				family.AppendChild( calories );
				family.AppendChild( fat );
				family.AppendChild( cholestrol );
				family.AppendChild( carbohydrates );
				family.AppendChild( protein );
				family.AppendChild( fiber );
				entry.AppendChild( family );
			}

			dairy.AppendChild( xdecl );
			dairy.AppendChild( xcom );
			dairy.AppendChild( entry );

			// ok: we have our document. now let's write it to disk
			XmlTextWriter xwriter = new XmlTextWriter( xmloutput.CreateText() );
			xwriter.Formatting = Formatting.Indented;
			dairy.WriteContentTo( xwriter );
			xwriter.Flush();

			// ok: let's write it to the console
			XmlTextWriter xout = new XmlTextWriter( Console.Out );
			xout.Formatting = Formatting.Indented;
			dairy.WriteContentTo( xout );
				
		}
}