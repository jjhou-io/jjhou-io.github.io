using System;
using System.IO;
using System.Windows.Forms;
using System.Collections;

class EntryPoint
{
	static string startupPath = Application.StartupPath;
	public static string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

	public static void Main()
	{
		Console.WriteLine( "FileIO begin ... " );

		TextFileTest.StreamReaderWriter();
		TextFileTest.FileOpen( thisDir + "word.txt", thisDir + "word_out.txt" );
		TextFileTest.BytesReadWrite( thisDir + "word.txt", thisDir + "word_trace.txt" );

		Console.WriteLine( "FileIO end ... " );
	}
}

class TextFileTest
{
	public static void StreamReaderWriter()
	{
		StreamReader ifile = new StreamReader( EntryPoint.thisDir + "word.txt" );
		StreamWriter ofile = new StreamWriter( EntryPoint.thisDir + "word_out.txt" );

		string str;
		ArrayList textLines = new ArrayList();

		while (( str = ifile.ReadLine()) != null )
		{
			Console.WriteLine( str );
			textLines.Add( str );
		}

		textLines.Sort();

		foreach ( string s in textLines )
			      ofile.WriteLine( s );

		ifile.Close();
		ofile.Close();
	}

	public static void FileOpen( string inFile, string outFile )
	{
		FileStream ifd = File.Open( inFile, FileMode.Open, FileAccess.Read );
		FileStream ofd = File.Open( outFile, FileMode.OpenOrCreate, FileAccess.ReadWrite );
		
			StreamReader ifile = new StreamReader( ifd );
			StreamWriter ofile = new StreamWriter( ofd );

			string str;
			ArrayList textLines = new ArrayList();

			while (( str = ifile.ReadLine()) != null ){
				Console.WriteLine( str );
				textLines.Add( str );
			}

			textLines.Sort();

			foreach ( string s in textLines )
					  ofile.WriteLine( s );

		    ifile.Close();
		    ofile.Close();
		
	}

	public static void BytesReadWrite( string inFile, string outFile )
	{
		if (( ! File.Exists( inFile )) ||( ! File.Exists( outFile )))
		{
			// generate a message
			return;
		}

		FileStream ifile = new FileStream( inFile, FileMode.Open, FileAccess.Read, FileShare.Read );
		FileStream ofile = new FileStream( outFile, FileMode.Truncate, FileAccess.ReadWrite );

		const int max_bytes = 124;
		byte  []  buffer    = new byte[ max_bytes ];
		int       bytesRead;

		while (( bytesRead = 
					ifile.Read( buffer, 0, max_bytes )) != 0 )
		{
			Console.WriteLine( "Bytes read: {0}", bytesRead );
			ofile.Write( buffer, 0, bytesRead );
		}

		ofile.Flush();

		Console.WriteLine( "file_Stream: CanRead:  {0}",  ofile.CanRead  );
		Console.WriteLine( "file_Stream: CanWrite: {0}",  ofile.CanWrite );
		Console.WriteLine( "file_Stream: CanSeek:  {0}",  ofile.CanSeek  );

		if ( ! ofile.CanWrite || ! ofile.CanSeek ) 
			    return;

		Console.WriteLine( "file_Stream: Length: {0}", ofile.Length );
		long offset = ofile.Length/4 - 1;
	
		for ( long position = 0L; position < ofile.Length; position += offset )
		{
			ofile.Seek( position, SeekOrigin.Begin );
			int theByte = ofile.ReadByte();
			ofile.WriteByte((byte)'X' );
			Console.WriteLine( "file_Stream: Position: {0} -- byte replaced: {1}", ofile.Position, Convert.ToChar( theByte ));
		}

		ifile.Close(); ofile.Close();
	}
}
