using System;
using System.Xml;
using System.Xml.XPath;
using System.Windows.Forms;

class xPathEntryPoint
{
	public static void Main()
	{
		Console.WriteLine( "Beginning XPath exercises ..." );
		xPathTester.test();
		Console.WriteLine( "Ending XPath exercises ..." );
	}
}

class xPathTester
{
	public static void test()
	{
		Console.WriteLine( "!!! : ok: about to create objects" );

        string path = Application.StartupPath + @"\..\..\";
		XPathDocument xpdoc = new XPathDocument( path + "food.xml" ); 
		XPathNavigator navi = xpdoc.CreateNavigator();

		Console.WriteLine( "!!! : ok: about to select food elements" );

		XPathNodeIterator iter = navi.Select( "/food_composition/food" );
		while ( iter.MoveNext() ){
			Console.WriteLine( iter.Current.Name );
			if ( iter.Current.HasChildren )
			{
				iter.Current.MoveToFirstChild();
				Console.WriteLine( iter.Current.Name );
				while ( iter.Current.MoveToNext() )
					 Console.WriteLine( iter.Current.Name );
			}
		}

		Console.WriteLine( "!!! : ok: about to select all children" );

		iter = navi.SelectChildren( XPathNodeType.All );
		int icnt = 0;
		while ( iter.MoveNext() )
			Console.WriteLine(( ++icnt).ToString() + ". " + iter.Current.Name +
		          " ==> " + iter.Current.ToString() );
	}
}