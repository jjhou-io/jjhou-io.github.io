using System;
using System.IO;

using System.Security;
using System.Collections;
using System.Diagnostics; // for Process class
using System.Windows.Forms;    // for Application class

public class EntryPoint
{
	public static void Main()
	{
		// HelloEnvironment.displayEnvironment();
		HelloEnvironment.process();	
	}
}
	
class HelloEnvironment
{	
	public static void displayEnvironment()
	{
		IDictionary dict = 
		   Environment.GetEnvironmentVariables();
		
		Console.WriteLine("There are {0} environment variables", dict.Count );
				
		string [] keys = new string[ dict.Count ];
		string [] values = new string[ dict.Count ];

		int ix = 0;
		foreach ( DictionaryEntry de in dict )
		{
			keys[ ix ]   = (string) de.Key;
			values[ ix ] = (string) de.Value;
			++ix;
		}

		Array.Sort( keys, values );

		for ( ix = 0; ix < keys.Length; ++ix )
		{
			Console.WriteLine( "Variable is {0} -- see its value? (y/n)", keys[ix]);
		    string rsp = Console.ReadLine();
			if ( rsp == "y" || rsp == "Y" )
				 Console.WriteLine( "\t==> {0} ", values[ix] );
		}	  
	}

    public static void process()
	{
		string user_name = 
			Environment.GetEnvironmentVariable( "USERNAME" );
 
		string mach_name = 
			Environment.GetEnvironmentVariable( "COMPUTERNAME" );

		OperatingSystem os_ver = Environment.OSVersion;
		
		if ( os_ver.Platform == PlatformID.Win32NT )
			 Console.WriteLine( "Hello, {0}!", user_name );
		else Console.WriteLine("Hello!"); 

		// Console.WriteLine( "Hello, {0}!", user_name );
		Console.WriteLine( "Your machine {0} is running {1}\n",
							mach_name, os_ver.ToString() );

		Process currProc = Process.GetCurrentProcess();
		Console.WriteLine( "The current process running is \'{0}\'", currProc.ProcessName );

		string startupPath;
        startupPath = Application.StartupPath;
        Console.WriteLine("Startup Path is {0}", startupPath);

		Process [] procs = Process.GetProcesses();
		string msg="There are {0} other processes running on {1}\n";
		Console.WriteLine( msg, procs.Length-1, mach_name ); 

		int dayCnt = 0;
		int hourCnt = 0;
		int minCnt = 0;
		int lessMinCnt = 0;

		foreach ( Process proc in procs )
		{
			TimeSpan totalTime = proc.TotalProcessorTime;

            if ( totalTime.Days > 0 )
			{
				 dayCnt++;
				 Console.WriteLine( "\nProcess Name: {0}", proc.ProcessName );
			     Console.WriteLine( "\thas been running for {0} days\n\ttotal: {1}",
				                       totalTime.Days, totalTime.ToString() );
			} 
			else
            if ( totalTime.Hours > 0 )
				 hourCnt++;
			else
			if ( totalTime.Minutes > 0 )
				 minCnt++;
			else lessMinCnt++;
		}

        Console.WriteLine( "\nMachine {0} Process Statistics", mach_name );
		Console.WriteLine( "\tLonger than a day:    {0}", dayCnt );
		Console.WriteLine( "\tLonger than an hour:  {0}", hourCnt );
		Console.WriteLine( "\tLonger than a minute: {0}", minCnt );
		Console.WriteLine( "\tLess than a minute:   {0}", lessMinCnt );

		Console.WriteLine();

		string [] logical_drives = Directory.GetLogicalDrives();
		Console.WriteLine(	"The logical drive subdirectory structure: ");
		
		foreach ( string dir_path in logical_drives )
		{
			Console.Write( "\t" );
			DirectoryInfo dir = new DirectoryInfo( dir_path );
			
			if ( dir.Exists == false ){
				 Console.WriteLine( "{0} :: is currently unavailable.", dir_path );
				 continue;
			}
				
			DirectoryInfo [] sub_dirs = dir.GetDirectories();
			int              dir_cnt  = sub_dirs.Length;
			Console.WriteLine( "{0} :: {1} subdirectories.", dir_path, dir_cnt );

			if ( dir_cnt < 10 )
			{
				Console.Write( "\t    The subdirectories: " );
			    foreach ( DirectoryInfo d in sub_dirs )
			    {
				    string dname = d.Name;
				    Console.Write( "{0} ", dname );
				}
				Console.WriteLine();
			}
		}

		Process p = Process.GetCurrentProcess();
		Console.WriteLine( "process id {0}", p.Id );

		Console.WriteLine( "\tstarted at {0}", p.StartTime );
		Console.WriteLine( "\tPrivleged Processor Time: \t{0}", p.PrivilegedProcessorTime );
		Console.WriteLine( "\tTotal Processor Time: \t{0}", p.TotalProcessorTime );
		Console.WriteLine( "\tUser Processor Time: \t{0}\n", p.UserProcessorTime );

		Console.WriteLine( "\tNonpaged System Memory: \t{0}", p.NonpagedSystemMemorySize );
		Console.WriteLine( "\tPaged Memory: \t{0}", p.PagedMemorySize );
		Console.WriteLine( "\tPaged System Memory: \t{0}", p.PagedSystemMemorySize );
		Console.WriteLine( "\tPeaked Page Memory: \t{0}", p.PeakPagedMemorySize );
		Console.WriteLine( "\tPeak Virtual Memory: \t{0}", p.PeakVirtualMemorySize );
		Console.WriteLine( "\tVirtual Memory Size: \t{0}", p.VirtualMemorySize );
		Console.WriteLine( "\tWorkingSet: \t{0}", p.WorkingSet  );
	}
}
