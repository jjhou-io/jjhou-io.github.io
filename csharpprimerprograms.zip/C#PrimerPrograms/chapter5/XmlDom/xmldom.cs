
using System;
using System.Diagnostics;
using System.IO;
using System.Xml; 
using System.Windows.Forms;

class testXML 
{

	public static void Main()
	{
		Console.WriteLine( "ok: processing beginning ..." );

		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

		string     xfile = thisDir + "food.xml"; 
		string  diagfile = thisDir + "food.diag";

		FileStream xmlfile = new FileStream( xfile, FileMode.Open );
        FileStream xmldiag = new FileStream( diagfile, FileMode.Create );

		Console.WriteLine( "ok: creating XmlTextReader for {0}", xfile );
		XmlTextReader xr = new XmlTextReader( xmlfile );
		XmlDocument   xd = new XmlDocument();

		Console.WriteLine( "ok: loading XmlTextReader for XmlDocument" );
		timer t   = new timer();
		t.context = "time to load xml document ";
		t.start();

		xd.Load( xr );

		t.stop();
		Console.WriteLine( t.ToString() );

		XmlDom.DiagFile = new StreamWriter( xmldiag );

		Console.WriteLine( "ok: processing the XmlDocument" );
		t.context = "time to process xml document ";
		t.start();

		XmlDom.processDOM( xd );

		t.stop();
		Console.WriteLine( t.ToString() );

		Console.WriteLine( "ok: processing done ... " );
		XmlDom.DiagFile.Close();
	}
}

class XmlDom
{
	static private StreamWriter diagFile;
	static public StreamWriter DiagFile 
	{
		get{ return diagFile;  }
		set{ diagFile = value; }
	}

	static public bool processDOM( XmlDocument xd )
	{
		
		diagFile.WriteLine( "XmlDocument {0} :: {1} ", xd.Name, xd.Value );

		XmlAttributeCollection xac = xd.Attributes;
		if ( xac != null && xac.Count != 0 )
		     diagFile.WriteLine( "\tDocument has {0} attributes\n", xac.Count );
		else diagFile.WriteLine( "\tDocument has no attributes.\n" );

		diagFile.WriteLine( "Retrieving the {0} XmlDocument  Children\n",
			                xd.ChildNodes.Count );

		XmlNodeList children = xd.ChildNodes;
		foreach ( XmlNode node in children )
		{
			diagFile.WriteLine( "Child node: {0} of type {1}", node.Name, node.NodeType );
			diagFile.WriteLine( "    Child has children? {0} :: Node's parent: {1}",
				    node.HasChildNodes, node.ParentNode.Name );
			diagFile.WriteLine();
		}

		diagFile.WriteLine( "OK: grabbing root element using DocumentElement" );
		XmlElement xelem = xd.DocumentElement;
		diagFile.WriteLine( "OK: {0} is the root element: ", xelem.Name );
				
		if ( xelem.HasChildNodes )
			 diagFile.WriteLine( "OK: {1}'s first child: {0}\n", xelem.FirstChild.Name, xelem.Name );

		diagFile.WriteLine( "Processing root element ... \n" );
		processElement( xelem );

		XmlNodeList foodElem = xelem.GetElementsByTagName( "food" );
		Console.WriteLine( "{0} foodElem retrieved", foodElem.Count );

		return true;
		
	}

	static public void processElement( XmlElement xe )
	{
		diagFile.WriteLine( "XmlElement {0} in processElement", xe.Name );

		if ( xe.HasChildNodes )
		{
			XmlNodeList xnl = xe.ChildNodes;
			diagFile.WriteLine( "{1} has {0} children", xnl.Count, xe.Name );
			
			foreach( XmlNode nn in xnl )
			{
				diagFile.WriteLine( "\thas child: {0} == {1}", 
					               nn.Name, nn.NodeType );

				switch( nn.NodeType )
				{
					case XmlNodeType.Element:
						processElement( (XmlElement)nn );
						break;

					case XmlNodeType.Text:
						// processText( (XmlText)nn );
						diagFile.WriteLine( "Text Node: {0}", nn.Value );
						break;

					case XmlNodeType.Comment:    
				        // processComment( (XmlComment)nn );
						diagFile.WriteLine( "Comment Node: {0}", nn.Value );
				        break;

					case XmlNodeType.CDATA: 
						// processCDATA( (XmlCDATA)nn );
				        diagFile.WriteLine( "CDATA Node: {0} :: {1}", nn.Name, nn.Value );
				        break;
				
			        case XmlNodeType.ProcessingInstruction: 
						// processProcInst( (XmlProcessingInstruction)nn );
					    diagFile.WriteLine( "PI Node: {0} :: {1}", nn.Name, nn.Value );
						break;

					case XmlNodeType.EndElement: 
						diagFile.WriteLine( "EndTag Node: {0}", nn.Name );
						if ( nn.Name.Equals( nn.Name ))
						{
						    diagFile.WriteLine( "OK: end of element {0}", xe.Name );
						    // Console.WriteLine( "\tvalue: {0}", elementValue );
						    // if ( elementComments.Count != 0 )
						         // Console.WriteLine( "Number of comments: {0}", elementComments.Count );
						}
				     break;
				}
			}
		}
	}
}