using System;
using System.Xml; 
using System.IO;
using System.Collections;

class xmlParse 
{
	/*
	 * 
		Beginning xmlParse.process_nodes() ...

		node type is XmlDeclaration
				name is xml
				value is version="1.0" encoding="utf-8"

		node type is Comment
				This node has no name
				value is  Place keywords in the PI below

		node type is ProcessingInstruction
				name is calories
				value is diabetes

		node type is Element
				name is food_composition
				has no attributes

		node type is Element
				name is food
				has no attributes

		node type is Element
				name is category
				has no attributes

		node type is Text
				This node has no name
				value is dairy

		node type is EndElement

		Ending xmlParse.process_nodes() ...
		Beginning xmlParse.switch_nodes() ...

		whole milk      calories : 150
		mozzarella      calories : 281  *** diabetes : -1
		muenster        calories : 368  *** diabetes : -1
		provolone       calories : 351  *** diabetes : -1

		*** Total calories : 1150

		Ending xmlParse.switch_nodes() ...
	*
	*/

	public static void Main()
	{
		Console.WriteLine( "Beginning xmlParse.process_nodes() ... \n" );

		FileStream    fs = new FileStream( @"C:\c#talks\ShortFood.xml", FileMode.Open );
		XmlTextReader x  = new XmlTextReader( fs );
		process_nodes( x );
		fs.Close();x.Close();

		Console.WriteLine( "\nEnding xmlParse.process_nodes() ... " );
		Console.WriteLine( "Beginning xmlParse.switch_nodes() ... \n" );

		fs = new FileStream( @"C:\c#talks\Food.xml", FileMode.Open );
		x  = new XmlTextReader( fs );
	    switch_nodes( x );

		Console.WriteLine( "\nEnding xmlParse.switch_nodes() ... " );
	}

	public static void process_nodes( XmlTextReader x )
	{
		x.WhitespaceHandling = WhitespaceHandling.Significant;
		int cnt = 0;
		while ( x.Read() == true )
		{
			Console.WriteLine("node type is {0}", x.NodeType );

			if ( ++cnt >= 8 ) 
				 break;

			if ( x.Name != String.Empty )
			     Console.WriteLine( "\tname is {0}",   x.Name );
			else Console.WriteLine( "\tThis node has no name" );

			if ( x.HasValue )
                 Console.WriteLine("\tvalue is {0}", x.Value ); 
			
			if ( x.NodeType == XmlNodeType.Element )
				if ( x.HasAttributes )
				{
					Console.Write( "\thas {0} attributes: ", x.AttributeCount );
					while ( x.MoveToNextAttribute() )
						Console.Write( "{0} = {1} ", x.Name, x.Value );
					Console.WriteLine();
				}
				else Console.WriteLine( "\thas no attributes" );

			Console.WriteLine();
		}
	}

	public static void switch_nodes( XmlTextReader x )
	{
		ArrayList elements = new ArrayList();
		string    filter   = null;
		string    health   = null;
		string    food     = null;
		int       total    = 0;

		x.WhitespaceHandling = WhitespaceHandling.Significant;

		while ( x.Read() == true )
		{
			switch( x.NodeType )
			{ 
				case XmlNodeType.ProcessingInstruction:
					filter = x.Name;
					health = x.Value;
					break;

				case XmlNodeType.Element:  
				{
					string text = null;
					string suffix = "";

					if ( x.Name.Equals( "name" ))
					{
						food = x.ReadString();
						break;
					}

					if ( x.Name.Equals( filter ))
					{
						if ( x.HasAttributes )
						{
							while ( x.MoveToNextAttribute() )
							   if ( x.Name.Equals( health ))
									suffix = "\t*** " + health + " : " + x.Value;
						}

						x.MoveToElement();
						text = x.ReadString();
						total += Convert.ToInt32( text );
						elements.Add( food + "\t" + x.Name + " : " + text + suffix );
					}
					
					break;
				}
			}
		}

		foreach ( string s in elements )
			 Console.WriteLine( s );

		Console.WriteLine( "\n*** Total {0} : {1}", filter, total );
	}

	public static void process_content( XmlTextReader x, string elem )
	{
		while ( x.MoveToContent() == XmlNodeType.Element )
		{
			Console.WriteLine( "{0} : {1}", x.Name, x.ReadString() );
		}
	}


	public static void processElementNode( XmlTextReader x )
	{
		XmlDocument xdoc = new XmlDocument();
		XmlNode xn = xdoc.ReadNode( x );
		Console.WriteLine( "processElementNode: {0} {1}", xn.Name, xn.GetType() );
	}
}

class XmlWrapper
{
	private string     m_fileName;
	private FileStream fs;

	/// <summary>
	/// XmlTextReader object holds the current
	/// XML node -- so we will read and process
	/// this node in the main loop, with the
	/// delegate set to what to do with the node
	/// </summary>
	private XmlTextReader x;

	public delegate void Action(XmlTextReader xtr);
	private Action m_action_element;
	
	public Action action_element
	{
		set{ m_action_element = value; }
		get{ return m_action_element;  }
	}

	public string fileName
	{
		get{ return m_fileName; }
		set{ 
			// add code to check for validity of file
			// that it exists
			// that it is a file?
			if ( value == null )
				throw new Exception( "invalid FileName" );
			m_fileName = value; }
	}

	public bool processFile()
	{
		while ( x.Read() == true )
		{
			Console.WriteLine( "ok: read a node: about to call action" );
			process_nodeType();
		}

		return true;
	}

	/*
	public void process_identify()
	{
		Console.WriteLine( "node: {0}\tattributes: {1}\t index {2}", 
					        x.Name, x.AttributeCount, x[ x.Name ] );

		Console.WriteLine( "node type: {0}\n\tvalue :: {1}", 
			                x.NodeType.Format(), x.Value );
	}
	*/

	public void process_nodeType()
	{
		// Console.WriteLine( "process_nodeType!" );
		switch( x.NodeType )
		{

			/*
			Element 
				An Element. 
					Example XML: <Name>
				An Element node can have the following child node types: 
					Element, Text, Comment, ProcessingInstruction,
					CDATA, and EntityReference. 
				The Element node can be the child of the Document, 
					DocumentFragment, EntityReference, and Element nodes.
			*/
			case XmlNodeType.Element: // r.LocalName
				Console.WriteLine( "*** process_nodeType: found Element!" );
				Console.WriteLine( "name: {0}\tValue: {1}", x.Name, x.Value );

				if ( action_element != null )
					 action_element( x );
				if ( x.Read() == true )
				{
					Console.WriteLine( "inside element: found: " );
					Console.WriteLine( "node type: {0}", x.NodeType );
					Console.WriteLine( "name: {0}\tValue: {1}", x.Name, x.Value );
				}
				break;


			/*
			Text 
				The text content of an element. 
				A Text node cannot have any child nodes. 
				The Text node can appear as the child node of the Attribute, 
					 DocumentFragment, Element, and EntityReference nodes.
 
			*/
			case XmlNodeType.Text:    // r.Value
				Console.WriteLine( "*** process_nodeType: found Text!" );
				Console.WriteLine( "name: {0}\tValue: {1}", x.Name, x.Value );
				break;
	
			

			case XmlNodeType.Attribute: // r.LocalName, r.Value
				Console.WriteLine( "*** process_nodeType: found Attribute!" );
				Console.WriteLine( "name: {0}\tValue: {1}", x.Name, x.Value );
				break;

			case XmlNodeType.CDATA: 
				Console.WriteLine( "*** process_nodeType: found CDATA!" );
				break;

			case XmlNodeType.Comment:    
				Console.WriteLine( "*** process_nodeType: found Comment!" );
				Console.WriteLine( "name: {0}\tValue: {1}", x.Name, x.Value );
				break;

			case XmlNodeType.EndElement: 
				Console.WriteLine( "*** process_nodeType: found EndTag!" );
				break;
				
			case XmlNodeType.ProcessingInstruction: 
				Console.WriteLine( "*** process_nodeType: found ProcessingInstruction!" );
				break;

			case XmlNodeType.Whitespace: 
				Console.WriteLine( "*** process_nodeType: found Whitespace!" );
				break;
			
			case XmlNodeType.SignificantWhitespace: 
				Console.WriteLine( "*** process_nodeType: found SignificantWhitespace!" );
				break;
			
			case XmlNodeType.Notation: 
				Console.WriteLine( "*** process_nodeType: found Notation!" );
				break;
			
			case XmlNodeType.Entity:    
				Console.WriteLine( "*** process_nodeType: found Entity!" );
				break;

			case XmlNodeType.EntityReference:    
				Console.WriteLine( "*** process_nodeType: found EntityReference!" );
				break;

			case XmlNodeType.EndEntity: 
				Console.WriteLine( "*** process_nodeType: found EndEntity!" );
				break;
			
			case XmlNodeType.Document: 
				Console.WriteLine( "*** process_nodeType: found Document!" );
				break;
				
			case XmlNodeType.DocumentFragment: 
				Console.WriteLine( "*** process_nodeType: found DocumentFragment!" );
				break;

			case XmlNodeType.DocumentType:    
				Console.WriteLine( "*** process_nodeType: found DocumentType!" );
				break;
		}
	}

	public XmlWrapper( string fn )
	{ 
		fileName = fn; 
		if ( getTextReader() == false )
			throw new Exception( "unable to open" + fileName );
	}

	private bool getTextReader()
	{
		// need to check this succeeds
		fs   = new FileStream( fileName, FileMode.Open );
		x = new XmlTextReader( fs );
		return true;
	}
}



