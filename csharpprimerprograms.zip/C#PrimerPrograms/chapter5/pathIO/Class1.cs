using System;
using System.IO;
using System.Windows.Forms;

class path
{
	public path( string p ){ m_path = p; }
	private string m_path;
	public  string thePath 
	{ 
		get{ return m_path; } 
		set{ m_path = value; }
	}

	public static void FileOpen( string inFile, string outFile )
	{
		FileInfo ifd = new FileInfo( inFile );
		FileInfo ofd = new FileInfo( outFile );

		if ( ifd.Exists && ofd.Exists &&
			((ofd.Attributes & FileAttributes.ReadOnly)==0))
		{
			StreamReader ifile = ifd.OpenText();
			StreamWriter ofile = ofd.CreateText();

			// rest is the same as above
		}
	}

	static public void Main()
	{
		string startupPath = Application.StartupPath;
		string thisDir = startupPath.Substring( 0, startupPath.IndexOf( @"\bin\" )+1 );

		path p = new path( thisDir + @"..\..\textfiles\alice_emma.txt" );

		Console.WriteLine( "The file is named " + Path.GetFileNameWithoutExtension( p.thePath ));

		if ( Path.HasExtension( p.thePath ))
			Console.WriteLine( "It has the extension: " + Path.GetExtension( p.thePath ));

		Console.WriteLine( "The full path is " + Path.GetFullPath( p.thePath ));

		if ( Path.IsPathRooted( p.thePath ))
			Console.WriteLine( "The path root is " + 
				Path.GetPathRoot( p.thePath ));

		string tempDir  = Path.GetTempPath();
		Console.WriteLine( "The temporary director is " + tempDir );
		
		string tempCombine = Path.Combine( tempDir, Path.GetFileName( p.thePath ) );
		Console.WriteLine( "Path of file copy " + tempCombine );

		string tempFile = Path.GetTempFileName();
		Console.WriteLine( "Temporary file is " + tempFile );

		testDirCreateDelete( thisDir + @"subdir\" );
	}

	public static void testDirCreateDelete( string workDir )
	{
		DirectoryInfo wd;

		// create the directory if it does not exist
		if ( ! Directory.Exists( workDir ))
		{
			wd = Directory.CreateDirectory( workDir );
			Console.WriteLine( "ok: created new directory: " + wd.FullName );
		}
		else 
		{
			wd = new DirectoryInfo( workDir );
			Console.WriteLine( "ok: directory exists: " + wd.FullName );
		}
 
		// create a subdirectory
		DirectoryInfo d = wd.CreateSubdirectory( "sub_subdir" );

		d.Delete(); wd.Delete( true );
	}

	public static void testDirProperties( string workDir )
	{
		DirectoryInfo dir = new DirectoryInfo( workDir );
		if ( dir.Exists )
		{
			Console.WriteLine( "Directory full name ", dir.FullName );
    
			// refreshes object -- 
			dir.Refresh();

			// Section 5.5.4 discusses the DateTime class
			DateTime createTime = dir.CreationTime;
			DateTime lastAccess = dir.LastAccessTime;
			DateTime lastWrite  = dir.LastWriteTime;
			// � display these � 

			DirectoryInfo parent = dir.Parent;
			DirectoryInfo root   = dir.Root;

			FileInfo [] has_files = dir.GetFiles();
			DirectoryInfo [] has_directories = dir.GetDirectories();
		}
	}

	public static void displayFileAttributes( FileInfo fd )
	{
		// Attributes returns a FileAttributes object
		FileAttributes fs = fd.Attributes;

		// use bitwise operators to see if attribute is set
		if (( fs & FileAttributes.Archive ) != 0 )
			Console.WriteLine( "Ok: is archived" ); 

		if (( fs & FileAttributes.ReadOnly ) != 0 )
			Console.WriteLine( "Ok: is readonly" );

		// � and so on �

		fd.Attributes -= FileAttributes.ReadOnly; 

	}
}
