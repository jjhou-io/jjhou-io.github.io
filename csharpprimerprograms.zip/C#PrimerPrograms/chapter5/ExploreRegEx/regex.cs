using System;
using System.Text;
using System.Text.RegularExpressions;

class EntryPoint
{
	static void Main()
	{
		Console.WriteLine( "ExploreRegEx begin ... " );
		ExploreRegEx.testOneFilter( 0 );
		ExploreRegEx.testUserFilter();
		ExploreRegEx.testAllFilter();

		ExploreRegEx.testSplit();
		ExploreRegEx.testReplace();
		Console.WriteLine( "ExploreRegEx end ... " );
	}
}
class ExploreRegEx
{
	
    static string inputString = "r2d2";
	static string filter = @"\d";

	static string [] inputs = 
	{
		"a21d2",
		"r2 d2",
		// "5040 bez(99,-3.94,43,8.84)",
	};

	static string [] filters = 
	{
		@"\d+",
		@"^\d+",
		@"\D+",
		@"\\w+",
		@"(a|b|c|d)+",
		"\\w\\d+\\w\\d+",
		".*?",
		"\\s",
		"\\S",

		/*
		"(-*\\d+\\.\\d+|-*\\d+)\\s\\'*\\s*bez\\((-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+)",
		"(-*\\d+\\.\\d+|-*\\d+)\\s",
		"(?:<1>(-*\\d+\\.\\d+)|(-*\\d+))\\s",

		"(?<1>(-*\\d+\\.\\d+)|(-*\\d+))\\s\\'*\\s*bez\\((?<2>(-*\\d+\\.\\d+)|(\\d+)),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+),(-*\\d+\\.\\d+|\\d+)",
		*/
	};

	public string String 
	{
		get{return inputString;}
		set{inputString = value;}
	}

	public string Filter 
	{
		get{return filter; }
		set{filter = value;}
	}

	public static void sayGoodbye()
	{
	    /// TODO : reportStats();
		Console.WriteLine( "OK. Bye." ); 
	}

	public static bool getString( bool check_filter )
	{
		Console.Write( "Would you like to enter a string to match against? (Y/N/? )\n\t ==> " );
		
		string rsp = Console.ReadLine();

		if ( rsp[ 0 ] == '?' ){
			Console.WriteLine( "Current string is {0}", inputString );
			return getString( check_filter ); 
		}
		
		if ( rsp[ 0 ] == 'Y' || rsp[ 0 ] == 'y' )
		{
			Console.Write( @"Please enter a string, or 'quit' to exit.\n\t==> " );

		    inputString = Console.ReadLine();
		    if ( inputString.Equals( "quit" ))
			     return false;
		}
	
		if ( check_filter )
		     checkForFilter();

		Console.WriteLine( "OK. Matching the regular expression: {0}", filter );
		return true;
	}

	public static void checkForFilter()
	{
		Console.Write( "Would you like to change regular expressions? (Y/N/?)" );
		string rsp = Console.ReadLine();
		if ( rsp[ 0 ] != 'y' && rsp[ 0 ] != 'y' && rsp[ 0 ] != '?' )
		     return;

		if ( rsp[ 0 ] == '?' ){
			Console.WriteLine( "Current regular expression is {0}", filter );
			checkForFilter(); return;
		}
		     
		Console.Write( "Please enter regular expression:\n\t**> " );
		filter = Console.ReadLine();
	}

	public static void testOneFilter( int index )
	{
		filter = filters[ index ]; // should check
		while ( getString( false ) )
			    doMatch();

		sayGoodbye();
	}

	public static void testAllFilter()
	{
		foreach ( string instring in inputs )
		{
			inputString = instring;
			foreach( string infilter in filters )
			{
				filter = infilter;
				doMatch();
			}
		}
		            
		sayGoodbye();
	}

	public static void testUserFilter()
	{
		while ( getString( true ))
		        doMatch();
			    
		sayGoodbye();
	}

    public static void doMatch()
	{
			Console.WriteLine( "original string:  {0}", inputString );
			Console.WriteLine( "attempt to match: {0}", filter );

            Regex regex = new Regex( filter );
			Match match = regex.Match( inputString );

		    if ( ! match.Success )
			{
				Console.WriteLine( "Sorry, no match of {0} in {1}",
					               filter, inputString );
				return;
			}

			// CaptureCollection capcol = match.Captures;
			// Console.WriteLine( "There were {0} matches: {1}", capcol.Count, capcol[0] );

            // foreach (string subString in theRegex.Split(s1))
			
			for ( ; match.Success; match = match.NextMatch() )
            {

                Console.WriteLine( "The characters {0} match beginning at position {1}", 
					                match.ToString(), match.Index );
									// match.Group(1).ToString(), match.Group(1).Index );
				// Console.WriteLine( "match #2: {0} at {1}",
									// match.Group(2).ToString(), match.Group(2).Index );

            }
}

	public static void testReplace()
	{
		 string re = "XP.\\d+";
		 Regex regex = new Regex( re );

		 string textLine = 
			 "XP.109 is currently in alpha. XP.109 represents a leap forward";

		 string replaceWith = "ToonPal";
		 
		 Console.WriteLine ( "original text: {0}", textLine );
		 Console.WriteLine ( "regular expresion : {0}", re );
		 Console.WriteLine ( "replacement text: {0}", 
			                  regex.Replace( textLine, replaceWith ));

		/*
		 original text: XP.109 is currently in alpha. XP.109 represents a leap forward
		 regular expresion : XP.\d+
		 replacement text: 
		     ToonPal is currently in alpha. ToonPal represents a leap forward 
		 */
    }

	public static void testSplit( /* string textLine, string splitMe */ )
	{
		string line = "Danny%Lippman%%Point Guard%Shooting Guard%%floater";
		string splitMe = "%+";
		Regex regex = new Regex( splitMe );
		
		foreach ( string capture in regex.Split( line ))
		    Console.WriteLine( "capture: {0}", capture );

		/*
		capture: Danny
		capture: Lippman
		capture: Point Guard
		capture: Shooting Guard
		capture: floater
		*/
	}
            
}