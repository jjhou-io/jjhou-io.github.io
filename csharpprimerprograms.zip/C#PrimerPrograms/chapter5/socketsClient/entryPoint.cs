using System;

public class EntryPoint
{
	public static void Main( string [] args )
	{
		Console.WriteLine( "!! Beginning: client side of socket demo ... " );
	
		string name;
		if( args.Length == 0 )
		{
			Console.WriteLine( "Usage: SocketsClient <name>" );
			Console.Write( "Please enter name to look up : ") ;
			name = Console.ReadLine();
			Console.WriteLine();
		}
		else name = args[0];
		
		Console.WriteLine( "Client: About to access socket server with name: " + name );
		Console.WriteLine( "Client: Time now: " + DateTime.Now.ToShortDateString() + 
			" " + DateTime.Now.ToShortTimeString()+ "\n" );

		SocketsClient sdc = new SocketsClient();
		sdc.sendRequest( name );

		Console.WriteLine( "!! Ending: client side of socket demo ... " );
	}
}