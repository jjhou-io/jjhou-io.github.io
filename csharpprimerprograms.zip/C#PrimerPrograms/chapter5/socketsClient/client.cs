using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class SocketsClient 
{
	private TcpClient theClient;
	const   int       port = 4554;
	const   int       packet_limit = 128;

	public bool sendRequest( string name )
	{
		theClient = new TcpClient( "localhost", port );
		Console.WriteLine( "Client[{0}]: got TCPClient: {1}",
			                port, theClient.ToString() );
				
		NetworkStream netstream = theClient.GetStream();
		Console.WriteLine( "Client[{0}]: got NetworkStream: {1}",
			                port, netstream.ToString() );

		if( ! netstream.CanWrite ) 
		{
			Console.WriteLine( "Client[{0}]: ?? Can't Write NetworkStream ", 
				                port, netstream.ToString() );
			theClient.Close();
			return false;
		}
			
		Console.WriteLine( "\nClient[{0}]: OK: about to write name to server stream.", port );

		Byte[] outPacket = 
			   System.Text.Encoding.ASCII.GetBytes( name.ToCharArray() );

		netstream.Write( outPacket, 0, outPacket.Length) ;
		netstream.Flush() ;
		
		while( ! netstream.DataAvailable )
		{ 
			// this receives our response back from the server
			byte[] packet  = new byte[ packet_limit  ];

			// ok: let's grab that puppy ...
			int    byteCnt = netstream.Read( packet, 0, packet_limit );
						
			// unpackage the packet back into a string ...
			string phone_number = System.Text.Encoding.ASCII.GetString( packet );

			// let's wrap up this portion of the demo ...
			Console.WriteLine( "Client[{0}]: OK: read back from the server stream.\n", port );
			Console.WriteLine( phone_number );			

			break;
		}
		
		return true;
	}	
}

		
		

	