
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
	
public class SocketsServer 
{
	static private int port = 4554;
	static private int maxPacket = 128;

	private TcpListener       tcpl;
	private DataSet           ds;
	private DataRowCollection rows;

	public void Start()
	{
		try 
		{
			//start listening on the assigned port
			tcpl = new TcpListener(port) ;
			tcpl.Start();

			Console.WriteLine( "Server[{0}]: OK: started TcpListener ... ",
				port );

			// retrieve the data from the data base ...
			Thread tdata = new Thread( new ThreadStart( retrieveData ));
			tdata.Start();
				
			// start the thread which actually handles a connection ...
			Thread tconnect = new Thread( new ThreadStart( handleConnection ));
			tconnect.Start();
		}
		catch( Exception ex )
		{
			Console.WriteLine( "Oops: Unable to Set Up SocketDemo_Server" );
			Console.WriteLine( ex.ToString() );
		}
	}

	public void retrieveData()
	{
		// A Sorry Note ...
		//
		// there is a change in the connection string elements between the latest version 
		// of .NET which the book is based on and, sigh, the final release version ...
		// 
		// that's just the nature of the beast ...
		//
		// in the program example in the text, this connection string was the ticket:
		// string scon = "server=localhost;uid=sa;pwd=;database=northwind";
		//
		// End of A Sorry Note ...

		string scon = "server=localhost;Integrated Security=SSPI;database=northwind"; 
		string scmd = "SELECT * FROM Employees";
		SqlConnection sqlconn = new SqlConnection( scon );
		SqlDataAdapter sqlcmd = new SqlDataAdapter( scmd, sqlconn );

		ds = new DataSet();
		sqlcmd.Fill(ds);
		rows = ds.Tables[0].Rows;

		Console.WriteLine( 
            "Server[{0}]: OK: retrieved SQL database info ... ",
			 port );
	}
		
	public void handleConnection()
	{
		Console.WriteLine( 
			"Server[{0}]: OK: actively listening for connections ... ",
			 port );

		// this holds recently requested phone numbers
		Hashtable cache = new Hashtable();

		while( true )
		{
			Socket aSocket = tcpl.AcceptSocket();

			if( aSocket.Connected )
			{
				Console.WriteLine( "Server[{0}]: " +
								   "OK: a client connected ...", port );

				// the Byte array will receive the packet of data from the Client
				Byte [] packetBuffer = new Byte[ maxPacket ];

				// ok. here is the call to receive the packet ...
				int byteCnt = aSocket.Receive( packetBuffer, packetBuffer.Length, 0 );

				// now we have to pull it out ...
				string clientPacket = System.Text.Encoding.ASCII.GetString( packetBuffer );

				// let's get rid of any unused buffer space ...
				// yes, this could probably be done smarter ... 
				//      but this is just a demo after all ...

				char [] unusedBytes = { (char)clientPacket[ byteCnt ] };
				clientPacket = clientPacket.TrimEnd( unusedBytes );

				// announce ourselves to dramatize the demo nature of the thing ...
				Console.WriteLine( "Server[{0}]: " + 
				                   "OK: client requested phone # for {1}", 
					                port, clientPacket );

				string result   = " Sorry. Cannot be found.";
				string response = "Server[" + port.ToString() + 
									   "]: Phone number for " + clientPacket + ": ";

				/*
				 * to illustrate a Hashtable : we cache recent requests 
				 *    
				 *    for each request, we check the cache
				 *    then, if not cached, the data table
				 */

				if ( cache.ContainsKey( clientPacket ))
				{
					Console.WriteLine( "Server[{0}]: " +
									   "OK: cached request for {1}", 
										port, clientPacket );

					result = cache[ clientPacket ].ToString();
				}	
				else 
				{
					Console.WriteLine( "Server[{0}]: " + 
									   "OK: first request for {1}", 
										port, clientPacket );

					foreach ( DataRow c in rows )
					{
						string lastName = c["LastName"].ToString();
						if ( lastName.Equals( clientPacket ) )
						{
							result = c["HomePhone"].ToString();
							cache[ clientPacket ] = result;
							break;
						}	 
					}
				}
					
				response += result;
				Console.WriteLine( response ); 

				// Convert to byte array in preparation for sending ...
				Byte [] resultBuffer = System.Text.Encoding.ASCII.GetBytes( response.ToCharArray() );

				// ok: let's kick back our response ...
				aSocket.Send( resultBuffer, resultBuffer.Length, 0 );
			}
		}
	}
	
}
		