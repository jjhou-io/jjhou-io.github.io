public class EntryPoint
{
	public static void Main()
	{
		SocketsServer theServer = new SocketsServer();
		theServer.Start();
	}
}