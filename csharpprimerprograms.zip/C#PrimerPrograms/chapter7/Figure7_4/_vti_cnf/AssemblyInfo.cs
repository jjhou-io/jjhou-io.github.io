vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_PROUST
vti_modifiedby:SR|IUSR_PROUST
vti_timecreated:TR|02 Nov 2001 17:16:24 -0000
vti_timelastmodified:TR|02 Nov 2001 17:16:24 -0000
vti_cacheddtm:TX|02 Nov 2001 17:16:26 -0000
vti_filesize:IR|2781
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
