using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Figure7_4
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ListBox ListBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;

		protected int AnnaCount;
		protected static int PoohCount;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label6;
		protected int MissCount;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.TextBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			// x & y hot zones for the image
			int [] AnnaZone = { 302, 388, 75, 194 };
			int [] PoohZone = { 62, 196, 108, 301 }; 

			string coords =  
				e.X.ToString() + ":" + e.Y.ToString();

			// ok: simple test of hit or miss �
			if ( e.X >= AnnaZone[0] && e.X <= AnnaZone[1] &&
				e.Y >= AnnaZone[2] && e.Y <= AnnaZone[3] )
			{ 
				coords += " : Anna"; 
				this.AnnaCount++;
				Label4.Text = "Anna hits: " + this.AnnaCount.ToString();
			}
			else 
				if ( e.X >= PoohZone[0] && e.X <= PoohZone[1] &&
				e.Y >= PoohZone[2] && e.Y <= PoohZone[3] )
			{ 
				coords += " : Pooh"; 
				PoohCount++;
				Label5.Text = "Pooh hits: " + PoohCount.ToString();
			}
			else { 
				coords += " : Ha! Missed";
				this.MissCount++;
				Label6.Text = "Misses -- ha!: " + this.MissCount.ToString();
			} 

			ListBox1.Items.Add( coords );
		}

		private void TextBox1_TextChanged(object sender, System.EventArgs e)
		{
			Label2.Text = "Hello, " + TextBox1.Text;
			TextBox1.Visible = false;
			Label1.Visible = false;
		}
	}
}
