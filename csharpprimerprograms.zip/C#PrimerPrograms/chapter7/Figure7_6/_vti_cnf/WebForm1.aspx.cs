vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_PROUST
vti_modifiedby:SR|IUSR_PROUST
vti_timecreated:TR|02 Nov 2001 09:07:13 -0000
vti_timelastmodified:TR|02 Nov 2001 16:18:44 -0000
vti_filesize:IR|2356
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|02 Nov 2001 16:15:26 -0000
vti_cacheddtm:TX|02 Nov 2001 16:18:46 -0000
