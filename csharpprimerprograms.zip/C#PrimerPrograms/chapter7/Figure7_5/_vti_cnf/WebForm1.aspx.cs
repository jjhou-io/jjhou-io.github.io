vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_PROUST
vti_modifiedby:SR|IUSR_PROUST
vti_timecreated:TR|02 Nov 2001 09:59:21 -0000
vti_timelastmodified:TR|02 Nov 2001 17:00:54 -0000
vti_filesize:IR|3758
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|02 Nov 2001 16:56:14 -0000
vti_cacheddtm:TX|02 Nov 2001 17:00:56 -0000
