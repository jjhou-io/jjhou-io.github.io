#define DEBUG

using System;
using System.Reflection;
using System.Diagnostics;
namespace tester 
{
	public class test
	{
	    // a pointer to function returning void and no params, 
	    // but it can address multiple methods from any class   
		public delegate void testRun();

	    // the actual delegate object ...
		static private testRun md_tester;

	    // the public property: users access it with object syntax
	    // the methods implicitly invoked ...
		static public  testRun Tester {
			   get{ return md_tester; }
			   set{ md_tester = value; }
		}

		static private void reSet() { md_tester = null; }
		static public  int  count() 
		       { return md_tester != null ? md_tester.GetInvocationList().Length : 0; }

		[Conditional( "DEBUG" )]
		public static void message( string msg, params object[] args )
		{
			Console.Write( msg );
			for ( int ix = 0; ix < args.Length; ++ix )
				  Console.Write( "\t{0}", args[ ix ] );
			Console.WriteLine();
		} 

		public static void run()
	    {
	        // how many methods does it actually address?
			int testCount = Tester != null 
				             ? Tester.GetInvocationList().Length : 0;

			Console.WriteLine( "test.run(): about to run {0} tests\n", testCount );

			if ( Tester != null )
			{
				// ok: execute all the methods it addresses
				Tester();

				// ok: now reset it to null
				reSet();
			}

			Console.WriteLine( "\ntest.Main(): {0} tests ran", testCount );
	    }

		static test()
		{
			// need to force the static constructor of each of our classes
			// in order to have the tests added to the delegate ...

			message( "CurrentDomain.GetAssemblies()" );

		    AppDomain appdomain = AppDomain.CurrentDomain;
		    Assembly [] assemblies = appdomain.GetAssemblies();

		    foreach ( Assembly a in assemblies )
			{
				 message( "GetAssembly() -- full name: ", a.FullName );

				 int pos = a.FullName.IndexOf( ',' );
				 string name = a.FullName.Substring(0, pos);

				 message( "assembly name: ", name );

				 // note: this is insufficient for production code
				 //       either need a table of system assemblies
				 //       or else modify tester to take assembly names

				 if ( name.Equals( "tester" ))    continue;
                 if ( name.Equals( "mscorlib" ))  continue;

				 message( "assembly name: ", name, "contains the types: " ); 
				   
				 Type [] t = a.GetTypes();
				 foreach ( Type tt in t )
				 {
					message( "\tTypeName: ", tt.FullName, "-- ",  tt.Name );
				    Activator.CreateInstance( tt );
				 }
			} // foreach assembly 
		}     // static constructor
	}         // class test
}             // namespace tester

