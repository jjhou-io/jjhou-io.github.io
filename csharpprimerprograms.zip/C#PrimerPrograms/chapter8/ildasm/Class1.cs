namespace ildasmDemo
{
	// Note: The purpose of this is to generate a
	//       binary that you can examine with ildasm

    using System;
	using structSpace;
	using classSpace;
	using classHierSpace;
	using System.Collections;

	enum stats { one, two, three };

    public class EntryPoint
    {
        public static int Main()
        {
			Console.WriteLine( "ildasm: generating exe to examine using ildasm" );
            structDef sd = new structDef( 1, 2, 3 );
			classDef  cd = new classDef( 1, 2, 3 );

			classBase cb = new classDer();
			bool ok = cb.isValid( "guest" );
			if ( ok )
				 cb.Normalize();
			
			int    ival = 1024;
			float  fval = 3.14159f;
			double dval = 3.14159;

			dval = 3.14159f;
			dval = fval;
			
			stats st = stats.one;

			int [] arrval = { 3, 5, 8 };
			int [,] matrix = {{0, 1}, {0,1}};
				 
			ArrayList al = new ArrayList( arrval );

			for ( int ix = arrval.Length-1, iy = al.Count-al.Count;
				  ix >= iy; --ix, ++iy )
			{
				al[ iy ] = al[ ix ];
				arrval[ iy ] = arrval[ ix ];
			}
				  
			int ixx;
			al[0] = 1;// box integer constant
			arrval[ 0 ] = 1;

			ixx = (int) al[0];// unbox object
			ixx = arrval[ 0 ];

            return 0;
        }
    }

} /// namespace ildasmDemo

namespace structSpace
{
	public struct structDef
	{
		static structDef()
		{
			ms_ival2 = new int[ 10 ]{ 1, 1, 2, 3, 5, 8, 13, 21, 34, 55 };
			ms_ival3 = ms_ival2[ 2 ];
		}

		public structDef( int one, int two, int three )
		{
			m_ival1 = one;
			m_ival2 = new int[ two ];
			m_ival3 = ( three >= 0 ) && ( three < ms_ival2.Length )
				        ? ms_ival2[ three ] : ms_ival3 * three;
		}

		internal int m_ival1;
		public   int [] m_ival2;
		private  int m_ival3;

		static internal int ms_ival1 = 1024;
		static public   int [] ms_ival2;
		static private  int    ms_ival3;

	}

} /// namespace structSpace


namespace classSpace
{
	public class classDef
	{
		static classDef()
		{
			ms_ival2 = new int[ 10 ]{ 1, 1, 2, 3, 5, 8, 13, 21, 34, 55 };
			ms_ival3 = ms_ival2[ 2 ];
		}

		public classDef( int one, int two, int three )
		{
			m_ival1 = one;
			m_ival2 = new int[ two ];
			m_ival3 = ( three >= 0 ) && ( three < ms_ival2.Length )
				        ? ms_ival2[ three ] : ms_ival3 * three;
		}

		internal int m_ival1;
		public   int [] m_ival2;
		private  int m_ival3;

		static internal int ms_ival1 = 1024;
		static public   int [] ms_ival2;
		static private  int    ms_ival3;

	}

} /// namespace classSpace

namespace classHierSpace
{
	interface inter
	{
		bool isValid( string id );
		string Id { get; set; }
	}

	public class classBase : inter
	{
		public  static int ms_cnt;
		private string     m_id;
		
		public string Id { get { return m_id; } set { m_id = value; }}

		static classBase(){ ms_cnt = 0; }
		public classBase( string id ){ ms_cnt++; m_id = id; }
		
		virtual public bool isValid( string id )
		{ Normalize(); return m_id.CompareTo( id ) == 0; } 

		public virtual void Normalize(){ m_id.ToLower(); } 
	}

	public class classDer : classBase
	{
		private string m_name;
		public string Name { get { return m_name; } set { m_name = value; }}

		public classDer( string id, string name )
			   : base( id ){ m_name = name; }

		public classDer() : this( "guest", "guest" ){}
		public override void Normalize(){ base.Normalize(); m_name.ToLower(); }

		override public bool isValid( string name )
		{ Normalize(); return m_name.CompareTo( name ) == 0; } 
			 
	}

} /// namespace classHierSpace
