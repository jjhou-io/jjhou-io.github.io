using System;
using System.IO;

public class EntryPoint
{
	public static void Main()
	{
		Console.WriteLine( "Beginning test of timer ... \n" );

		timer t   = new timer();
		t.context = "reading in a file and echoing it to console ";
		t.start();

		StreamReader ifile = File.OpenText( @"c:\fictions\gnome.txt" );

		string textline; 
		int    lineCnt = 0;

		while (( textline = ifile.ReadLine()) != null )
		{
			if ( lineCnt++ == 0 )
				 Console.WriteLine( "\t\t{0}\n", textline );
			
			Console.WriteLine( textline );
		}

		t.stop();
		Console.WriteLine( t.ToString() );

		Console.WriteLine( "Ending test of timer ...\n"     );
	}
}
