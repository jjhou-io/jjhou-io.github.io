using System;

// timer class is a modification of an interface
// over an implementation Eric Gunnerson, author
// of A Programmer's Introduction to C#, kindly
// shared with me.

public class timer 
{
		private long   elapsedCount;
		private long   startCount;
		private string m_context;

		public  string context
		{
			get{ return m_context;  }
			set{ m_context = value; }
		}

		public void start()
		{
			startCount = 0;
			QueryPerformanceCounter( ref startCount );
		}
		
		public void stop()
		{
			long stopCount = 0;
			QueryPerformanceCounter( ref stopCount );

			elapsedCount = (stopCount - startCount);
		}

		public void lap()
		{
			long stopCount = 0;
			QueryPerformanceCounter( ref stopCount );

			elapsedCount += (stopCount - startCount);
		}
	
		public void clear()
		{
			elapsedCount = 0;
		}

		public override string ToString()
		{
		    long freq = 0;
			QueryPerformanceFrequency( ref freq );
			float seconds = (float) elapsedCount / (float) freq;

			return context + " : " + seconds.ToString() + " secs.";
		}

		[System.Runtime.InteropServices.DllImport("KERNEL32")]
		private static extern bool QueryPerformanceCounter(  ref long lpPerformanceCount);

		[System.Runtime.InteropServices.DllImport("KERNEL32")]
		private static extern bool QueryPerformanceFrequency( ref long lpFrequency);                     
}


