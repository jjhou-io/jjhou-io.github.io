using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;

public class EntryPoint 
{
	public static void Main()
	{
		Console.WriteLine( "Assembly Exploration begin ... " );
		AssemblyExplore.getAssemblies();
		Console.WriteLine( "Assembly Exploration end ... " );
	}
}

public class AssemblyExplore
{
	[Conditional( "DEBUG" )]
	public static void message( string msg, params object[] args )
	{
		Console.Write( msg );
		for ( int ix = 0; ix < args.Length; ++ix )
			  Console.Write( " {0} ", args[ ix ] );
		Console.WriteLine();
	} 

	public static void getAssemblies()
	{
		AppDomain theApp = AppDomain.CurrentDomain;
		Assembly [] currAssemblies = theApp.GetAssemblies();
		Console.WriteLine( "The current AppDomain has {0} Assemblies", 
			                currAssemblies.Length );

		foreach ( Assembly a in currAssemblies )
		{
			 message( "\nThe Assembly FullName Property: \n\t", a.FullName );

			 int     pos  = a.FullName.IndexOf( ',' );
			 string  name = a.FullName.Substring(0, pos);
			 Type [] t    = a.GetTypes();

			 // Gets the location of the loaded file that contains 
			 //      the manifest.
			 string     manifestLocation = a.Location;
			 MethodInfo theEntry         = a.EntryPoint;

			 message( "assembly name:   ", name );
			 message( "manifest loc:    ", manifestLocation );
			 message( "entry point:     ", 
				       theEntry != null ? theEntry.ToString():"Not Defined"  );
			 message( "number of types: ", t.Length ); 

			  
			 if ( t.Length < 10 )
				  Console.WriteLine( "The types contained within the assembly are: " );
			 else Console.WriteLine( "The first 10 types contained within the assembly are: " );
			 
			 int cnt = 0;
			 foreach ( Type tt in t )
			 {
				       message( "\ttype name: ", tt.Name );
					   if ( ++cnt == 10 ) 
						    break;
			 }
		} 
	}
}


