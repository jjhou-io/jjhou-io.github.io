using System;
using System.Reflection;
using System.Diagnostics;
using System.Collections;

/*
 * Note: this project depends on loading this dll
 *       it must be built under tester
 *       then the dll under bin/tester.dll must be
 *       added to the references ...
 */

using tester;

// should change these to write to a file
// best perhaps by creating two display classes
//      1. ConsoleDisplay
//      2. FileDisplay

public class EntryPoint
{
	public static void Main()
    {
		Console.WriteLine( "EntryPoint.Main(): about to run " );
		test.run();
		Console.WriteLine( "EntryPoint.Main(): about to run " );
    }
}

public class testBitArray
{
	static testBitArray()
	{
		test.Tester += new test.testRun( testBasics );
	}

	static public void testBasics()
	{
		Console.WriteLine( "testBitArray::testBasics()" );

		BitArray mbit = new BitArray( 16, true );
		for ( int frame = 1; frame < 12; ++frame )
		{
               mbit.SetAll( false );
               for ( int ix = 0; ix < 16; ++ix ) {
	                 if (( ix % 2 ) != 0 ) 
	                      mbit[ ix ] = true;
			   }
		}

		for ( int frame = 1; frame < 12; ++frame )
		{
			Console.Write( "{0}", mbit[ frame ] ? '1' : '0' );
		}
    }
}

public class testHashtable
{
	static private Hashtable ms_ahash;
	private static readonly string [] ms_words = s.Split( null );

private const string s = @"MooCat is a long-haired white kitten with large black patches 
like a cow looks only he is a kitty poor kitty Alice says cradling MooCat in her arms 
pretending he is not struggling to break free MooCat is a present to Alice from her 
parents so that Alice does not feel so alone since their move here from New York City 
to Tucson only she does Aice Emma has long flowing red hair her father says when the 
wind blows through her hair it looks almost alive like a fiery bird in flight a beautiful 
fiery bird he tells her magical but untamed Daddy shush there is no such thing she tells 
him at the same time wanting him to tell her more shyly she asks I mean Daddy is there";

	static testHashtable()
	{
		// test.Tester += new test.testRun( testBasics );
	}

	private static void displayTableSort()
	{
		ArrayList aKeys = new ArrayList( ms_ahash.Keys );
		aKeys.Sort();
		foreach ( string key in aKeys )
			Console.WriteLine( "{0} :: {1}", key, ms_ahash[ key ] );
	}

	private static void displayTable()
	{
		Console.WriteLine( "Hashtable has {0} entries", ms_ahash.Count );
		IDictionaryEnumerator ie = ms_ahash.GetEnumerator();

		while ( ie.MoveNext() )
			    Console.WriteLine( "{0} :: {1}", ie.Key, ie.Value );
	}

	static public void testBasics()
	{
		Console.WriteLine( "!! Begin: testHashtable.testBasics()\n" );

		Console.WriteLine( "word count: {0}", ms_words.Length );

		ms_ahash = new Hashtable();
		
		foreach( string s in ms_words )
		{
			if ( s == String.Empty )
				 continue;

			if ( ms_ahash[ s ] == null )
				 ms_ahash[ s ] = 1;
			else ms_ahash[ s ] = (int)ms_ahash[ s ] + 1; 
/*
			if ( ! ms_ahash.Contains( s ))
				   ms_ahash[ s ] = 1; 
				// or:  ms_ahash.Add( s, 1 );
		    else   ms_ahash[ s ] = (int)ms_ahash[ s ] + 1; 
*/
			
		}
      
		Console.WriteLine( "Display key/value pair in hash order" );
		displayTable();

		Console.WriteLine( "Display key/value pair in key sorted order" );
		displayTableSort();

		Array tabl = Array.CreateInstance( typeof(int), ms_ahash.Count );
		ms_ahash.CopyTo( tabl, 0 );
		
		Console.WriteLine( "\n!! End:   testHashtable.testBasics()" );
	}
}

public class testArrayList
{
	static private ArrayList ms_alist;
	
	static testArrayList()
	{
		test.Tester += new test.testRun( testBasics );
		// test.Tester += new test.testRun( testCapacity );
	}

	static public void displayList()
	{
		Console.WriteLine();
		// foreach ( string str in ms_alist ) Console.WriteLine( str );

		for ( int ix = 0; ix < ms_alist.Count; ++ix )
		      Console.WriteLine( ms_alist[ ix ] );

		Console.WriteLine();
	}

	static private void testTrim()
	{
		Console.WriteLine( "\nAbout to trim arraylist to size" );

		Console.WriteLine( "Before trim: Count: {0} Capacity: {1}",
						            ms_alist.Count, ms_alist.Capacity );

		ms_alist.TrimToSize();

		Console.WriteLine( "After trim: Count: {0} Capacity: {1}",
						            ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "Now about to Add an element" );
		ms_alist.Add( 0 );

		Console.WriteLine( "Count: {0} Capacity: {1}",
						            ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "OK: About to re-trim arraylist" );

		ms_alist.TrimToSize();

		Console.WriteLine( "After re-trim: Count: {0} Capacity: {1}",
						            ms_alist.Count, ms_alist.Capacity );
	}

	static private void removeElements( int count )
	{
		if ( count > ms_alist.Count || count < 1 )
			 count = ms_alist.Count;

		Console.WriteLine( "\nAbout to remove {0} elements", count );

		Console.WriteLine( "Before removals: Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		ms_alist.Remove( ms_alist[ --count ] );

		Console.WriteLine( "Remove a single object: Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		ms_alist.RemoveAt( --count );

		Console.WriteLine( "RemoveAt a single index: Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		ms_alist.RemoveRange( 0, count );

		Console.WriteLine( "RemoveRange: Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

	}

    static private void addElements()
	{
		int capacity = ms_alist.Capacity;

		for ( int ix = 0; ix < 10000; ++ix )
		{
			ms_alist.Add( ix );
			if ( ms_alist.Count > capacity )
			{
				 capacity = ms_alist.Capacity;
		         Console.WriteLine( "Count: {0} Capacity: {1}",
						             ms_alist.Count, ms_alist.Capacity );
			}
		}
	}

	static public void testCapacity()
	{
		Console.WriteLine( "!! Begin: testArrayList.testCapacity()\n" );
		ms_alist = new ArrayList();

		Console.WriteLine( "Default capacity for empty ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		addElements();
		testTrim();
		removeElements( 100 );

		ms_alist.Clear();
		Console.WriteLine( "\nClear ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		addElements();

		const int fixedCapacity = 512;
		ms_alist = new ArrayList( fixedCapacity );

		Console.WriteLine( "\nExplicit capacity set for empty ArrayList\n" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		addElements();

		Console.WriteLine( "\n!! End:   testArrayList.testCapacity()\n" );
	}

	static public void testBasics()
	{
		Console.WriteLine( "!! Begin: testArrayList.testBasics()\n" );

		string [] s = { 
			"O, beware, my lord, of jealousy",
			"It is the green-eyed monster, which doth mock",
			"The meat it feeds on." };

		string [] t = {
			@"Life's but a walking shadow; a poor player,",
			"That struts and frets his hour upon the stage",
			"And then is heard no more: it is a tale",
			"Told by an idiot, full of sound and fury,"
		};

		// initialize ArrayList from a built-in array
		ms_alist = new ArrayList( s ); displayList();

		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );

		Console.WriteLine( "adding one element: note capacity!" );
		ms_alist.Add( "Out, out, brief candle" );

		Console.WriteLine( "Count: {0} Capacity: {1}",
							ms_alist.Count, ms_alist.Capacity );
		
		Console.WriteLine( "adding range of 4 elements: note capacity!" );
		ms_alist.AddRange( t ); 

		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );
		displayList();

		Console.WriteLine( "ArrayList.Reverse(): " );
		ms_alist.Reverse(); displayList();

		Console.WriteLine( "ArrayList.Sort(): " );
		ms_alist.Sort(); displayList();

		string st = t[ 1 ];
		if ( ms_alist.Contains( st ))
			 Console.WriteLine( "found at index "  +
				                ms_alist.IndexOf( st ).ToString() + 
								" : " + st );
		
		Console.WriteLine( "\nAbout to turn ArrayList into Array" );
		Console.WriteLine( "Count: {0} Capacity: {1}",
						    ms_alist.Count, ms_alist.Capacity );
		Array newArray = ms_alist.ToArray( st.GetType() );
		Console.WriteLine( "ToArray: {0} elements", newArray.Length );

		Console.WriteLine( "\nAbout to generate a fixed size ArrayList" );
		ms_alist.TrimToSize();
		ArrayList newList = ArrayList.FixedSize( ms_alist );
		Console.WriteLine( "Count: {0} Capacity: {1}",
						    newList.Count, newList.Capacity );

		Console.WriteLine( "\n!! End:   testArrayList.testBasics()" );
	}
	
}
 


