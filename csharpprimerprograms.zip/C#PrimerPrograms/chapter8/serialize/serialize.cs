using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

// Add serialization to some existing classes ... matrix/vector ...
public class EntryPoint
{
	public static void Main()
	{
		Matrix m = new Matrix( 4, 4, 42.0f);
		m.ToDisk();
		Matrix m2 = new Matrix( "matrix.bin" );
		m2.displaySelf();
	}
}
[ Serializable ]
class Matrix
{
	[ NonSerialized ]
	private string out_stream;

    float [,] mat;
	DateTime  dat;

	public void displaySelf()
	{
		Console.WriteLine( "file: {0}", out_stream );
		Console.WriteLine( "date: {0}", dat.ToLongTimeString() );
		
		Console.Write( "({0},{1}) ", mat.GetLength(0), mat.GetLength(1) );
		foreach ( float f in mat ) Console.Write( "{0} ", f );
		Console.WriteLine();
	}

	public Matrix( string file_name )
	{ FromDisk( file_name ); }

	public Matrix( int col, int row ){ mat = new float[ col, row ]; }
    public Matrix( int col, int row, float val )
	{
		mat = new float[ col, row ];
		for ( int ix = 0; ix < col; ++ix )
			for ( int iy = 0; iy < row; ++iy )
			    mat[ix,iy] = val;
	}

	public string OutStream
	{
		get{ return out_stream; }
		set{ out_stream = value; }
	}

	public void ToDisk() 
	{
		// remember, this guy is not serialized ...
		if ( out_stream == null )
			 out_stream = "matrix.bin";
		
		Stream s = new FileInfo( out_stream ).Open(FileMode.Create);
		BinaryFormatter bfm = new BinaryFormatter();

		dat = DateTime.Now;
		Console.WriteLine( "setting the date: {0}", dat.ToLongTimeString() );

        bfm.Serialize( s, this );
		s.Close();
	}

	public void FromDisk( string filename ) 
	{
        Stream s = (new FileInfo (filename)).Open(FileMode.Open);
        BinaryFormatter bfm = new BinaryFormatter();
        Matrix m = (Matrix) bfm.Deserialize(s);
		s.Close();
		mat = m.mat;
		dat = m.dat;

		// We declared this as NonSerialized, recall ...
		out_stream = filename; 
	}
}