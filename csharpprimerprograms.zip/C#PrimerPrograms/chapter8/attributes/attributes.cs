using System;
using System.Reflection;

class EntryPoint 
{
	static public void Main()
	{
		Console.WriteLine( "Beginning Main() entry point ... \n" );

		string msg = "Ato to writeline: {0} :: version {1:F}";
	    Console.WriteLine( msg, "ffo", 1024 );

		testAttributes ta = new testAttributes();

		AttributeExercise.retrieveClass1( ta );
		Console.WriteLine();
		AttributeExercise.retrieveClass2( ta );
		Console.WriteLine();
		AttributeExercise.retrieveMembers( ta );


		Console.WriteLine( "\nEnding Main() entry point ... " );
		
	}
}

public class AttributeExercise
{
	static public void retrieveClass1( object obj )
	{
		Type tp = obj.GetType();
		Attribute [] attrs = Attribute.GetCustomAttributes( tp ); �
   
		Console.WriteLine( "There are {0} attributes associated with {1}",
			                attrs.Length, tp );

		foreach( Attribute attr in attrs )
			     if ( attr is AuthorAttribute ){
				      AuthorAttribute auth = (AuthorAttribute) attr;
                      Console.WriteLine( "Author Attribute: {0} :: version {1:F}",
					                      auth.name, auth.version );

					  if ( auth.comment != null )
					       Console.WriteLine( "\t{0}", auth.comment );
			     }

		retrieveMembers( obj );
	}

	static public void retrieveMembers( object obj )
	{
		Type tp = obj.GetType();
		MethodInfo [] mi = tp.GetMethods(); �
   
		Console.WriteLine( "There are {0} methods associated with {1}",
			                mi.Length, tp );

		Type attrType = Type.GetType( "AuthorAttribute" );

		foreach( MethodInfo m in mi )
		{
			object [] attrs = m.GetCustomAttributes( attrType, false );
			Console.WriteLine( "There are {0} attributes associated with {1}",
			                    attrs.Length, m.Name );
			if ( attrs.Length == 0 )
			     continue;

			foreach( object o in attrs )
			     if ( o is AuthorAttribute ){
				      AuthorAttribute auth = (AuthorAttribute) o;
                      Console.WriteLine( "Author Attribute: {0} :: version {1:F}",
					                      auth.name, auth.version );

					 if ( auth.comment != null )
					       Console.WriteLine( "\t{0}", auth.comment );
			     }
		}
	}

	static public void retrieveClass2( object obj )
	{
		Type tp = obj.GetType();
		object [] attrs = tp.GetCustomAttributes( false ); �
   
		Console.WriteLine( "There are {0} attributes associated with {1}",
			                attrs.Length, tp );

		foreach( object o in attrs )
			     if ( o is AuthorAttribute ){
				      AuthorAttribute auth = (AuthorAttribute) o;
                      Console.WriteLine( "Author Attribute: {0} :: version {1:F}",
					                      auth.name, auth.version );
					  if ( auth.comment != null )
					       Console.WriteLine( "\t{0}", auth.comment );
			     }
	}

}

// no longer supports ClassMembers as an AttributeTargets enumerator
[AttributeUsage( AttributeTargets.Method|AttributeTargets.Class, AllowMultiple = true )] 
public class AuthorAttribute: Attribute 
{ 
    public AuthorAttribute( string nm )
           { name = nm; version = 1.0; } 

	public string name 
	{
		get{ return m_name; }
		set{ m_name = value; }
	}

	public double version 
	{
		get{ return m_version;  }
		set{ m_version = value; }
	}

	public string comment 
	{
		get{ return m_comment;  }
		set{ m_comment = value; }
	}
    
	private string m_name;
	private string m_comment;
	private double m_version;
}

[Author( "Anna Lippman", comment = "new hire; first project" )]
[Serializable]
class testAttributes
{
    [Author( "Kenny Meyers", version=2.0, 
              comment = "added threading support" ) ]
    [Author( "Danny Lippman", version=1.1 )]
    static public bool doit(){ return true; }

    [Author( "Kenny Meyers", version=2.0, 
              comment = "extensibility for user" ) ]
    public virtual void display() { /* ... */ }
}


