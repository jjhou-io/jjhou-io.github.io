using System;
using System.Collections;
using System.Reflection;

public struct point {  public float x, y; }
public enum   eNUM  { one, two, three }

class ReflectionEntry
{
	static public BindingFlags lookupAll = 
		BindingFlags.Public | BindingFlags.NonPublic |
	    BindingFlags.Instance | BindingFlags.Static;

	public static void Main()
	{
		Console.WriteLine( "Begin ReflectionEntry ... " );

		simpleTest();
		bindingTest();

		string [] languages = { "COBOL", "C", "C++", "C#", "Perl", "Java" };
		Programmer p = new Programmer( "stan", 27, 22, languages );

		Console.WriteLine( "identifyType ==> Programmer" );
        ExploreReflection.identifyType( p );

        Type t = p.GetType();
		MemberInfo[] membs = t.GetMember( "overloaded" );
		Console.WriteLine( "member retrieved: {0}", membs.Length );

		Console.WriteLine( "identifyType ==> point" );
		ExploreReflection.identifyType( new point() );

		Console.WriteLine( "identifyType ==> eNUM" );
		ExploreReflection.identifyType( new eNUM() );

		Console.WriteLine( "identifyType ==> DateTime" );
		ExploreReflection.identifyType( new DateTime( 1971, 7, 4  ));

		Console.WriteLine( "identifyType ==> 1" );
		ExploreReflection.identifyType( 1 );

		Console.WriteLine( "identifyType ==> person" );
		ExploreReflection.identifyType( new person( "stan", 29 ) );

		Console.WriteLine( "End ReflectionEntry ... " );
	}

	public static void bindingTest()
	{
		string s = "a simple string";
		Type t = s.GetType();
		Type tt = t.GetInterface( "ICloneable" );
		Console.WriteLine( "Interface type: {0} interface? {1}", t.Name, t.IsInterface );

		PropertyInfo [] pi = t.GetProperties( lookupAll );
        Console.WriteLine( "total number of string properties: {0}", pi.Length );

		foreach ( PropertyInfo f in pi )
		{
			Console.WriteLine( "\t{0} :: {1}", f.Name, f.PropertyType );
			ParameterInfo [] pif = f.GetIndexParameters();

			if ( pif.Length == 0 )
			     Console.WriteLine( "\t\tholds the value {0}\n", f.GetValue( s, null ));
		}

		FieldInfo [] fi;

		fi = t.GetFields();
		Console.WriteLine( "number of public string fields: {0}", fi.Length );
		
		fi = t.GetFields( lookupAll );
        Console.WriteLine( "total number of string fields: {0}", fi.Length );

		Console.WriteLine( "The {0} fields are as follows: ", fi.Length );

		foreach ( FieldInfo f in fi )
		{
			Console.Write( "\t{0} :: ", f.Name );
			Console.Write( "{0} ", f.IsPublic ? "public" : f.IsPrivate ? "private" : "unknown" );
			Console.Write( "{0} ", f.IsStatic ? "static" : "" );
			Console.WriteLine();
		}
	}

	public static void simpleTest()
	{
		string s = "A simple string";
		Type t = s.GetType();

		PropertyInfo pi = t.GetProperty( "Length" );
		Console.WriteLine( "{0} is of type {1}", pi.Name, pi.PropertyType ); 
		Console.WriteLine( "Can Read? {0} Can Write? {1}", pi.CanRead, pi.CanWrite );
		Console.WriteLine( "Actual value is {0}", pi.GetValue( s, null ));

		PropertyInfo [] parray = t.GetProperties();
		Console.WriteLine( "{0} has {1} properties\n", t.FullName, parray.Length );
		foreach ( PropertyInfo pinfo in parray )
		{
			ParameterInfo [] pif = pinfo.GetIndexParameters();
			if ( pif.Length != 0 )
			{
				Console.WriteLine( "{0} is an indexer of {1} indices", 
					                pinfo.Name, pif.Length );

				foreach ( ParameterInfo parm in pif )
				          Console.WriteLine( "index {0} is of type {1}", 
							                 parm.Position+1, parm.ParameterType );
			}
			object [] o = { 0 }; // this is a cheat ...
			
			Console.WriteLine( "{0} is of type {1}", pinfo.Name, pinfo.PropertyType ); 
			Console.WriteLine( "Can Read? {0} Can Write? {1}", pinfo.CanRead, pinfo.CanWrite );
			
			if ( pif.Length == 0 )
			     Console.WriteLine( "The Property value is {0}\n", pinfo.GetValue( s, null ));
		    else Console.WriteLine( "First index value is {0}\n", pinfo.GetValue( s, o ));
		}
	}
}

public class ExploreReflection
{
	public static void identifyType( object o )
	{
		Type t = o.GetType();

		if ( t.IsClass )
		{
			 Console.WriteLine( "{0} registered as a class", t.FullName );
			 process_class( t );
			 return; 
		}

		if ( t.IsEnum )
		{
			Console.WriteLine( "{0} registered as an Enum", t.FullName );
			// process_enum( t ); 
			return; 
		}

		if ( t.IsValueType )
		{
			Console.WriteLine( "{0} registered as a Value Type", t.FullName );
			// process_ValType( t ); 
			return;
		}
		   
		Console.WriteLine( "{0} registered as something else", t.FullName );
		// process_type( t );
	}

	public static void process_class( Type t )
	{
		Console.WriteLine( "ExploreReflection.process_class( {0} )", t.FullName );
		process_memberInfo( t );
		process_fieldInfo( t );
		process_constructorInfo( t );
	}

	public static void process_fieldInfo( Type t )
	{
		// retrieves public fields both declared and inherited
		FieldInfo[] fi = t.GetFields( ReflectionEntry.lookupAll ); // );// BindingFlags.LookupAll );
		Console.WriteLine( "fieldInfo: {0}", fi.Length );
		foreach ( FieldInfo f in fi )
			Console.WriteLine( "field info: {0} type: {1}", 
			f.Name, f.FieldType);
	}

	public static void process_constructorInfo( Type t )
	{
		// retrieves public ctors
		ConstructorInfo[] fi = t.GetConstructors( ReflectionEntry.lookupAll );
		Console.WriteLine( "ConstructorInfo: {0}", fi.Length );
		foreach ( ConstructorInfo f in fi )
		{
			ParameterInfo [] pi = f.GetParameters();
			int paramCount = pi == null ? 0 : pi.Length;
			Console.WriteLine( "Constructor info: {0} params: {1}", 
			                    f.Name,  paramCount );
			Console.Write( "\t{0} ", f.IsPublic ? "public" : f.IsPrivate ? "private" : "protected?" );
			Console.Write( "{0} ", f.IsStatic ? "static" : "instance" );
			Console.WriteLine();
		}

		ConstructorInfo ctor = t.GetConstructor( nullSignature );
		
		ParameterInfo [] pii = ctor.GetParameters();
		int aparamCount = pii == null ? 0 : pii.Length;
		Console.WriteLine( "Selected null consturcotr: {0} params: {1}", 
			                ctor.Name,  aparamCount );
		Console.Write( "\t{0} ", ctor.IsPublic ? "public" : ctor.IsPrivate ? "private" : "protected?" );
		Console.Write( "{0} ", ctor.IsStatic ? "static" : "instance" );
		Console.WriteLine();
		
		ctor = t.GetConstructor( stringIntSignature );
		pii = ctor.GetParameters();
		aparamCount = pii == null ? 0 : pii.Length;
		Console.WriteLine( "Selected two arg consturcotr: {0} params: {1}", 
			                ctor.Name,  aparamCount );

		Console.Write( "\t{0} ", ctor.IsPublic ? "public" : ctor.IsPrivate ? "private" : "protected?" );
		Console.Write( "{0} ",   ctor.IsStatic ? "static" : "instance" );
		Console.WriteLine();
	}

    static Type [] nullSignature = new Type[0];
	static Type [] stringIntSignature = new Type[]{ 
		Type.GetType("System.String", true ), // String.Empty.GetType(),
		Type.GetType("System.Int32" )// 0.GetType()
	};
			
	public static void process_propertyInfo( Type t )
	{
		// retrieves public properties
		PropertyInfo[] pi = t.GetProperties( );
		Console.WriteLine( "propertyInfo: {0}", pi.Length );
		foreach ( PropertyInfo p in pi ){
			Console.WriteLine( "Property: {0}\tType: {1}",
								p.Name, p.PropertyType );

			Console.WriteLine( "\tRead: {0}\tWrite: {1}",
								p.CanRead, p.CanWrite );
		}		
	}

	public static void process_memberInfo( Type t )
	{
		MemberInfo[] mi = t.GetMembers();

		Console.WriteLine( "There are {0} members of {1}:\n",
						   mi.Length, mi[4].DeclaringType.Name );

		int ix = 1;
		
		foreach ( MemberInfo m in mi )
			Console.WriteLine( "\t{0}:\t{1} is a {2}",
				               ix++, m.Name, m.MemberType );
	}

    public static void test_values()
	{
		Type t = 132.GetType();
	}
}

class person
{
	public int nameInBaseDerived;
	static protected int foo;
	static public int Foo{ get{return foo;  }}

	public class NT_Date_of_Birth 
	{
		public DateTime nt_dob;
		public bool isBirthday()
		{ return ( nt_dob == DateTime.Now ); }
	}
	
	public person() {}// just to have around for reflection
	
	public person( string s, int age )
	{
		Name = s; Age = age; 
	}

	public person( string s, int age, DateTime dob )
		: this( s, age )
	{
		m_dob.nt_dob = dob;
	}

	private string           m_name;
	protected int              m_age;
	public NT_Date_of_Birth m_dob;

	public DateTime DateOfBirth 
	{
		set { m_dob.nt_dob = value; }
		get { return m_dob.nt_dob;  }
	}

	public bool isBirthday() { return m_dob.isBirthday(); }

	public static implicit operator string( person p ) 
	{
		 return p.m_name;
	}

	public static bool operator==( person p1, person p2 )
	{
		return ( p1.m_name == p2.m_name &&
			     p1.m_dob.nt_dob == p2.m_dob.nt_dob );
	}

	public static bool operator!=( person p1, person p2 )
	{
		return ! ( p1 == p2 );
	}

	public string Name {
		get{ return m_name; }
		set{ m_name = value; }
	}

	public int Age {
		get{ return m_age; }
		set{ m_age = value; }
	}

	// does not distinguish overloads
	public void overload( int ix ){}
	public void overload( string s ){}
}

class Programmer : person
{
	new public int nameInBaseDerived;

	public void overloaded() {}
	public void overloaded( int ix ) {}
	

	static public int count;
	private int yearsExperience;
	public string [] languages;

	static Programmer()
	{
		count = 0;
	}

	public Programmer() {}

	public Programmer( string s, int age ) : base( s, age ) {}

	public Programmer( string s, int age, int exp, string [] langs )
		: base( s, age )
	{
		yearsExperience = exp;
		languages = langs;
	}

	public int YearsExperience
	{
		get{ return yearsExperience;  }
		set{ yearsExperience = value; }
	}
	
}


