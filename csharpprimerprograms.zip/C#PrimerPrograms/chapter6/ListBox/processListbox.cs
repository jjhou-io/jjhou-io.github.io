using System;
using System.IO;
using System.Windows.Forms;

class processListbox
{
	private ListboxForm    thisForm;

	public processListbox( ListboxForm theForm )
	       { thisForm = theForm; }

	public bool process_file( string file_name )
	{
		StreamReader ifile;

		try 
		{
		    ifile = File.OpenText( file_name );
		}
		catch( Exception )
		{
			// Alternatively, we could pop open a 
			// File Dialog and let the user choose ...

			DialogResult dr = 
				MessageBox.Show( "Unable to open file " + file_name,
				"Unable to Open Dialog", 
				MessageBoxButtons.OKCancel,
				MessageBoxIcon.Error );

			return ( dr == DialogResult.OK ) ? true : false;
		}

		string textline; 
		int    lineCnt = 0;

		if ( thisForm.TheListBox.Items.Count != 0 )
			 thisForm.TheListBox.Items.Clear();

		while (( textline = ifile.ReadLine()) != null )
		{
			thisForm.TheListBox.Items.Add( textline );
			if ( lineCnt++ == 0 )
				 thisForm.Text = textline;
		}	
	 
		return true;
	}

	private void addBlankLine()
	{
		thisForm.TheListBox.Items.Add( "" );
	}

	private void addLine( string theLine )
	{
		thisForm.TheListBox.Items.Add( theLine );
	}

	public void interactive()
	{
		thisForm.TheListBox.Items.Clear();
		thisForm.Text = "An Interactive Demo";
		addLine( "Please select one of the following:" );
		addBlankLine();
		addLine( "\tpear" );
		addLine( "\tapple" );
		// thisForm.TheListBox.
	}
}