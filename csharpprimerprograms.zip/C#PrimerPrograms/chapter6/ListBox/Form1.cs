
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Data;

    public class ListboxForm : Form
    {
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;

		// OK: this represents generated code I modified ...
		private ListBox theListbox;

		// an independent class to process the ListBox
		private processListbox proc;

		public ListBox 
			   TheListBox{ get{ return theListbox; }}

        public ListboxForm()
        {
            InitializeComponent();
			proc = new processListbox( this );
        }

		// OK: end of code i modified ...

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.button3 = new System.Windows.Forms.Button();
			this.theListbox = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
			this.label1.Location = new System.Drawing.Point(24, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Enter Full Path of File";
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(128, 96);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(48, 23);
			this.button3.TabIndex = 5;
			this.button3.Text = "Clear";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// theListbox
			// 
			this.theListbox.HorizontalScrollbar = true;
			this.theListbox.Location = new System.Drawing.Point(24, 144);
			this.theListbox.Name = "theListbox";
			this.theListbox.Size = new System.Drawing.Size(304, 225);
			this.theListbox.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(72, 96);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(32, 23);
			this.button1.TabIndex = 3;
			this.button1.Text = "Go";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(200, 96);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(40, 23);
			this.button2.TabIndex = 4;
			this.button2.Text = "Quit";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(192, 32);
			this.textBox1.Name = "textBox1";
			this.textBox1.TabIndex = 2;
			this.textBox1.Text = "";
			// 
			// ListboxForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(352, 389);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button3,
																		  this.button2,
																		  this.button1,
																		  this.textBox1,
																		  this.label1,
																		  this.theListbox});
			this.Name = "ListboxForm";
			this.Text = "Hello, Listbox!";
			this.ResumeLayout(false);

		}

		// OK: these are the event handlers for the three buttons.
		//     obviously, it is more readable to rename the buttons
		//     such as Button_Clear, or whatever ...

		protected void button3_Click (object sender, System.EventArgs e)
		{
			if ( TheListBox.Items.Count != 0 )
			     TheListBox.Items.Clear();
		}

		// A useful exercise is to add a Browse button to allow the
		// user to choose the file through a FileDialog rather than
		// insist the user enter the path of the file, etc.

		protected void button1_Click (object sender, System.EventArgs e)
		{
			if ( textBox1.Text.Length != 0 )
				 if( ! proc.process_file( textBox1.Text ))
					 Close();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			DialogResult dr = 
				MessageBox.Show( "Are you sure you want to quit?",
				"DoubleCheck Dialog", 
				MessageBoxButtons.OKCancel,
				MessageBoxIcon.Question );

			if ( dr == DialogResult.OK )
				 Close();
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run( new ListboxForm() );
        }

		
    }

