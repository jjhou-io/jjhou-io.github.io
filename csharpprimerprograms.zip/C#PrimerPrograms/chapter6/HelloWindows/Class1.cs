using System;
using System.Windows.Forms;
using System.Drawing;

public class aForm : Form
{
	private System.Windows.Forms.TextBox textBox1;
	private System.Windows.Forms.Label label1;
    private System.ComponentModel.Container components;
	private System.Windows.Forms.Button button1;
	private System.Windows.Forms.Label label2;
		
            
	private void InitializeComponent ()
	{
		this.components = new System.ComponentModel.Container ();
		this.label1 = new System.Windows.Forms.Label ();
		this.label2 = new System.Windows.Forms.Label ();
		this.button1 = new System.Windows.Forms.Button ();
		this.textBox1 = new System.Windows.Forms.TextBox ();
		//@this.TrayHeight = 0;
		//@this.TrayLargeIcon = false;
		//@this.TrayAutoArrange = true;
		label1.Location = new System.Drawing.Point (24, 56);
		label1.Text = "Please enter your name:";
		label1.Size = new System.Drawing.Size (192, 23);
		label1.Font = new System.Drawing.Font ("Tahoma", 10, System.Drawing.FontStyle.Bold);
		label1.TabIndex = 0;
		label2.Location = new System.Drawing.Point (104, 152);
		label2.Text = "label2";
		label2.Size = new System.Drawing.Size (176, 48);
		label2.ForeColor = System.Drawing.Color.OliveDrab;
		label2.Font = new System.Drawing.Font ("Courier New", 12, System.Drawing.FontStyle.Bold);
		label2.TabIndex = 2;
		label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		label2.Visible = false;
		button1.Location = new System.Drawing.Point (152, 232);
		button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
		button1.Size = new System.Drawing.Size (75, 23);
		button1.TabIndex = 3;
		button1.Text = "OK";
		button1.Click += new System.EventHandler (this.button1_Click);
		textBox1.Location = new System.Drawing.Point (96, 88);
		textBox1.TabIndex = 1;
		textBox1.Size = new System.Drawing.Size (168, 20);
		this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
		this.ClientSize = new System.Drawing.Size (408, 273);
		this.Controls.Add (this.button1);
		this.Controls.Add (this.label2);
		this.Controls.Add (this.textBox1);
		this.Controls.Add (this.label1);
	}

	protected void button1_Click (object sender, System.EventArgs e)
	{
		label2.Text = "Hello," + "\n" + textBox1.Text;
		label2.Visible = true;
	}

	public aForm()
	{
		InitializeComponent();
		Text = "Hello Windows Title Bar";
	}

	/*
	 * protected override void OnPaint( PaintEventArgs e )
	{
		FontFamily [] ff = FontFamily.GetFamilies( e.Graphics );
		// foreach( FontFamily f in ff )
		//	     MessageBox( f.Name );
		string hw = "hello, win world!";
		e.Graphics.DrawString( hw, Font, // ff[ ff.Length-1 ].GenericSerif,
			                   new SolidBrush( Color.DarkBlue ),
							   100f, 100f );
	}
	*/
}

public class entryPoint
{
	public static void Main()
	{
		Application.Run( new aForm() );
	}
}