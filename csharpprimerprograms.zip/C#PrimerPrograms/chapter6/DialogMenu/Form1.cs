namespace WF_Dialogs
{
    using System;
    using System.Drawing;
	using System.Drawing.Printing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Data;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem TextBoxColor;
		private System.Windows.Forms.MenuItem menuItem9;

		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.TextBox textBox1;

        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.fontDialog1 = new System.Windows.Forms.FontDialog ();
			this.textBox1 = new System.Windows.Forms.TextBox ();
			this.menuItem2 = new System.Windows.Forms.MenuItem ();
			this.menuItem5 = new System.Windows.Forms.MenuItem ();
			this.menuItem6 = new System.Windows.Forms.MenuItem ();
			this.menuItem13 = new System.Windows.Forms.MenuItem ();
			this.menuItem15 = new System.Windows.Forms.MenuItem ();
			this.menuItem14 = new System.Windows.Forms.MenuItem ();
			this.menuItem3 = new System.Windows.Forms.MenuItem ();
			this.menuItem7 = new System.Windows.Forms.MenuItem ();
			this.menuItem1 = new System.Windows.Forms.MenuItem ();
			this.menuItem4 = new System.Windows.Forms.MenuItem ();
			this.menuItem10 = new System.Windows.Forms.MenuItem ();
			this.TextBoxColor = new System.Windows.Forms.MenuItem ();
			this.menuItem12 = new System.Windows.Forms.MenuItem ();
			this.menuItem17 = new System.Windows.Forms.MenuItem ();
			this.menuItem16 = new System.Windows.Forms.MenuItem ();
			this.menuItem11 = new System.Windows.Forms.MenuItem ();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu ();
			this.menuItem8 = new System.Windows.Forms.MenuItem ();
			this.menuItem9 = new System.Windows.Forms.MenuItem ();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog ();
			this.label1 = new System.Windows.Forms.Label ();
			this.mainMenu1 = new System.Windows.Forms.MainMenu ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			//@fontDialog1.SetLocation (new System.Drawing.Point (7, 7));
			textBox1.Location = new System.Drawing.Point (24, 104);
			textBox1.Text = "Default Text Entry";
			textBox1.Font = new System.Drawing.Font ("Microsoft Sans Serif", 12);
			textBox1.TabIndex = 0;
			textBox1.Size = new System.Drawing.Size (192, 26);
			textBox1.TextChanged += new System.EventHandler (this.textBox1_TextChanged);
			menuItem2.Text = "Font";
			menuItem2.Index = 0;
			menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[2] {this.menuItem3, this.menuItem4});
			menuItem5.Text = "Color";
			menuItem5.Index = 1;
			menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[3] {this.menuItem6, this.menuItem9, this.menuItem8});
			menuItem6.Text = "label";
			menuItem6.Index = 0;
			menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[1] {this.menuItem7});
			menuItem13.Text = "BackColor";
			menuItem13.Index = 1;
			menuItem13.Click += new System.EventHandler (this.menuItem13_Click);
			menuItem15.Text = "Edit";
			menuItem15.Index = 0;
			menuItem15.MenuItems.AddRange(new System.Windows.Forms.MenuItem[2] {this.menuItem16, this.menuItem17});
			menuItem14.Enabled = false;
			menuItem14.Text = "Print";
			menuItem14.Index = 2;
			menuItem3.Text = "Textbox";
			menuItem3.Index = 0;
			menuItem3.Click += new System.EventHandler (this.menuItem3_Click);
			menuItem7.Text = "Fore Color (text)";
			menuItem7.Index = 0;
			menuItem7.Click += new System.EventHandler (this.menuItem7_Click);
			menuItem1.Text = "Edit";
			menuItem1.Index = 0;
			menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[3] {this.menuItem2, this.menuItem5, this.menuItem14});
			menuItem4.Text = "Label";
			menuItem4.Index = 1;
			menuItem4.Click += new System.EventHandler (this.menuItem4_Click);
			menuItem10.Text = "";
			menuItem10.Index = -1;
			TextBoxColor.Text = "Fore Color (text)";
			TextBoxColor.Shortcut = System.Windows.Forms.Shortcut.ShiftF1;
			TextBoxColor.Index = 0;
			TextBoxColor.Click += new System.EventHandler (this.menuItem10_Click);
			menuItem12.Text = "ForeColor";
			menuItem12.Index = 0;
			menuItem12.Click += new System.EventHandler (this.menuItem12_Click);
			menuItem17.Text = "Color";
			menuItem17.Index = 1;
			menuItem17.Click += new System.EventHandler (this.menuItem17_Click);
			menuItem16.Text = "Font";
			menuItem16.Index = 0;
			menuItem11.Text = "Back Color";
			menuItem11.Index = 1;
			menuItem11.Click += new System.EventHandler (this.menuItem11_Click);
			//@contextMenu1.SetLocation (new System.Drawing.Point (302, 7));
			contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[1] {this.menuItem15});
			menuItem8.Text = "Form";
			menuItem8.Index = 2;
			menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[2] {this.menuItem12, this.menuItem13});
			menuItem9.Text = "Text Box";
			menuItem9.Index = 1;
			menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[2] {this.TextBoxColor, this.menuItem11});
			//@colorDialog1.SetLocation (new System.Drawing.Point (201, 7));
			label1.Location = new System.Drawing.Point (24, 16);
			label1.Text = "Menu & Dialog  Demo";
			label1.Size = new System.Drawing.Size (208, 23);
			label1.ContextMenu = this.contextMenu1;
			label1.Font = new System.Drawing.Font ("Tahoma", 14, System.Drawing.FontStyle.Bold);
			label1.TabIndex = 1;
			//@mainMenu1.SetLocation (new System.Drawing.Point (103, 7));
			mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[1] {this.menuItem1});
			this.Text = "Form1";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.Menu = this.mainMenu1;
			this.ClientSize = new System.Drawing.Size (240, 153);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.textBox1);
		}

		protected void menuItem17_Click (object sender, System.EventArgs e)
		{
			ColorDialog diag = new ColorDialog();

			// We don't want them selecting a custom color.
			diag.AllowFullOpen = false;

			// Set the initial color select to the current text color,
			// so that if the user cancels out we will restore the original color.
			diag.Color = label1.ForeColor ;
			diag.ShowDialog();
			label1.ForeColor =  diag.Color;
		}

		protected void menuItem7_Click (object sender, System.EventArgs e)
		{
			ColorDialog diag = new ColorDialog();

			// We don't want them selecting a custom color.
			diag.AllowFullOpen = false;

			// Set the initial color select to the current text color,
			// so that if the user cancels out we will restore the original color.
			diag.Color = label1.ForeColor ;
			diag.ShowDialog();
			label1.ForeColor =  diag.Color;
		}

		protected void menuItem13_Click (object sender, System.EventArgs e)
		{
			// Form BackColor
			ColorDialog diag   = new ColorDialog();
			diag.AllowFullOpen = false;

			diag.Color = BackColor ;
			diag.ShowDialog();
			BackColor =  diag.Color;
		}

		protected void menuItem12_Click (object sender, System.EventArgs e)
		{
			// Form ForeColor
			ColorDialog diag   = new ColorDialog();
			diag.AllowFullOpen = false;

			diag.Color = ForeColor ;
			diag.ShowDialog();
			ForeColor =  diag.Color;
		}
		
		protected void menuItem10_Click (object sender, System.EventArgs e)
		{
			// ForeColor -- text box
			ColorDialog diag   = new ColorDialog();
			diag.AllowFullOpen = false;

			diag.Color = textBox1.ForeColor ;
			diag.ShowDialog();
			textBox1.ForeColor = diag.Color;
		}

		protected void menuItem11_Click (object sender, System.EventArgs e)
		{
			// BackColor -- text box
			ColorDialog diag   = new ColorDialog();
			diag.AllowFullOpen = false;

			diag.Color = textBox1.BackColor ;
			diag.ShowDialog();
			textBox1.BackColor =  diag.Color;
		}

		protected void menuItem4_Click (object sender, System.EventArgs e)
		{
			fontDialog1.ShowColor = true;
			if(fontDialog1.ShowDialog() != DialogResult.Cancel )
			{
				label1.Font      = fontDialog1.Font ;
				label1.ForeColor = fontDialog1.Color;
			}
		}

		protected void menuItem3_Click (object sender, System.EventArgs e)
		{
			fontDialog1.ShowColor = true;
			if( fontDialog1.ShowDialog() != DialogResult.Cancel )
			{
				textBox1.Font = fontDialog1.Font ;
				textBox1.ForeColor = fontDialog1.Color;
			}
		}

		protected void textBox1_TextChanged (object sender, System.EventArgs e)
		{
			Text = textBox1.Text;
		}

        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
    }
}
