namespace WF_Menu
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Data;
	using System.IO;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;

        public Form1()
        {
            InitializeComponent();

		    StreamReader ifile = File.OpenText( @"c:\fictions\word.txt" );

			string textline; 
			int    lineCnt = 0;

			while (( textline = ifile.ReadLine()) != null )
			{
				// listBox1.Items.Add( textline );
				switch ( lineCnt )
				{
				case 0: Text = textline;label1.Text = textline;break;
				case 1: label2.Text = textline;break;
				case 2: label3.Text = textline;break;
				case 3: label4.Text = textline;break;
				case 5: label5.Text = textline;break;
				case 6: label6.Text = textline;break;
				case 7: label7.Text = textline;break;
				case 8: label8.Text = textline;break;
				case 9: label9.Text = textline;break;
				case 11: label10.Text = textline;break;
				case 12: label11.Text = textline;break;
				case 13: label12.Text = textline;break;
				case 14: label13.Text = textline;break;
					
				default:
					break;
				}
				
				lineCnt++;
			}		 
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(120, 552);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(384, 23);
			this.label7.TabIndex = 8;
			this.label7.Text = "label7";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(120, 536);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(384, 23);
			this.label6.TabIndex = 7;
			this.label6.Text = "label6";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(120, 520);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(384, 23);
			this.label5.TabIndex = 6;
			this.label5.Text = "label5";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(120, 464);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(384, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "label3";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(120, 448);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(384, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "label2";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(120, 432);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(384, 23);
			this.label1.TabIndex = 2;
			this.label1.Text = "label1";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(120, 480);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(384, 23);
			this.label4.TabIndex = 5;
			this.label4.Text = "label4";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(120, 672);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(416, 23);
			this.label13.TabIndex = 14;
			this.label13.Text = "label13";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(120, 624);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(416, 23);
			this.label10.TabIndex = 11;
			this.label10.Text = "label10";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(120, 640);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(416, 23);
			this.label11.TabIndex = 12;
			this.label11.Text = "label11";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label11.Click += new System.EventHandler(this.label11_Click);
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(120, 656);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(416, 23);
			this.label12.TabIndex = 13;
			this.label12.Text = "label12";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(24, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(608, 408);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(120, 584);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(384, 23);
			this.label9.TabIndex = 10;
			this.label9.Text = "label9";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(120, 568);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(384, 23);
			this.label8.TabIndex = 9;
			this.label8.Text = "label8";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 18);
			this.ClientSize = new System.Drawing.Size(656, 753);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label13,
																		  this.label12,
																		  this.label11,
																		  this.label10,
																		  this.label9,
																		  this.label8,
																		  this.label7,
																		  this.label6,
																		  this.label5,
																		  this.label4,
																		  this.label3,
																		  this.label2,
																		  this.label1,
																		  this.pictureBox1});
			this.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold);
			this.Name = "Form1";
			this.Text = "Timothy Gnome - Page 1";
			this.ResumeLayout(false);

		}

		protected void label11_Click (object sender, System.EventArgs e)
		{

		}

		protected void menuItem3_Click (object sender, System.EventArgs e)
		{

		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
    }
}
