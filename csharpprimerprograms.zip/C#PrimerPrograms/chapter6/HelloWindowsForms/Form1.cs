namespace HelloWindows.Forms
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Data;

    public class Form1 : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 56);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Please Enter Name";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(152, 56);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(168, 22);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "";
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(72, 136);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.Text = "OK";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(184, 136);
			this.button2.Name = "button2";
			this.button2.TabIndex = 3;
			this.button2.Text = "Quit";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 15);
			this.ClientSize = new System.Drawing.Size(344, 205);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button2,
																		  this.button1,
																		  this.label1,
																		  this.textBox1});
			this.Font = new System.Drawing.Font("Palatino Linotype", 8F);
			this.Name = "Form1";
			this.Text = "Hello, Windows Forms!";
			this.ResumeLayout(false);

		}

		protected void textBox1_TextChanged (object sender, System.EventArgs e)
		{
			if ( textBox1.Text != null )
			     Text = "Hello, " + textBox1.Text;
		}

        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
		
		protected void button2_Click (object sender, System.EventArgs e)
		{
			// Our Code
			DialogResult dr = 
				  MessageBox.Show( "Are you sure you want to quit, " + textBox1.Text + "?",
				                   "DoubleCheck Dialog", 
				                    MessageBoxButtons.OKCancel,
									MessageBoxIcon.Error );

			if ( dr == DialogResult.OK )
			{
				MessageBox.Show( "OK: " + textBox1.Text + " -- bye!" );
				Close();
			}    
		}
		
		protected void button1_Click (object sender, System.EventArgs e)
		{
			string [] messages = 
			{
				"Please enter your name before Pressing OK",
				"Welcome to your First Windows Forms Program"
			};

			string [] titles = 
			{
				"Bad Data Dialog",
				"Hello, Windows Dialog"
			};

			if (  textBox1.Text == string.Empty )
			{
				 MessageBox.Show( messages[0], titles[0], 
					              MessageBoxButtons.OK, MessageBoxIcon.Warning );
				 return;
			}
			     
			DateTime current = DateTime.Now;

			string helloMessage = 
				"hello, " + textBox1.Text + "!\n" +
				messages[1] + "\n" +
				"at " + current.ToShortTimeString() +
				" on " + current.ToLongDateString();

			MessageBox.Show( helloMessage, titles[1], 
				             MessageBoxButtons.OK, MessageBoxIcon.Information );

		}
    }
}
