namespace datagrid
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
	using System.Windows.Forms;
    using System.Data;
	using System.IO;
	using System.Xml;
	using System.Data.SqlClient;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MainMenu File;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;

        public Form1()
        {
            InitializeComponent();

			// ASSN:
			// the prior 
			//          uid=sa;pwd= 
			// pair within the connection string has been replaced with 
			//          Integrated Security=SSPI
			// string scon = "server=localhost;uid=sa;pwd=;database=northwind";
			// END_ASSN

			string scon = "server=localhost;Integrated Security=SSPI;database=northwind";
			string scmd = "SELECT * FROM Employees";
			SqlConnection conn = new SqlConnection( scon );
			SqlCommand cmd = new SqlCommand( scmd, conn );

			SqlDataAdapter sda = new SqlDataAdapter();
			sda.SelectCommand = cmd;

			conn.Open();

			DataSet ds = new DataSet();
			sda.Fill( ds, "Employees" );

			dataGrid1.DataSource = ds.Tables[0].DefaultView;

        }

        private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.File = new System.Windows.Forms.MainMenu();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 16);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(496, 176);
			this.dataGrid1.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 201);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid1});
			this.Menu = this.File;
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}

		protected void openFileDialog1_FileOk (object sender, System.ComponentModel.CancelEventArgs e)
		{
			Text =  openFileDialog1.FileName;
			// FileStream fs  = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read );
			DataSet ds = new DataSet();
			// ds.ReadXml( fs );
			ds.ReadXml( openFileDialog1.FileName );

			dataGrid1.DataSource = ds.Tables[0].DefaultView;

		}

		protected void menuItem2_Click (object sender, System.EventArgs e)
		{
				Text = "open file?";
			    openFileDialog1.ShowDialog();
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			Text = "open file?";
			openFileDialog1.ShowDialog();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}
    }
}
