namespace WF_Pictures
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Data;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Label      label1;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;

		static string image_location = @"C:\C#PrimerPrograms\pictures\";
		static public string ImageLocation { get{ return image_location; }}

        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// pictureBox5
			// 
			this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox5.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox5.Image")));
			this.pictureBox5.Location = new System.Drawing.Point(56, 160);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(100, 112);
			this.pictureBox5.TabIndex = 4;
			this.pictureBox5.TabStop = false;
			this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
			// 
			// pictureBox6
			// 
			this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox6.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox6.Image")));
			this.pictureBox6.Location = new System.Drawing.Point(440, 160);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new System.Drawing.Size(100, 112);
			this.pictureBox6.TabIndex = 5;
			this.pictureBox6.TabStop = false;
			this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
			// 
			// label1
			// 
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
			this.label1.Location = new System.Drawing.Point(56, 320);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(488, 23);
			this.label1.TabIndex = 6;
			this.label1.Text = "Click on a picture to see a Larger Image";
			// 
			// pictureBox3
			// 
			this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox3.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox3.Image")));
			this.pictureBox3.Location = new System.Drawing.Point(256, 40);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(100, 72);
			this.pictureBox3.TabIndex = 2;
			this.pictureBox3.TabStop = false;
			this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
			// 
			// pictureBox4
			// 
			this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox4.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox4.Image")));
			this.pictureBox4.Location = new System.Drawing.Point(56, 32);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(100, 88);
			this.pictureBox4.TabIndex = 3;
			this.pictureBox4.TabStop = false;
			this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(256, 176);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(100, 96);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox2.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(440, 32);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(100, 88);
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(608, 381);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.pictureBox6,
																		  this.pictureBox5,
																		  this.pictureBox4,
																		  this.pictureBox3,
																		  this.pictureBox2,
																		  this.pictureBox1});
			this.Name = "Form1";
			this.Text = "A Pride of Annas";
			this.ResumeLayout(false);

		}

		protected void pictureBox5_Click (object sender, System.EventArgs e)
		{
			//AnnaTable
			Form2 f2 = new Form2( image_location + "bigAnnaTable.JPG" );
			f2.Show();
			label1.Text = "You last selected " + image_location + "bigAnnaTable.JPG";
		}

		protected void pictureBox2_Click (object sender, System.EventArgs e)
		{
			//AnnaDog
			Form2 f2 = new Form2(image_location + "bigAnnaDog.JPG" );
			f2.Show();
			label1.Text = "You last selected " + image_location + "bigAnnaDog.JPG";
		}

		protected void pictureBox3_Click (object sender, System.EventArgs e)
		{
			//AnnaGlide
			Form2 f2 = new Form2(image_location + "bigAnnaGlide.JPG" );
			f2.Show();
			label1.Text = "You last selected " + image_location + "bigAnnaGlide.JPG";
		}

		protected void pictureBox4_Click (object sender, System.EventArgs e)
		{
			//AnnaPooh
			Form2 f2 = new Form2(image_location + "bigAnnaPooh.JPG" );
			f2.Show(); f2.Activate();
			label1.Text = "You last selected " + image_location + "bigAnnaPooh.JPG"; 
		}

		protected void pictureBox6_Click (object sender, System.EventArgs e)
		{
			Form2 f2 = new Form2(image_location + "bigAnnaWork.JPG" );
			f2.Show();
			label1.Text = "You last selected " + image_location + "bigAnnaWork.JPG"; 
		}

		protected void pictureBox1_Click (object sender, System.EventArgs e)
		{
			Form2 f2 = new Form2(image_location + "bigAnnaCold.JPG");
			if ( f2.ShowDialog( this ) != DialogResult.OK )
				 label1.Text = "You last selected " + image_location + "bigAnnaCold.JPG";
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
    }
}
