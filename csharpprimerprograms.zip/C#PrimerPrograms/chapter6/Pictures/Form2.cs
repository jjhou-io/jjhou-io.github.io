namespace WF_Pictures
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;

    public class Form2 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		public  Bitmap theImage = new Bitmap( 
			    Form1.ImageLocation + "bigAnnaWork.JPG" );
				
		protected override void OnPaint( PaintEventArgs e )
		{
			if ( theImage != null )
			{
				Graphics g = e.Graphics;
				g.DrawImage( theImage, ClientRectangle );
			}
		}

        public Form2( string theFile )
        {
            // Required for Windows Form Designer support
            InitializeComponent();

			// our stuff
            theImage = new Bitmap( theFile );
			Text = theFile;

			AutoScroll = true;
			AutoScrollMinSize = theImage.Size;

			ClientSize = new System.Drawing.Size( theImage.Width+5, theImage.Height+5 );

        }

        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			// this.AutoScroll = true;
			// this.ClientSize = new System.Drawing.Size (600, 525);
		}
    }
}
