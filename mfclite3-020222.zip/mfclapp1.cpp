//------------------------------------------------------
// �ɦW�Gmfclapp.cpp
// �@�̡G�J�� J.J.Hou (jjhou), jjhou@jjhou.com, www.jjhou.com
// �γ~�G���� MFCLite�A�îi�{�@�� MFC App ���g�k
//   �o�̩w�q App classes�A�M�@�ӥ��쪫�� theApp
//
// �{���\��G�H����]�`�N�j�p�g�^���������ާ@�C
// ����\�ਣ CMyWinApp::OnAppHotKeyHelp() �ҦC�C�S�O�Ъ`�N�G
// '0' - ��ܥثe���A�]doc/frame/view)
// '1' - ���� active windows�A�ĤϽƴ`�������A����ܥثe���A ('0')
// 'C' - ClearAll�C���ҵL��������A�u�O���ҰT��¶��
// 'u' - WM_LBUTTONUP�A���Ҧ۰ʶ�J�w�]��Ʃ� document
// 'd' - WM_LBUTTONDOWN�A���ҵL��������A�u�O���ҰT��¶��
// 'm' - WM_MOUSEMOVE�A���ҵL��������A�u�O���ҰT��¶��
//------------------------------------------------------

#include <iostream>
#include "mfclite.h"     // MFCLite Module
#include "mfclshp.h"     // Shape Module
#include "mfclapp.h"     // App Module
#include "resource.h"    // Command ID
#include <map>           // for map
#include <fstream>       // for ofstream
using namespace std;

CMyWinApp theApp;

IMPLEMENT_DYNCREATE(CMyView, CView)
IMPLEMENT_DYNCREATE(CMyDocument, CDocument)
IMPLEMENT_DYNCREATE(CMainFrame,  CMDIFrameWnd)   // 2001/11/14
IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)   // 2001/11/14

BEGIN_MESSAGE_MAP(CMyWinApp, CWinApp)
  ON_COMMAND(ID_FILE_NEW,  CWinApp::OnFileNew)     //5
  ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)    //5
  ON_COMMAND(ID_APP_ABOUT, OnAppAbout)             //5
  ON_COMMAND(ID_APP_HOTKEY_HELP, OnAppHotKeyHelp)  //11
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)    // 2001/11/14
  ON_WM_CREATE()
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)   // 2001/11/14
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyDocument, CDocument)
  ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)    //5
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyView, CView)
  ON_WM_LBUTTONDOWN()                              //5
  ON_WM_LBUTTONUP()                                //5
  ON_WM_MOUSEMOVE()                                //5
END_MESSAGE_MAP()

////////// CMyWinApp Implementation ////////////////////////////
////////////////////////////////////////////////////////////////

BOOL CMyWinApp::InitInstance()
{
  // �n���@�� DocTemplate
  CMultiDocTemplate* pDocTemplate;
  pDocTemplate = new CMultiDocTemplate(
                        IDR_MYDOCTYPE,                 // .dat
                        RUNTIME_CLASS(CMyDocument),
                        RUNTIME_CLASS(CChildFrame),
                        RUNTIME_CLASS(CMyView)
                     );
  AddDocTemplate(pDocTemplate);

  CMainFrame* pMainFrame = new CMainFrame;
  pMainFrame->LoadFrame(IDR_MAINFRAME);
  m_pMainWnd = pMainFrame;

  OnAppHotKeyHelp();  // �ѩ�L�깳�����A�ҥH���C�X�Ҧ��������ϥΪ̾ǲߨϥ�

  // Enable drag/drop open. We don't call this in Win32, since a
  //  document file extension wasn't chosen while running AppWizard.
  // m_pMainWnd->DragAcceptFiles();  // MFCLite ���䴩�A�����C

  // Enable DDE Execute open
  // EnableShellOpen();              // MFCLite ���䴩�A�����C
  // RegisterShellFileTypes(TRUE);   // MFCLite ���䴩�A�����C

  AfxGetApp()->OnCmdMsg(ID_FILE_NEW, 0);  // �s�}�@�� document�C�o�|�ɭP
                                          // �}�Ҥ@�� frame �M�@�� view

  pMainFrame->ShowWindow(0 /*m_nCmdShow*/ );
  pMainFrame->UpdateWindow();


  //13 --------------------------------------------------------
  // �H�U�ΨӴ��� ptr alias for persistence �����T�ʡC�P�� xiaox�C
  CSquare *ps1 = new CSquare(1,2,3);
  CSquare *ps2 = ps1 ;   // ps1 �M ps2 ���V�P�@�� object
  CSquare *ps3 = new CSquare(3,2,1);
  CRect   *pr1 = new CRect(1,2,3,4);
  CRect   *pr2 = pr1 ;   // pr1 �M pr2 ���V�P�@�� object
  CRect   *pr3 = new CRect(4,3,2,1);
  assert (ps1 == ps2);
  assert (ps1 != ps3);
  assert (pr1 == pr2);
  assert (pr1 != pr3);
  {
      CFile write("ptralias.out", CFile::modeWrite) ;
      CArchive store(&write, CArchive::store) ;
      store << ps1 << ps2 << ps3 << pr1 << pr2 << pr3;

      store.ShowStoreMap();
      cout << ps1 << ' ' << ps2 << ' ' << ps3 << ' ';
      cout << pr1 << ' ' << pr2 << ' ' << pr3 << endl;
      ps1->display();
      ps3->display();
      pr1->display();
      pr3->display();
  }
  delete ps1;
  delete ps3;
  delete pr1;
  delete pr3;
  ps1 = ps2 = ps3 = NULL;
  pr1 = pr2 = pr3 = NULL;
  {
      CFile read("ptralias.out", CFile::modeRead) ;
      CArchive load(&read, CArchive::load) ;
      load >> ps1 >> ps2 >> ps3 >> pr1 >> pr2 >> pr3;

      load.ShowLoadArray();
      cout << ps1 << ' ' << ps2 << ' ' << ps3 << ' ';
      cout << pr1 << ' ' << pr2 << ' ' << pr3 << endl;
      ps1->display();
      ps3->display();
      pr1->display();
      pr3->display();
  }
  assert (ps1 == ps2);  // �p�G�L���A���ܭ���V�P�@�� object �� ptrs �{�����V�P�@�� object
  assert (ps1 != ps3);
  assert (pr1 == pr2);  // �p�G�L���A���ܭ���V�P�@�� object �� ptrs �{�����V�P�@�� object
  assert (pr1 != pr3);
  //13 --------------------------------------------------------
  // �H�W�w�q�L����


  // �H�U�ΨӴ��� R/W mode �����T�ʡC�P�� xiaox�C
  {
    char c = 0x1a;  // in text mode, Ctrl-Z means EOF.
    CFile write("rwtest.out", CFile::modeWrite) ;
    CArchive store(&write, CArchive::store) ;
    store << c;
  }
  {
    char c;
    CFile read("rwtest.out", CFile::modeRead) ;
    CArchive load(&read, CArchive::load) ;
    load >> c;  // assertion fail
  }
  // �H�W�w�q�L����

  return TRUE;
}

int CMyWinApp::ExitInstance()  //11
{
    //TRACE1("CMyWinApp::ExitInstance() \n");
    // delete m_pDocTemplate3;              // why crash???
    return CWinApp::ExitInstance();
}

void CMyWinApp::OnAppHotKeyHelp()  // 11
{
  // ��� Help �T���C�p��q rc �� res ��Ū�X�A�~�O�̲z�Q�C
  cout << endl;
  cout << "MFCLite v3.0 HotKey help : " << endl;
  cout << "  N - File|New, Create a new document" << endl;
  cout << "  O - File|Open, Open an existing document" << endl;
  cout << "  S - File|Save, Save the active document\tSave" << endl;
  cout << "  A - File|save As, Save the active document with a new name" << endl;
  cout << "  C - File|Close, Close the active document" << endl;   //14
  cout << "  X - File|eXit, Quit the application; prompts to save documents" << endl;  //14
  cout << "  B - Help|aBout, Display program info., version number and copyright" << endl;
  cout << "  H - Help|HotKey, Display HotKey information" << endl;
  cout << "  R - Edit|Clear all, Clears the drawing" << endl;
  cout << "  W - Window|new Window, Open another window for the active document" << endl;
  cout << endl;
  cout << "  0 - ShowStatus (mainFrame, Docs, docFrames, Views...)" << endl;
  cout << "  1 - Change Active Window in turn" << endl;
  cout << "  G - debuG, Output debug information to 'debug.txt'" << endl;
  cout << "  p - WM_PAINT" << endl;
  cout << "  c - WM_CLOSE, Close the active window and prompts to save documents" << endl; //14
  cout << "  x - WM_CLOSE, Quit the application; prompts to save documents" << endl;       //14
  cout << "  u - WM_LBUTTONUP" << endl;
  cout << "  d - WM_LBUTTONDOWN" << endl;
  cout << "  m - WM_MOUSEMOVE" << endl;
  cout << endl;
}

void CMyWinApp::OnAppAbout()
{
  // ��� [Help|About] �T���C
  cout << endl;
  cout << "---------------------------------------------------" << endl;
  cout << "MFCLite v3.0                                       " << endl;
  cout << " history:                                          " << endl;
  cout << "   v1.0, released in <Dissecting MFC> 2e,ch3.      " << endl;
  cout << "   v2.0, released in <Polymorphism in C++> 1e,ch5. " << endl;
  cout << "   v3.0, released in <Polymorphism in C++> 2e,ch6. " << endl;
  cout << " by j.j.hou                                        " << endl;
  cout << "   ref. MFC source                                 " << endl;
  cout << " @copyleft :)                                      " << endl;
  cout << "---------------------------------------------------" << endl;
  cout << endl;
}


////////// CMainFrame Implementation //////////////////////////
////////////////////////////////////////////////////////////////

int CMainFrame::OnCreate(LPCREATESTRUCT lpcs)
{
  // TRACE1("CMainFrame::OnCreate() \n");

  // �H�U�b MFC App ���I�s CMDIFrameWnd::OnCreate()�C
  // ���O�]���b�@�� MDI �{�����A�D�������~�Ӧ� CMDIFrameWnd�C
  if (CMDIFrameWnd::OnCreate(lpcs) == -1)
      return -1;

  // ���J ToolBar, StatusBar, Indicator...

  return 0;  // success
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
  // TRACE1("CMainFrame::PreCreateWindow() \n");

  // TODO: Modify the Window class or styles here by modifying
  //  the CREATESTRUCT cs

  // jjhou : �o�̬O���F���� client �@�Ӿ��|�i�H��Φ۩w�� window class�C
  //         �q�`���|�ק�A����N���K�[����{���X�C

  return CMDIFrameWnd::PreCreateWindow(cs);
}

void CMainFrame::OnWindowNew()  //11
{
    // TRACE1("CMainFrame::OnWindowNew() \n");

    CMDIChildWnd* pActiveChild = MDIGetActive();
    CDocument* pDocument;
    if (pActiveChild == NULL ||
        (pDocument = pActiveChild->GetActiveDocument()) == NULL)
    {
        TRACE0("Warning: No active document for WindowNew command.\n");
        return;     // command failed
    }

    // �{�b�A�ǳƲ��ͤ@�� new docFrame !
    CDocTemplate* pTemplate = ((CMyWinApp*)AfxGetApp())->m_pDocTemplate3; // only difference with CMDIFrameWnd::OnWindowNew()
    CFrameWnd* pFrame = pTemplate->CreateNewFrame(pDocument, pActiveChild);
    if (pFrame == NULL)
    {
        TRACE0("Warning: failed to create new frame.\n");
        return;     // command failed
    }

    // InitialUpdateFrame...
}

////////// CMyDocument Implementation //////////////////////////
////////////////////////////////////////////////////////////////

void CMyDocument::Serialize(CArchive& ar)
{
  TRACE1("CMyDocument::Serialize()\n");

  CObject::Serialize(ar);
  if (ar.IsStoring()) {
    myList.Serialize(ar);   // persistence, �g�J�ɮ�
    //ar << myList;
  }
  else {
    myList.Serialize(ar);   // persistence, �q�ɮ�Ū�X
    //ar >> myList;
  }

}

void CMyDocument::OnEditClearAll()
{
  TRACE1("CMyDocument::OnEditClearAll()\n");
}

////////// CMyView Implementation //////////////////////////////
////////////////////////////////////////////////////////////////

CMyDocument* CMyView::GetDocument() const
{
  ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyDocument)));
  return (CMyDocument*)m_pDocument;
}

void CMyView::OnDraw(/* CDC* */)
{
    TRACE1("CMyView::OnDraw() \n");

    CMyDocument* pDoc = GetDocument();

    // ���X�Ҧ���ƨ����
    POSITION pos = pDoc->myList.GetHeadPosition();
    // jjhou: why ok? myList is private in CMyDocument!
    // Ans: because CMyView is friend of CMyDocument.
    while (pos != NULL) {
        CShape* pS = (CShape*)pDoc->myList.GetNext(pos);
        pS->display();  // ��ܥX��
    }
}

void CMyView::OnMouseMove(UINT nFlags, CPoint point)
{
  TRACE1("CMyView::OnMouseMove()\n");
}

void CMyView::OnLButtonDown(UINT nFlags, CPoint point)
{
    TRACE1("CMyView::OnLButtonDown()\n");
}

void CMyView::OnLButtonUp(UINT nFlags, CPoint point)
{
    TRACE1("CMyView::OnLButtonUp()\n");

    CMyDocument* pDoc = GetDocument();

    // ���ҥO LButtonUp �o�ͮɴN�N�H�U��Ƹm�J document ���C

    CShape* pShape[8];
    // prepare raw data
    pShape[0] = new CEllipse(3.0, 3.0, 7.0, 21.0);
    pShape[1] = new CCircle(5.0, 5.0, 7.0);
    pShape[2] = new CTriangle(0.0, 0.0, 1.0, 0.0, 0.0, 1.0);
    pShape[3] = new CRect(5.6, 6.8, 3.0, 9.0);
    pShape[4] = new CSquare(3.2, 4.3, 6.0);
    pShape[5] = new CStroke;
    CStroke* pStroke = dynamic_cast<CStroke*>(pShape[5]);
    assert(pStroke);
    pStroke->m_DArray.Add(1);
    pStroke->m_DArray.Add(2);
    pStroke->m_DArray.Add(3);
    pStroke->m_DArray.Add(4);
    pStroke->m_DArray.Add(5);
    pStroke->m_DArray.Add(6);
    pStroke->m_DArray.Add(7);
    pShape[6] = new CTriangle(0.0, 0.0, 3.5, 0.0, 0.0, 5.3);
    pShape[7] = new CRect(9.9, 9.9, 4.8, 9.8);

    for (int i=0; i<8; i++)   // prepare container's data
        pDoc->myList.AddTail(pShape[i]);

    pDoc->UpdateAllViews(this);
    // �H�W�ʧ@�A�p�G���ɪ� doc �u���@�� docFrame�]�M�@�� view�^
    // ����N���|��������ܰʧ@�C�]�� UpdateAllViews() �|�P�_
    // sender�A���q�� sender�C�o�˪��]�p�O�]���b�u���������{����
    // OnLButtonUp() �������Ӥw����ø����ܤu�@�]�_�h�p�����ϥΪ� WYSIWYG ?�^
}
//---------------- end of file --------------------
