//------------------------------------------------------
// �ɦW�Gmfclshp.cpp
// �@�̡G�J�� J.J.Hou (jjhou),  jjhou@jjhou.com,  www.jjhou.com
// �γ~�Gbased on MFCLite�A��@�H�U classes�G
//   CShape, CSquare, CRect, CCircle, CEllipse, CTriangle
//
// �޳N���I�G
// Object (operator) I/O �Y�H���Ь���¦�A�H�קK�غc�a�Ӫ��B�~�t��C
// �p�G���諸�O embedded objects�A�h�������ϥΨ� Serialize()�C
// �ҥH�A
// �p�G container ���t���O ptr�A�h
//   Serialize() �����ĥ� ar << ptr; ar >> ptr;
// �p�G container ���t���O obj�A�h
//   Serialize() �����ĥ� obj.Serialize();
// �Ҧp CStroke ���t CDWordArray obj�A�ҥH��
//   Serialize() �����ĥ� obj.Serialize()
// �Ҧp CAnotherShapeList ���t CObList obj�A�ҥH��
//   Serialize() �����ĥ� obj.Serialize()
//------------------------------------------------------

#include <iostream>
#include "mfclite.h"
#include "mfclshp.h"
using namespace std;

IMPLEMENT_DYNCREATE(CShape, CObject)
IMPLEMENT_SERIAL(CSquare, CShape, 0)
IMPLEMENT_SERIAL(CRect, CSquare, 0)
IMPLEMENT_SERIAL(CCircle, CShape, 0)
IMPLEMENT_SERIAL(CEllipse, CCircle, 0)
IMPLEMENT_SERIAL(CTriangle, CShape, 0)
IMPLEMENT_SERIAL(CStroke, CShape, 0)
IMPLEMENT_SERIAL(CAnotherShapeList, CShape, 0)

void CSquare::display()
{
  cout << "CSquare:";
  cout << " x=" << m_x << ", y=" << m_y;
  cout << ", width=" << m_w << endl;
}

void CRect::display()
{
  cout << "CRect:";
  cout << " x=" << m_x << ", y=" << m_y;
  cout << ", height=" << m_h
       << ", width=" << m_w << endl;
}

void CCircle::display()
{
  cout << "CCircle:";
  cout << " x=" << m_x << ", y=" << m_y
       << " ,r=" << m_r1 << endl;
}

void CEllipse::display()
{
  cout << "CEllipse:";
  cout << " x=" << m_x << ", y=" << m_y;
  cout << ", r1=" << m_r1 << ", r2=" << m_r2 << endl;
}

void CTriangle::display()
{
  cout << "CTriangle:";
  cout << " x1=" << x1 << ", y1=" << y1;
  cout << " x2=" << x2 << ", y2=" << y2;
  cout << " x3=" << x3 << ", y3=" << y3 << endl;
}

void CStroke::display()
{
  CDWordArray* pDArray = (CDWordArray*)&(this->m_DArray);

  cout << "CStroke(" << pDArray->GetSize() << "):";

  for (int i = 0; i< pDArray->GetSize(); i++)
       cout << " " << (*pDArray)[i];
  cout << endl;
}

void CSquare::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    ar << m_x << m_y << m_w;
  }
  else
  {
    ar >> m_x >> m_y >> m_w;
    m_h = m_w;
  }
}

void CRect::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    ar << m_x << m_y << m_h << m_w;
  }
  else
  {
    ar >> m_x >> m_y >> m_h >> m_w;
  }
}

void CCircle::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    ar << m_x << m_y << m_r1;
  }
  else
  {
    ar >> m_x >> m_y >> m_r1;
    m_r2 = m_r1;
  }
}

void CEllipse::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    ar << m_x << m_y << m_r1 << m_r2;
  }
  else
  {
    ar >> m_x >> m_y >> m_r1 >> m_r2;
  }
}

void CTriangle::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    ar << x1 << y1 << x2 << y2 << x3 << y3;
  }
  else
  {
    ar >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
  }
}

void CStroke::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    m_DArray.Serialize(ar);   // OK�CDWordArray ������T�N�]�����|�Q�g�J�ɮ�

    // error code:
    // ar << &m_DArray;
  }
  else
  {
    m_DArray.Serialize(ar);   // �W���p�ĥ� Serialize()�A�o�̴N�ӹ����o��g�C

    // error code:
    // CDWordArray* pDArray = &m_DArray;
    // ar >> pDArray;         // �d�U�`�N�A���ઽ�� ar >> &m_DArray;
  }
}

//--------------------------------

void CAnotherShapeList::display()
{
  // ���X�Ҧ���ƨ����
  CObList* pObList = (CObList*)&(this->m_ObList);

  cout << "CAnotherShapeList:(" << pObList->GetCount() << "):" << endl;

  POSITION pos = (pObList)->GetHeadPosition();
  while (pos != NULL) {
      CObject* pO = (CObject*)pObList->GetNext(pos);
      CShape* pS = dynamic_cast<CShape*>(pO);
      assert(pS);
      pS->display();  // show it.
  }
  cout << endl;
}

void CAnotherShapeList::Serialize(CArchive& ar)
{
  CObject::Serialize(ar);

  if (ar.IsStoring())
  {
    m_ObList.Serialize(ar);   // OK�CCObList ������T�N�]�����|�Q�g�J�ɮ�

    // error code:
    // ar << &m_ObList;
  }
  else
  {
    m_ObList.Serialize(ar);   // �W���p�ĥ� Serialize()�A�o�̴N�ӹ����o��g�C

    // error code:
    // CObList* pObList = &m_ObList;
    // ar >> pObList;         // �d�U�`�N�A���ઽ�� ar >> &m_ObList;
  }
}
// ------------------ end of file --------------------------

