//------------------------------------------------------
// �ɦW�Gmfclapp.h
// �@�̡G�J�� J.J.Hou (jjhou), jjhou@jjhou.com, www.jjhou.com
// �γ~�G���� MFCLite�A�îi�{ MFC(Lite) App ���g�k
//   ���ɫŧi Application classes
//------------------------------------------------------

#include <iostream>
#include "mfclite.h"  // MFCLite Module
using namespace std;

//#define IDR_MAINFRAME  128 // �N���@�� icon,bitmap,menu,accel,string,toolbar
//#define IDR_MYDOCTYPE  129 // �N���@�� icon,menu,7-string�]�䤤 4th �O���ɦW�^
//#define IDR_MYDOCTYPE2 130 // �N���@�� icon,menu,7-string�]�䤤 4th �O���ɦW�^
// MFCLite �˱�W�z�覡�A�N IDR_xxx �ѡu�@��M UI�v²�Ƭ�
//   �@�Ӱ��ɦW�r��]�N�� doc �����^
#define IDR_MAINFRAME  string("")
#define IDR_MYDOCTYPE  string(".dat")
#define IDR_MYDOCTYPE2 string(".hou")
#define IDR_MYDOCTYPE3 string(".hoo")  //11
// �H�W���ӬO�� UINT�A�N���@��M GUI : icon,bitmap,menu,accel,string,toolbar�A
// �䤤���Ӧr��A���� 7 �Ӥl�r��A�ĥ|�Ӥl�r��N�����ɦW�A�]�N�O��󫬺A�C
// ���̭쥻���Q��b .rc �ɤ��C
// ���Ҭ��D²�ơA�����H�� ID �N���Ӱ��ɦW�]��Y��󫬧O�^�A�øm�󦹳B

class CMyWinApp;
class CMainFrame;
class CChildFrame;
class CMyDocument;
class CMyView;
class CMyDocument2;
class CMyView2;
class CMyView3;  //11

class CMyWinApp : public CWinApp
{
public:
      DECLARE_MESSAGE_MAP()
  virtual BOOL InitInstance();
  virtual int ExitInstance();  //11
  void OnAppAbout();
  CMultiDocTemplate* m_pDocTemplate3;   //11
  void OnAppHotKeyHelp();      //11
};

class CMainFrame : public CMDIFrameWnd     // 2001/11/14
{
      DECLARE_DYNCREATE(CMainFrame)
public:
      DECLARE_MESSAGE_MAP()
  virtual ~CMainFrame() { }
  int OnCreate(LPCREATESTRUCT lpcs);
  virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
  void OnWindowNew();       //11
};

class CChildFrame : public CMDIChildWnd    // 2001/11/14
{
      DECLARE_DYNCREATE(CChildFrame)
public:
      DECLARE_MESSAGE_MAP()
  virtual ~CChildFrame() { }
};

class CMyView : public CView
{
      DECLARE_DYNCREATE(CMyView)
public:
      DECLARE_MESSAGE_MAP()
  virtual ~CMyView() { }
  CMyDocument* GetDocument() const;
  virtual void OnDraw(/* CDC* pDC */);
  void OnLButtonDown(UINT nFlags, CPoint point);
  void OnLButtonUp(UINT nFlags, CPoint point);
  void OnMouseMove(UINT nFlags, CPoint point);
};

class CMyDocument : public CDocument
{
friend CMyView;
      DECLARE_DYNCREATE(CMyDocument)
public:
      DECLARE_MESSAGE_MAP()
  CMyDocument() { }
  virtual ~CMyDocument() { }
  void OnEditClearAll();
  virtual void Serialize(CArchive& ar);
private:
  CObList myList;
};

class CMyView2 : public CView
{
      DECLARE_DYNCREATE(CMyView2)
public:
      DECLARE_MESSAGE_MAP()
  virtual ~CMyView2() { }
  CMyDocument2* GetDocument() const;
  virtual void OnDraw(/* CDC* pDC */);
  void OnLButtonDown(UINT nFlags, CPoint point);
  void OnLButtonUp(UINT nFlags, CPoint point);
  void OnMouseMove(UINT nFlags, CPoint point);
};

class CMyView3 : public CView   //11
{
      DECLARE_DYNCREATE(CMyView3)
public:
      DECLARE_MESSAGE_MAP()
  virtual ~CMyView3() { }
  CMyDocument2* GetDocument() const;   // note the return type!
  virtual void OnDraw(/* CDC* pDC */);
  void OnLButtonDown(UINT nFlags, CPoint point);
  void OnLButtonUp(UINT nFlags, CPoint point);
  void OnMouseMove(UINT nFlags, CPoint point);
};

class CMyDocument2 : public CDocument
{
friend CMyView2;
friend CMyView3; //11
      DECLARE_DYNCREATE(CMyDocument2)
public:
      DECLARE_MESSAGE_MAP()
  CMyDocument2() { pDArray = new CDWordArray; }
  virtual ~CMyDocument2() { delete pDArray; }
  virtual void Serialize(CArchive& ar);
private:
  CDWordArray* pDArray;
};
//------------- end of file ---------------
