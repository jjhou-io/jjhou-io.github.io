//------------------------------------------------------
// �ɦW�Gmfclshp.h
// �@�̡G�J�� J.J.Hou (jjhou),  jjhou@jjhou.com,  www.jjhou.com
// �γ~�Gbased on MFCLite�A��@�H�U classes�G
//   CShape, CSquare, CRect, CCircle, CEllipse, CTriangle
// ���̳��P MFC(Lite) �ۮe�A���������~�Ӧ� CObject �ñĥ�
//   ���¦�س] Serialization�C
// �`�N�G���ϥΡuMFCLITE �T�j�S��v�A�����t�J mfclite.h
//------------------------------------------------------

#ifndef _MFC_SHAPE_
#define _MFC_SHAPE_

#include "mfclite.h"  // MFCLite module

class CShape : public CObject
{
      DECLARE_DYNCREATE(CShape)
public:
  virtual void display() { }
  virtual void Serialize(CArchive&) { }
};

class CRect : public CShape
{
      DECLARE_SERIAL(CRect)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
  CRect(float x=0.0, float y=0.0, float h=0.0, float w=0.0)
    { m_x = x;    m_y = y;    m_h = h;    m_w = w; }
protected:
  float m_x, m_y, m_h, m_w;
};

class CSquare : public CRect
{
      DECLARE_SERIAL(CSquare)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
  CSquare(float x=0.0, float y=0.0, float w=0.0)
    : CRect(x, y, w, w)   // ����δN�O�e���۵����|���
    { }
};

class CEllipse : public CShape
{
      DECLARE_SERIAL(CEllipse)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
  CEllipse(float x=0.0, float y=0.0, float r1=0.0, float r2=0.0)
    { m_x = x;  m_y = y;   m_r1 = r1;   m_r2 = r2; }
protected:
  float m_x, m_y, m_r1, m_r2;  // (x,y) �����J�I���@�Ar1, r2 �����u��b�C
};

class CCircle : public CEllipse
{
      DECLARE_SERIAL(CCircle)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
  CCircle(float x=0.0, float y=0.0, float r=0.0)
    : CEllipse(x, y, r, r)  // ��άO���u�b�۵�������
    { }
};

class CTriangle : public CShape
{
      DECLARE_SERIAL(CTriangle)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
  CTriangle(float x1val=0.0, float y1val=0.0,
            float x2val=0.0, float y2val=0.0,
            float x3val=0.0, float y3val=0.0)
  {
    x1 = x1val;  y1 = y1val;
    x2 = x2val;  y2 = y2val;
    x3 = x3val;  y3 = y3val;
  }
protected:
  float x1, y1, x2, y2, x3, y3;  // �T���Ϊ��T�ӳ��I
};

class CStroke : public CShape
{
      DECLARE_SERIAL(CStroke)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
public:
  CDWordArray m_DArray;   // hold elements by CDWordArray
};

//---------------------------------

class CAnotherShapeList : public CShape
{
      DECLARE_SERIAL(CAnotherShapeList)
public:
  virtual void display();
  virtual void Serialize(CArchive&);
public:
  CObList m_ObList;        // hold elements by CObList
};

#endif // _MFC_SHAPE_

