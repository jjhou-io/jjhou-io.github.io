// Author: J.J.Hou (Top Studio)
// File: Test2.java (test how to retrofit class)
// Note: this class use JQueue (generic form, compiled by JDK1.4+JSR14)
//                  and NQueue (non-generic form, compiled by JDK1.3)

import java.util.*;      // for Iterator
import java.io.*;        // for IO
import com.jjhou.util.*; // for d:\tij2\prog\com\jjhou\util\NQueue.class

public class Test2 {
  public static void main(String[] args)
  throws ClassNotFoundException, IOException {

    {
    // (1) JQueue<> ...
    JQueue<Employee> eq = new JQueue<Employee>();
    eq.push(new Employee("Finance", "MJChen"));
    eq.push(new Employee("Engineering", "JJHou"));
    eq.push(new Employee("Sales", "Grace"));
    eq.push(new Employee("Support", "Jason"));
    System.out.println(eq);
      // JQueue( [[dept=Support,name=Jason], [dept=Sales,name=Grace], [dept=Engineering,name=JJHou], [dept=Finance,name=MJChen]] )
    }

    {
    // (2) JQueue ...
    JQueue eq = new JQueue();
    eq.push(new Employee("Finance", "MJChen"));    // warning: unchecked call
    eq.push(new Employee("Engineering", "JJHou")); // warning
    eq.push(new Employee("Sales", "Grace"));       // warning
    eq.push(new Employee("Support", "Jason"));     // warning
    System.out.println(eq);
      // JQueue( [[dept=Support,name=Jason], [dept=Sales,name=Grace], [dept=Engineering,name=JJHou], [dept=Finance,name=MJChen]] )
    }

    {
    // (3) NQueue ... (existing no NQueue.java, just NQueue.class)
    NQueue eq = new NQueue();
    eq.push(new Employee("Finance", "MJChen"));
    eq.push(new Employee("Engineering", "JJHou"));
    eq.push(new Employee("Sales", "Grace"));
    eq.push(new Employee("Support", "Jason"));
    System.out.println(eq);
      // NQueue( [[dept=Support,name=Jason], [dept=Sales,name=Grace], [dept=Engineering,name=JJHou], [dept=Finance,name=MJChen]] )
    }

    /*
    {
    // (4) NQueue<> ... (existing no NQueue.java, just NQueue.class)
    NQueue<Employee> eq = new NQueue<Employee>();  // ERROR! type NQueue does not take parameters
    eq.push(new Employee("Finance", "MJChen"));
    eq.push(new Employee("Engineering", "JJHou"));
    eq.push(new Employee("Sales", "Grace"));
    eq.push(new Employee("Support", "Jason"));
    System.out.println(eq);
      // NQueue( [[dept=Support,name=Jason], [dept=Sales,name=Grace], [dept=Engineering,name=JJHou], [dept=Finance,name=MJChen]] )
    }
    */
  }
}

