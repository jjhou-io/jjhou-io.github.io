// Author: J.J.Hou (Top Studio)
// File: Test.java
//
// for GJ :
// build : gjc.bat Test.java  [x]
// build : gjcr.bat Test.java [o]
// options: gjcr Test.java -nowarn or gjcr Test.java -unchecked
// note : GJCR ������ PE2's EOF
// note : �������H�U "ERROR in GJ" �����C
//
// for JDK1.4 with JSR14 :
// build : javag.bat Test.java
// options: -gj -warnunchecked (�w���O�� javag.bat ��)
// note : JDK14 ���� PE2's EOF
// note : �L�k���� bounded type parameter.

import java.util.LinkedList;
import java.util.Collections;
import java.util.List;  // for List
import java.util.*;     // for Iterator
import java.io.*;       // for IO

public class Test {
  public static void main(String[] args)
  throws ClassNotFoundException, IOException {

    // (1) Integer list ...
    LinkedList<Integer> il = new LinkedList<Integer>();
    il.add(new Integer(0));
    il.add(new Integer(1));
    il.add(new Integer(5));
    il.add(new Integer(2));

    Iterator ite = il.iterator();
    while(ite.hasNext()) {
        System.out.println(ite.next());  // 0 1 5 2 (separated by '\n')
    }

    Integer tempi = il.iterator().next();
    System.out.println(tempi);            // 0
    Integer maxi = Collections.max(il);   // Algorithm
    System.out.println(maxi);             // 5

    Collections.sort(il);                 // Algorithm
    ite = il.iterator();
    while(ite.hasNext()) {
        System.out.println(ite.next());  // 0 1 2 5 (separated by '\n')
    }
    System.out.println(il);  // [0, 1, 2, 5]


    // (2) String list ...
    LinkedList<String> sl = new LinkedList<String>();
    sl.add("zero");
    sl.add("one");
    sl.add("two");
    sl.add("five");
    System.out.println(sl);  // [zero, one, two, five]

    String temps = sl.iterator().next();
    System.out.println(temps);           // zero
    String maxs = Collections.max(sl);   // Algorithm
    System.out.println(maxs);            // zero

    Collections.sort(sl);    // Algorithm
    System.out.println(sl);  // [five, one, two, zero]


    // (3) String list list ...
    LinkedList<LinkedList<String>> sll = new LinkedList<LinkedList<String>>();
    sll.add(sl);
    String temps2 = sll.iterator().next().iterator().next();
    System.out.println(temps2);    // five
    System.out.println(sll);       // [[five, one, two, zero]]



    // --- �H�U�N�X�� jjhou �K�[
    // --- ���զU�� collection classes ���x���ĪG�A
    // --- �� generic method & bounded type param.

    // (4) Double ArrayList ...
    ArrayList<Double> da = new ArrayList<Double>();
    da.add(new Double(3.3));
    da.add(new Double(1.1));
    da.add(new Double(5.5));
    da.add(new Double(2.2));
    System.out.println(da);  // [3.3, 1.1, 5.5, 2.2]

    System.out.println(Collections.max(da));   // 5.5
    Collections.sort(da);    // Algorithm
    System.out.println(da);  // [1.1, 2.2, 3.3, 5.5]


    // (5) char Vector ...
    Vector<Character> cv = new Vector<Character>();  // ERROR in GJ (GJ not support Vector?)
    cv.add(new Character('j'));
    cv.add(new Character('j'));
    cv.add(new Character('H'));
    cv.add(new Character('o'));
    cv.add(new Character('u'));
    System.out.println(cv);  // [j, j, H, o, u]

    System.out.println(Collections.max(cv));   // u
    Collections.sort(cv);    // Algorithm
    System.out.println(cv);  // [H, j, j, o, u]


    // (6) String HashSet ...
    HashSet<String> shs = new HashSet<String>();
    shs.add(new String("jjhou"));
    shs.add(new String("jason"));
    shs.add(new String("jamie"));
    shs.add(new String("jeremy"));
    shs.add(new String("jiangtao"));
    shs.add(new String("jou"));
    System.out.println(shs);  // [jjhou, jason, jeremy, jiangtao, jamie, jou]
    System.out.println(Collections.max(shs));   // jou


    // (7) Long TreeSet ...
    TreeSet<Long> lts = new TreeSet<Long>();
    lts.add(new Long(5));
    lts.add(new Long(2));
    lts.add(new Long(7));
    lts.add(new Long(4));
    System.out.println(lts);  // [2, 4, 5, 7]
    System.out.println(Collections.max(lts));   // 7


    // (8) Integer/String HashMap ...
    HashMap<Integer, String> ishm = new HashMap<Integer, String>();
    ishm.put(new Integer(3), new String("jjhou"));
    ishm.put(new Integer(1), new String("jason"));
    ishm.put(new Integer(9), new String("jamie"));
    ishm.put(new Integer(7), new String("jiang"));
    // System.out.println(Collections.max(ishm));
      // cannot resolve symbol: method max (java.util.HashMap<java.lang.Integer,java.lang.String>)
      // why?
    System.out.println(ishm);
      // {9=jamie, 7=jiang, 3=jjhou, 1=jason}


    // (9) Integer/String TreeMap ...
    TreeMap<Integer, String> istm = new TreeMap<Integer, String>();
    istm.put(new Integer(3), new String("jjhou"));
    istm.put(new Integer(1), new String("jason"));
    istm.put(new Integer(9), new String("jamie"));
    istm.put(new Integer(7), new String("jiang"));
    // System.out.println(Collections.max(istm));
      // cannot resolve symbol: method max (java.util.TreeMap<java.lang.Integer,java.lang.String>)
      // why?
    System.out.println(istm);
      // {1=jason, 3=jjhou, 7=jiang, 9=jamie}


    // (10) Employee TreeSet ...
    Employee empv[] = {
      new Employee("Finance", "Degree, Debbie"),
      new Employee("Finance", "Grade, Geri"),
      new Employee("Finance", "Extent, Ester"),
      new Employee("Engineering", "Measure, Mary"),
      new Employee("Engineering", "Amount, Anastasia"),
      new Employee("Engineering", "Ratio, Ringo"),
      new Employee("Sales", "Stint, Sarah"),
      new Employee("Sales", "Pitch, Paula"),
      new Employee("Support", "Rate, Rhoda"),
    };
    Set<Employee> emps = new TreeSet<Employee>(Arrays.asList(empv));
      // ERROR in GJ (GJ not support asList()?)
    System.out.println(emps); /*
                                [[dept=Engineering,name=Amount, Anastasia],
                                 [dept=Engineering,name=Measure, Mary],
                                 [dept=Engineering,name=Ratio, Ringo],
                                 [dept=Finance,name=Degree, Debbie],
                                 [dept=Finance,name=Extent, Ester],
                                 [dept=Finance,name=Grade, Geri],
                                 [dept=Sales,name=Pitch, Paula],
                                 [dept=Sales,name=Stint, Sarah],
                                 [dept=Support,name=Rate, Rhoda]]
                              */
    Employee maxEmp = Collections.max(emps);
      // �`�N�G�ݥO Set emps �f�t class Employee implements Comparable
      //   �ΥO Set<Employee> emps �f�t class Employee implements Comparable<Employee>
      //   �p���~��ϤW�z�� Collections.max(emps) ���\�C
      // �ѦҡG"Java Collections" p214 �M "GJ: A Generic Java" (DDJ)
      // �`�N�GCollections.max(coll) �|�̧ǱN�s�� coll ���C�Ӥ����૬�� Compariable �� Compariable<T>
      //   �X �� max(coll) �������s���O C coll�� C<T> coll �өw�A
      //   �M��I�s�� compareTo()�A�����d�U���j�̡C�� java source file collections.java

    System.out.println(maxEmp);
      // [dept=Support,name=Rate, Rhoda]


    // (11-1) test generic method Test.gm(List<T>) ...
    System.out.println(Test.gm(da));       // 1.1
    // System.out.println(Test.gm(emps));  // ERROR! �ܦn�A�]�� Set �ä��O�@�� List�C
    LinkedList<Employee> empl = new LinkedList<Employee>(Arrays.asList(empv));
      // ERROR in GJ (GJ not support asList()?)
    System.out.println(Test.gm(empl));     // [dept=Finance,name=Degree, Debbie]


    // (12) persistence (serialization) ...
    // print before write
    System.out.println(il);      // [0, 1, 2, 5]
    System.out.println(sl);      // [five, one, two, zero]
    System.out.println(sll);     // [[five, one, two, zero]]
    System.out.println(da);      // [1.1, 2.2, 3.3, 5.5]
    System.out.println(cv);      // [H, j, j, o, u]
    System.out.println(shs);     // [jjhou, jason, jeremy, jiangtao, jamie, jou]
    System.out.println(lts);     // [2, 4, 5, 7]
    System.out.println(ishm);    // {9=jamie, 7=jiang, 3=jjhou, 1=jason}
    System.out.println(istm);    // {1=jason, 3=jjhou, 7=jiang, 9=jamie}
    System.out.println(emps);

    ObjectOutputStream out =
      new ObjectOutputStream(
        new FileOutputStream("collect.out"));

    out.writeObject(il);
    out.writeObject(sl);
    out.writeObject(sll);
    out.writeObject(da);
    out.writeObject(cv);
    out.writeObject(shs);
    out.writeObject(lts);
    out.writeObject(ishm);
    out.writeObject(istm);
    out.writeObject(emps);
    out.close();  // also flush output stream

    ObjectInputStream in =
      new ObjectInputStream(
        new FileInputStream("collect.out"));

    // LinkedList il2             = (LinkedList<Integer>)in.readObject();
    // LinkedList<Integer> il2    = (LinkedList<Integer>)in.readObject();
    //   ERROR both!
    //   found   : java.lang.Object
    //   required: java.util.LinkedList<java.lang.Integer>
    // LinkedList<Integer> il2             = (LinkedList)in.readObject();
    //   Warning: unchecked assignment: java.util.LinkedList to java.util.LinkedList<java.lang.Integer>
    // LinkedList<Integer> il2             = in.readObject();
    //   ERROR!
    //   found   : java.lang.Object
    //   required: java.util.LinkedList<java.lang.Integer>
    //
    LinkedList il2  = (LinkedList)in.readObject();
    LinkedList sl2  = (LinkedList)in.readObject();
    LinkedList sll2 = (LinkedList)in.readObject();
    ArrayList da2   = (ArrayList)in.readObject();
    Vector cv2      = (Vector)in.readObject();
    HashSet shs2    = (HashSet)in.readObject();
    TreeSet lts2    = (TreeSet)in.readObject();
    HashMap ishm2   = (HashMap)in.readObject();
    TreeMap istm2   = (TreeMap)in.readObject();
    Set emps2       = (Set)in.readObject();
    in.close();

    // print after read
    System.out.println(il2);      // [0, 1, 2, 5]
    System.out.println(sl2);      // [five, one, two, zero]
    System.out.println(sll2);     // [[five, one, two, zero]]
    System.out.println(da2);      // [1.1, 2.2, 3.3, 5.5]
    System.out.println(cv2);      // [H, j, j, o, u]
    System.out.println(shs2);     // [jjhou, jason, jeremy, jiangtao, jamie, jou]
    System.out.println(lts2);     // [2, 4, 5, 7]
    System.out.println(ishm2);    // {9=jamie, 7=jiang, 3=jjhou, 1=jason}
    System.out.println(istm2);    // {1=jason, 3=jjhou, 7=jiang, 9=jamie}
    System.out.println(emps2);

    // (13) heterogenous Stack ...
    Stack<Integer> is = new Stack<Integer>();
    is.push(new Integer(0));
    is.push(new Integer(1));
    is.push(new Integer(5));
    is.push(new Integer(2));
    System.out.println(is);       // [0, 1, 5, 2]
    System.out.println(is.pop()); // 2
    System.out.println(is.pop()); // 5
    System.out.println(is.pop()); // 1
    System.out.println(is.pop()); // 0

    Stack myStack = new Stack();       // non-generic
    myStack.push(new Integer(4));      // warning:unchecked call to push(E) as a member of the raw type java.util.Stack
    myStack.push(new Double(4.4));     // warning
    myStack.push(new String("jjhou")); // warning
    System.out.println(myStack);       // [4, 4.4, jjhou]
    System.out.println((String)myStack.pop());  // jjhou (no downcast is also work)
    System.out.println((Double)myStack.pop());  // 4.4   (no downcast is also work)
    System.out.println((Integer)myStack.pop()); // 4     (no downcast is also work)

    // (14) heterogenous LinkedList ...
    LinkedList myList = new LinkedList();  // non-generic
    myList.add(new Double(4.4));           // warning
    myList.add(new String("jjhou"));       // warning
    System.out.println(myList);            // [4.4, jjhou]
    // System.out.println(Collections.max(myList));  // warning.
      // ERROR! Exception in thread "main" java.lang.ClassCastException

    // (15) JQueue ...
    JQueue<Employee> eq = new JQueue<Employee>();
    eq.push(new Employee("Finance", "MJChen"));
    eq.push(new Employee("Engineering", "JJHou"));
    eq.push(new Employee("Sales", "Grace"));
    eq.push(new Employee("Support", "Jason"));
    System.out.println(eq);
      // Queue( [[dept=Support,name=Jason], [dept=Sales,name=Grace], [dept=Engineering,name=JJHou], [dept=Finance,name=MJChen]] )
    System.out.println(eq.pop());     // [dept=Finance,name=MJChen]
    System.out.println(eq.pop());     // [dept=Engineering,name=JJHou]
    System.out.println(eq.pop());     // [dept=Sales,name=Grace]
    System.out.println(eq.pop());     // [dept=Support,name=Jason]
  }

  // (11-2) generic method & bounded type parameter.
  // public static <T implements Comparable<T>> T gm (List<T> list)
  //   ERROR in JDK14, but SUCCESS in GJ.
  //   if SUCCESSFUL then Test.gm(da) in (11-1) will fail,
  //   because Double type not implement bounded Comparable<Double> -- �J���{���C
  public static <T> T gm (List<T> list)
  {
    T temp = list.iterator().next(); // get the first one
    return temp;                     // and just return.
  }
}

