public class CCircle extends CShape {
  public void draw() { };
}    // CCircle is a CShape
