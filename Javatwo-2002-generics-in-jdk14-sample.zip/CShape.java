public abstract class CShape {
  public abstract void draw();  // always virtual in Java
}

