// Author: J.J.Hou (Top Studio)
// File: JQueue.java (generic form)
// compiled by JDK1.4+JSR14

import java.util.*;

public class JQueue<T>
{
  protected LinkedList<T> mySequence;

  public JQueue() {
    mySequence = new LinkedList<T>();
  }

  public boolean isEmpty() {
    return mySequence.isEmpty();
  }

  public int size() {
    return mySequence.size();
  }

  public boolean add(T obj) {
    return mySequence.add(obj);
  }

  public void push(T obj) {
    mySequence.addFirst(obj);
  }

  public synchronized T pop() {
    return mySequence.removeLast();
  }

  public synchronized String toString() {
    return "JQueue( " + mySequence.toString() + " )";
  }
}
