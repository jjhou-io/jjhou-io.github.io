// Author: J.J.Hou (Top Studio)
// File: NQueue.java (retrofitting file)
// compiled by JDK1.4: javag -retrofit xxx -d xxx

import java.util.*;

public class NQueue<T>
{
  protected LinkedList<T> mySequence;
  public NQueue();
  public boolean isEmpty();
  public int size();
  public boolean add(T obj);
  public void push(T obj);
  public synchronized T pop();
  public synchronized String toString();
}
