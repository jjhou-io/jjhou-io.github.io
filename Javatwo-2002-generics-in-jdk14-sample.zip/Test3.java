// File: Test3.java

import java.util.*;     // for Iterator

public class Test3 {
  static LinkedList<Employee> empl = new LinkedList<Employee>();

  public static void main(String[] args) {
      empl.add(new Employee("Finance", "Degree, Debbie"));
      Employee temp = Test3.gm(empl);
  }

  public static <T> T gm (List<T> list)
  {
      return list.iterator().next();
  }
}

