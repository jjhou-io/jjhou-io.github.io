public class CRect extends CShape {
  public void draw() { };
}      // CRect is a CShape
