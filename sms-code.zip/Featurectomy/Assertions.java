
class Assertions  {
    public static final boolean isEnabled = true; 
    // Change to false for release

    public static void assert( boolean assertion, String message ) {
        if (!assertion)
            {
                throw new Error( "Assertion failed: " + message );
            }
    }

    public static void main( String[] args ) {
        try {
            int x=0;
            if (Assertions.isEnabled)
                Assertions.assert( x == 1, "x is non-zero" );
            Assertions.assert( x==1, "second one" );
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
}


