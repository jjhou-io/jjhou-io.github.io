import  java.io.*;


class Sample {
    void check( int i ) {}
 
    public int sumsq(int x, int y) {
        int z = (x * x) + (y * y);
        check(z);
        return z;
    }
    public void main( String[] argc ) {
        System.out.println( "Answer: " + sumsq( 3,4 ) );
    }
}




