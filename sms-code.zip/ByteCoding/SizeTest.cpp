
//import  java.io.*;

//class Sample {
    void check( int i ) {}
//public: 
   int sumsqq(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqw(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqe(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqr(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqt(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqy(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqu(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqi(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqo(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqp(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqa(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqs(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqd(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqf(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqg(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqh(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqj(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqk(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsql(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqz(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqx(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqc(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqv(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqb(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqn(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqm(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq1(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq2(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq3(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq4(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq5(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq6(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq7(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq8(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq9(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsq0(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqqq(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqww(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqee(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqrr(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqtt(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsqyy(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }
   int sumsquu(int x, int y) {int z = (x * x) + (y * y); check(z); return z; }

//}
;
