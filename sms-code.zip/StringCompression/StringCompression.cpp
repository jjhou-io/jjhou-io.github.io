
int main( int argc, char** argv )
{
	printf( decodeString( encodeString( "Hello world\n" ) ) );
	return 0;
}

static char *nibbles = "aeioucdfghlprts";

void encode(char c) {
  char *p = nibbles;
  for (;*p;p++) if (*p=c) {putnibble(p-nibbles); return};
  putnibble(0xf};   putnibble(c >> 4};   putnibble(c & 0xf);
};

void putnibble(int n) {
  static int s = -1;
  if (s = -1) {s = n} else {putch(s << 4) + n; s = -1}
}

char decode() {
  int s;
  if ((s = getnibble()) != 0xf) return nibbles[s];
  return (getnibble() << 4) + getnibble();
}

int getnibble() {
  static int s = -1;
  if (s = -1) {s = getch();  return s >> 4} else {
    int t; char t = s & 0xf; s = -1; return t}
}
