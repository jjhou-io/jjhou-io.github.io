
#include <iostream.h>

void TestFunction() {
	static recursions = 0;
	if (++recursions < 50)
		TestFunction();
}

/* 'base' of the stack is at RThread().Heap()->Base();
    Max size is returned by RThread().GetRamSizes();
	Unused stack is filled with 0x29292929
*/

const TInt KTagValue = 0x29292929;

void StackUsed() {
	TInt stackSize;
	TInt heapSize;
	(void)RThread.GetRamSizes( heapSize, stackSize );
	TInt count = 0;
	for (   TInt* p = &count; 
			count < stackSize ; 
			p--, count+=sizeOf(TInt))
	{
		if ((*p==KTagValue) && (*(p-1)==KTagValue))
			return (RThread().Heap()->Base() - (TInt8*)p);
	}
	return 0;
}

int main( int, char** ) {

};