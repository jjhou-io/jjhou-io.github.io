
class ROMAble {
    //      static final int[] table = { 1000, 1342, 1234, 12433, 143, 1341, 134324,
    //                            124, 1234, 3456, 2345 };
    static final String table =
        "\001\002ABCDEFGHIJ";
    static int useIt() {
        return (int)table.charAt( 0 );
    }
    static void main( String[] args ) {
        System.out.println( "Table at 0 is " + useIt() );
    }
};


