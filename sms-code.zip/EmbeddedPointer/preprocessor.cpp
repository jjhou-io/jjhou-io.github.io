#include <iostream.h>

#define ASSERT( i ) {if (!(i)) cout << "Assert fail: " #i "line " << \
 __LINE__ << endl;} 

class A { public:
  A( int i ) : x( i ) { cout << i << " created\n"; }
  ~A() { cout << x << " deleted\n"; }
private: 
  int x;
public:
  A* next;
};


A* ListHead;
template <class T> T* dummy_function_to_save_listPtr( T*& list, T* next ) { 
  T* x = list; list = next; return x; } 
#define ADD_LIST( LIST, ITEM, NEXT ) \
{(ITEM)->NEXT = (LIST); (LIST) = (ITEM);}
#define GET_LIST( LIST, NEXT ) \
dummy_function_to_save_listPtr( (LIST), (LIST)->NEXT )


class B { public: B* next; };

int main()
{
  B* ListOfB = 0;
  B* b = new B;
  ADD_LIST( ListOfB, b, next );
  delete GET_LIST( ListOfB, next );

  ASSERT( ListHead == 0 );
  A* x = new A( 0 );
  ADD_LIST( ListHead, x, next );
  ASSERT( ListHead == x );
  ASSERT( GET_LIST( ListHead, next ) == x );
  ASSERT( ListHead == 0 );
  delete x;
  for (int i=0; i<3; i++)
    {
      x = new A( i );
      ADD_LIST( ListHead, x, next );
    }
  for (; ListHead ;)
    delete GET_LIST( ListHead, next );
  ASSERT( ListHead == 0 );
}



