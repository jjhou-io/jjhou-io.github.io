
#include <iostream.h>
#include <assert.h>
#include <string.h>

class String {
public:
  String( char* _rep ) : rep( strdup( _rep ) ) {}
  char operator[]( int i ) const { return rep[i]; }
  char& operator[]( int i ) { return rep[i]; }
  // copy ctor, operator= and dtor also required
private:
  char* rep;
};



int main()
{
  String x( "hello" );
  assert( x[1] == 'e' );
  x[1] = 'f';
  assert( x[1] == 'f' );
  const String y( "hello" );
  assert( y[1] == 'e' );
  return 0;
}

/* 
void foo( const String& p );
void foo( String p );
*/
