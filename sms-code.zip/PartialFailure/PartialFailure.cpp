
#include <iostream.h>
#include <Memory>

using namespace std;

class NetworkInterfaceClass { public:
  void doSomethingWhichCallsAnException() { throw "hello"; }
  ~NetworkInterfaceClass() { cout << "dtor called"; }
};


int main() {
  auto_ptr<char> c;
  try {
    auto_ptr<NetworkInterfaceClass> p(new NetworkInterfaceClass);
    p->doSomethingWhichCallsAnException();  // p is now orphaned
    NetworkInterfaceClass* q = p.release();
  }
  catch ( ... ) {
    cout << "Exception caught\n";
  }
  return 0;
}


