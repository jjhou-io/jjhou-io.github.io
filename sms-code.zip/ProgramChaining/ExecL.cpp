
#include <iostream>
#include <string>

using namespace std;

#define SAY( x ) { cout << x << endl; }

#include <process.h>


void ChainToCommand( string command )
{
	const char *args[4];
	args[0] = getenv( "comspec" );
	args[1] = "/c";
	args[2] = command.c_str();
	args[3] = 0;
	_execv( args[0], args );
}

void main(int argc, char** argv)
{
	ChainToCommand( "notepad xxx.txt" );
}


