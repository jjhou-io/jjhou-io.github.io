
import java.io.*;
// import java.awt.Frame;


class Executor {
    
    public static void main(String[]args){
        new Executor().testAll();
    }

    /**
       there is something funny going on.
       The first couple of tests work, but trying to repeat 'dir com*.*' 
       produces no output!
    */
    
    public void testAll() {
        String prefix = "command.com /c ";  // Needs to be full path of command for MS Java
        test( prefix + "echo hullo " );
        test( prefix + "dir "); 
        test( prefix + "dir com*.*" );
        test( prefix + "cd " ); 
 
        test( prefix + "dir com*.*" ); //different  output 2nd 
        //time - drive D has no label!
        //test( prefix + "command.com /c cd " );  // works
        //test( prefix + "command.com /c cd . " ); // hangs
        //test( prefix + "command.com /c cd dummy " ); //hangs 
        test( prefix + "command.com /c echo goodbye " );
    }
    
    public void test(String command) {
        System.out.println("\n\ncommand = " + command + "\n----------------" );
        String result = execute(command);
        System.out.println( result + "\n----------------------" );
    }
    
    
    public String  execute( String theCommand ) {
        // Usage example (MS Windows):
        //     String s = execute( prefix + "command.com /c dir .  " );
    
        // if the command fails, empty string returned - e.g. "cd iDontExist"

        // note that ready() is false before first read. That is why it is tested 
        //after first read. 
        //However if first read blocks, we are stuck!
    
        String result = "";

        try {

            Process proc = Runtime.getRuntime().exec(theCommand);
            InputStream resultStream = proc.getInputStream();
            BufferedReader br = new BufferedReader( new InputStreamReader(resultStream) );
            while ( true ) {
                String line = br.readLine();
                result += line + "\n" ;
                if (!br.ready()) break; // must be tested after first readLine
            } // while

        } catch(Exception e){ 
            System.out.println("caught " + e);
            e.printStackTrace();
            
        }; //try catch
        
        return result;
    } // execute


} // class
