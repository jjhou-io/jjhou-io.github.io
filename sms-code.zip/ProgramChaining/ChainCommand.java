import java.util.*;
import java.io.*;

class ChainCommand
{
    public static void assert (boolean  assertion, String excuse) {
        if  (!assertion) { throw new RuntimeException(excuse);}
    }

    public static void progress (String msg) {System.out.print(msg);}

    public static void main( String[] args )  {
        progress(".");
        try {
            String s = ExecuteACommand( "command.com /c dir"  );
            System.out.println( "Command DIR returned: " + s );
            //          ChainToCommand( "c:\\windows\\notepad.exe" );
        } catch ( IOException e ) {
            assert( false, "IOException thrown " + e );
        }
        System.out.println("done!");
    }

    static String ExecuteACommand( String theCommand ) throws IOException {
        Process p = Runtime.getRuntime().exec(theCommand);
        InputStream processOutput = p.getInputStream();
        String result = new String();
        byte buf[] = new byte[20];
        int i;
        while ((i = processOutput.read(buf)) >= 0)
            result = result + new String( buf, 0, 0, i );
        return result;
    }

    static void ChainToCommand( String theCommand ) throws IOException  {
        Runtime.getRuntime().exec(theCommand);
        Runtime.getRuntime().exit( 0 );
    }
}


