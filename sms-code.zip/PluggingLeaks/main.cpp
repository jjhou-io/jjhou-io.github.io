
void* operator new( unsigned int, int, char*, int );

#define new(x) new(x, __FILE__, __LINE__ )

int main()
{
	char* x = new char;
	char* y = new( 3 ) char;
}
