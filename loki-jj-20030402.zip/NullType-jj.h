// Loki �J���վ㪩
// �ɦW : NullType-jj.h
// �ھ� : Loki's NullType.h
// �վ�� : jjhou
// �̫����� : 20030402
// �����G���ɶȬ��ӤH�׽m����
// �A�ΡGGNU-C++ 3.2 (MinGW-2.0.0-3,special 20020817-1)  
//       GNU-C++ 2.95.3-5 (Cygwin special,20010316)
// �sĶ�Gcommand line mode �����H g++ �sĶ�A���ݥ���ﶵ�]options�^


////////////////////////////////////////////////////////////////////////////////
// The Loki Library
// Copyright (c) 2001 by Andrei Alexandrescu
// This code accompanies the book:
// Alexandrescu, Andrei. "Modern C++ Design: Generic Programming and Design 
//     Patterns Applied". Copyright (c) 2001. Addison-Wesley.
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author or Addison-Welsey Longman make no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

// Last update: February 19, 2001


#ifndef NULLTYPE_INC_
#define NULLTYPE_INC_


namespace Loki
{
    class NullType {};  	// ref. NullType.h
}   

#endif // NULLTYPE_INC_
