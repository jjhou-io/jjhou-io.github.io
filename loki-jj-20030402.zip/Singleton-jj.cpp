// Loki �J���վ㪩
// �ɦW : Singleton-jj.cpp
// �ھ� : Loki's Singleton.cpp
// �վ�� : jjhou
// �̫����� : 20030402
// �����G���ɶȬ��ӤH�׽m����
// �A�ΡGGNU-C++ 3.2 (MinGW-2.0.0-3,special 20020817-1)  
//       GNU-C++ 2.95.3-5 (Cygwin special,20010316)
// �sĶ�Gcommand line mode �����H g++ �sĶ�A���ݥ���ﶵ�]options�^


////////////////////////////////////////////////////////////////////////////////
// The Loki Library
// Copyright (c) 2001 by Andrei Alexandrescu
// This code accompanies the book:
// Alexandrescu, Andrei. "Modern C++ Design: Generic Programming and Design 
//     Patterns Applied". Copyright (c) 2001. Addison-Wesley.
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author or Addison-Welsey Longman make no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

// Last update: February 19, 2001

#include "Singleton-jj.h"
#include <iostream>
using namespace std;

using namespace Loki::Private;

// �H�U���쥻�O extern�C�sĶ���L�]�ӷ��p���^�C�J���� extern �����C
TrackerArray Loki::Private::pTrackerArray = 0;
unsigned int Loki::Private::elements = 0;

////////////////////////////////////////////////////////////////////////////////
// function AtExitFn
// Ensures proper destruction of objects with longevity
////////////////////////////////////////////////////////////////////////////////

void Loki::Private::AtExitFn()
{
    // cout << "AtExitFn()" << endl;  // jjhou
    
    assert(elements > 0 && pTrackerArray != 0);
    // Pick the element at the top of the stack
    LifetimeTracker* pTop = pTrackerArray[elements - 1];
    // Remove that object off the stack
    // Don't check errors - realloc with less memory 
    //     can't fail
    pTrackerArray = static_cast<TrackerArray>(std::realloc(
        pTrackerArray, --elements));
    // Destroy the element
    delete pTop;
}
