// �mC++�]�p�s����n�]Modern C++ Design�^��07�� Smart Pointers ���յ{��
// last update : 20030402
// �A�νsĶ���GGNU-C++ 3.2 (MinGW-2.0.0-3,special 20020817-1) 

// cb6[o], cb5[o], 
// g32[o]
// gcc291[x]
// g295[x]: Internal compiler error 
// vc6[x]:template definitions cannot nest

#include <iostream>
#include <string>
#include <cstdlib>  // for malloc()
#include <new>      // for placement new
using namespace std;

// policy class 1
template <class T>
struct OpNewCreator
{
  static T* Create()
  {
    cout << "OpNewCreator::Create()" << endl;
    return new T;
  }
protected:
  ~OpNewCreator() { cout << "OpNewCreator::dtor" << endl; }
};

// policy class 2
template <class T>
struct MallocCreator
{
  static T* Create()
  {
    cout << "MallocCreator::Create()" << endl;
    void* buf = malloc(sizeof(T));
    if (!buf) return 0;
    return new(buf) T;  // placement new, invoke ctor
  }
//protected: // ���F test6�A�ڧ⦹�B�אּ public:
  ~MallocCreator() { cout << "MallocCreator::dtor" << endl; }
};

// policy class 3
template <class T>
struct PrototypeCreator
{
  PrototypeCreator(T* pObj = 0)
    : pPrototype_(pObj)
  { }

  T* Create()
  {
    cout << "PrototypeCreator::Create()" << endl;
    return pPrototype_ ? pPrototype_->Clone() : 0;
  }

  T* GetPrototype() { return pPrototype_; }
  void SetPrototype(T* pObj) { pPrototype_ = pObj; }

private:
  T* pPrototype_;
protected:
  ~PrototypeCreator() { 
      cout << "PrototypeCreator::dtor" << endl;  
      if (pPrototype_) delete pPrototype_; 
  }
};



// lib code
// implementing policy classes with "template template parameters"
class Widget;  // Q: �p�G�o��O lib�A������n�D lib ���D user-defined class �O�H
class Gadget;

template<
    template <class /* Created */ >                      // "Created" needless!
    class CreationPolicy = OpNewCreator >                // default policy
class WidgetManager : public CreationPolicy<Widget>      // using policy
{
public:	
  // �U���o�Ө禡�u���b "Prototype policy" ���p�U�~�|�Q�Ψ�A�]�]���~�|�Q�sĶ�C	
  void SwitchPrototype(Widget* pNewPrototype)
  {
  	CreationPolicy<Widget>& myPolicy = *this;   // jjhou:up-cast
  	delete myPolicy.GetPrototype();
  	myPolicy.SetPrototype(pNewPrototype);
  }	
  
  // �ϥΦP�@�� create-policy�A���ͤ��P�� object.
  void DoSomething()
  {
        Gadget* pw= CreationPolicy<Gadget>().Create();	
        // �W�沣�ͼȮɪ���A���`�ɷ|��_ CreationPolicy<Gadget> �� dtor.
        // �p�G�� dtor �O protected�A����K�L���F�C���ڻ{���ثe�b derived class ���A
        // ���ӥi�H��_ base class's protected method ���ڡC
        pw->func();
        delete pw;
  }	
};

//---------------------------------------------------------------

// application code
class Widget
{
public:
  Widget(int x=0, int y=0) : x_(x),y_(y) { }
  ~Widget() { cout << "Widget::dtor" << endl; }
  void func() { cout << '[' << x_ << ',' << y_ << ']' << endl; }
  Widget* Clone() { return new Widget(*this); }
private:
  int x_, y_;
};

class Gadget
{
public:
  Gadget() : str_(string("hello")) { }
  Gadget(const string& str) : str_(str) { }
  ~Gadget() { cout << "Gadget::dtor" << endl; }
  void func() { cout << '[' << str_ << ']' << endl; }
  Gadget* Clone() { return new Gadget(*this); }
private:
  string str_;
};


int main()
{
  { // test1
  typedef WidgetManager< OpNewCreator > myWidgetMgr;
  myWidgetMgr wMsg;
  Widget* pw = wMsg.Create();   // OnNewCreator::Create()
  pw->func();                   // [0,0]
  delete pw;
  }

  { // test2
  typedef WidgetManager< MallocCreator > myWidgetMgr;
  myWidgetMgr wMsg;
  Widget* pw = wMsg.Create();   // MallocCreator::Create()
  pw->func();                   // [0,0]
  delete pw;
  }

  { // test3
  typedef WidgetManager< PrototypeCreator > myWidgetMgr;
  myWidgetMgr wMsg;
  
  wMsg.SetPrototype(new Widget(1,1));
  Widget* pw = wMsg.Create();   // PrototypeCreator<T>::Create()
  pw->func();                   // [1,1]
  delete pw;
  
  wMsg.SetPrototype(new Widget(2,2));   
  // �H�W�|�y�� memory leak�C���� GetPrototype(), �A delete�A�A SetPrototype()
  pw = wMsg.Create();           // PrototypeCreator<T>::Create()
  pw->func();                   // [2,2]  
  delete pw;
  }

  { // test4
  typedef WidgetManager< PrototypeCreator > myWidgetMgr;
  myWidgetMgr wMsg;
  
  wMsg.SetPrototype(new Widget(3,3));
  Widget* pw = wMsg.Create();   // PrototypeCreator<T>::Create()
  pw->func();                   // [3,3]
  delete pw;
  
  wMsg.SwitchPrototype(new Widget(4,4));  // no memory leak
  pw = wMsg.Create();           // PrototypeCreator<T>::Create()
  pw->func();                   // [4,4]  
  delete pw;
  }

  { // test5
  typedef WidgetManager< > myWidgetMgr;  // use default argument
  myWidgetMgr wMsg;
  Widget* pw = wMsg.Create();   // OnNewCreator<T>::Create()
  pw->func();                   // [0,0]
  delete pw;
  }

  { // test6
  typedef WidgetManager< MallocCreator > myWidgetMgr;
  myWidgetMgr wMsg;
  Widget* pw = wMsg.Create();   // MallocCreator::Create()
  pw->func();                   // [0,0]
  wMsg.DoSomething();           // [hello]Gadget::dtor
     // �W��L���F�CCB ���~�T���O�G
     //   Destructor for 'MallocCreator<Gadget>' is not accessible
     // �p�G�ڱN MallocCreator <T> �� protected dtor �אּ public
     //   �h CB5 �K�q�L�F�]�� G291 �̵M�L�k�sĶ�^�C
  delete pw;
  }
}
