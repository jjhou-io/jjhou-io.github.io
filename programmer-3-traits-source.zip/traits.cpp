#include <iostream>
#include <cstddef>   // for ptrdiff_t
using std::cout;

template <class T>
struct MyIter {
  typedef T          value_type;       // nested type�]�_�����O�ŧi�^
  typedef ptrdiff_t  difference_type;  // nested type�]�_�����O�ŧi�^
  typedef T&         reference;        // nested type�]�_�����O�ŧi�^
  typedef T*         pointer;          // nested type�]�_�����O�ŧi�^
  T* ptr;
  MyIter(T* p=0) : ptr(p) { }
  T& operator*() const { return *ptr; }
  // ...
};

template <class Iterator>
typename Iterator::value_type  // �o�@���O func ���^�𫬧O
func(Iterator ite)
{ return *ite; }




template <class I>
struct iterator_traits {   // traits �N���u�S�ʡv
  typedef typename I::value_type        value_type;
  typedef typename I::difference_type   difference_type;
  typedef typename I::pointer           pointer;
  typedef typename I::reference         reference;
};

// partial sepecialization 1
template <class T>
struct iterator_traits<T*> {   // �S�ƪ��Giterator �O�@�� pointer
  typedef T          value_type;
  typedef ptrdiff_t  difference_type;
  typedef T*         pointer;
  typedef T&         reference;
};

// partial sepecialization 2
template <class T>
struct iterator_traits<const T*> {  // �S�ƪ��Giterator �O�@�� pointer-to-const
  typedef T          value_type;
  typedef ptrdiff_t  difference_type;
  typedef const T*   pointer;
  typedef const T&   reference;
};


template <class I>
typename iterator_traits<I>::value_type  // �o�@���O func ���^�𫬧O
func2(I ite)
{ return *ite; }



int main()
{
   // ...
   MyIter<int> ite(new int(8));
   cout << func(ite);
   cout << func2(ite);

   int* pi = new int(5);
   cout << func2(pi);
   const int* pci = new int(9);
   cout << func2(pci);

}

