// VC6 [x], BCB4 [o], G++ [o]  (VC6 not support partial-specialization)

#include <iostream>
#include <cstddef>  // for ptrdiff_t
using std::cout;
using std::endl;
// �`�N�A����}�� namespace std; �_�h�|�M std �� iterator_trait �Ĭ�

struct input_iterator_tag { };
struct output_iterator_tag { };
struct forward_iterator_tag : public input_iterator_tag { };
struct bidirectional_iterator_tag : public forward_iterator_tag { };
struct random_access_iterator_tag : public bidirectional_iterator_tag { };

template <class I>
struct iterator_traits {
  typedef typename I::iterator_category  iterator_category;
  typedef typename I::value_type         value_type;
  typedef typename I::difference_type    difference_type;
  typedef typename I::pointer            pointer;
  typedef typename I::reference          reference;
};

// partial specialization for native pointer
template <class T>
struct iterator_traits<T*> {
  typedef random_access_iterator_tag  iterator_category;
  typedef T                           value_type;
  typedef ptrdiff_t                   difference_type;
  typedef T*                          pointer;
  typedef T&                          reference;
};

// partial specialization for native pointer-to-const
template <class T>
struct iterator_traits<const T*> {
  typedef random_access_iterator_tag  iterator_category;
  typedef T                           value_type;
  typedef ptrdiff_t                   difference_type;
  typedef const T*                    pointer;
  typedef const T&                    reference;
};

// base iterator class
template <class Category,
          class Value,
          class Distance = ptrdiff_t,
          class Pointer = Value*,
          class Reference = Value&>
struct iterator {
  typedef Category  iterator_category;
  typedef Value     iterator_value;
  typedef Distance  iterator_distance;
  typedef Pointer   iterator_pointer;
  typedef Reference iterator_reference;
};


// a generic algorithm
template <class InputIterator>
typename iterator_traits<InputIterator>::value_type
sum_nonempty(InputIterator first, InputIterator last)
{
  typename iterator_traits<InputIterator>::value_type  result = *first++;
  for (; first != last; ++first)
    result += *first;

  return result;
}

// another generic algorithm
template< class InputIterator, class T >
typename iterator_traits<InputIterator>::difference_type
count( InputIterator first, InputIterator last, const T& x )
{
   typename iterator_traits<InputIterator>::difference_type n = 0;
   for ( ;  first != last; ++first)
     if (*first == x)
       ++n;
   return n;
}


// generic algorithm advance()...
template <class InputIterator, class Distance>
void advance(InputIterator& i, Distance n, input_iterator_tag)
{
  for ( ; n > 0; --n, ++i );
}

template <class BidirectionalIterator, class Distance>
void advance(BidirectionalIterator& i, Distance n, forward_iterator_tag)
{
  advance(i, n, input_iterator_tag());
}

template <class RandomAccessIterator, class Distance>
void advance(RandomAccessIterator& i, Distance n, random_access_iterator_tag)
{
  i += n;
}

template <class BidiectionalIterator, class Distance>
void advance(BidiectionalIterator& i, Distance n, bidirectional_iterator_tag)
{
  if (i >= 0)
      for ( ; n > 0; --n, ++i ) { }
  else
      for ( ; n < 0; ++n, --i ) { }
}

// top level advance()
template <class Iterator, class Distance>
inline void advance(Iterator& i, Distance n)
{
  advance(i, n, iterator_traits<Iterator>::iterator_category());
}



template <class Category,
          class Value,
          class Distance = ptrdiff_t,
          class Pointer = Value*,
          class Reference = Value&>
class MyIter : public iterator<Category,
                               Value,
                               Distance,
                               Pointer,
                               Reference>
{

};

void main()
{
  int ia[5] = {0, 1, 2, 3, 4};
  int total = sum_nonempty(ia, ia+5);
  cout << total << endl;  // 10
  int c = count(ia, ia+5, 2);
  cout << c << endl;      // 1

  cout << *ia << endl;    // 0
  int* pi = &(ia[0]);
  advance(pi, 3);
  cout << *pi << endl;    // 3

  MyIter<random_access_iterator_tag, int> myiter;

}

