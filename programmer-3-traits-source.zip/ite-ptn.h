// based on [Gamma95] 5.4.10

class IteratorOutOfBounds { };

template <typename Item>  // note: Item is value-type, not node-type
class Iterator
{
public:
  virtual void First() = 0;
  virtual void Next() = 0;
  virtual bool IsDone() const = 0;
  virtual Item CurrentItem() const = 0;
protected:
  Iterator() { };   // protected ctor, �� derived class �~�L�H�i�ϥ�
                    // �i�קK�Q client �ϥΡC
};

template <typename Item>
class ListIterator : public Iterator<Item>
{
public:
  ListIterator(const List<Item>* aList)
    : _list(aList), _current(0) {  }

  // [Lippman98] 15.11 �`���L�����w�o�ظѪk (�n�S First �M Next)
  virtual void First() { _current = 0; }
  virtual void Next()  { _current++;   }
  virtual bool IsDone() const { return _current >= _list->size(); }
  virtual Item CurrentItem() const {
     if (IsDone())
         throw IteratorOutOfBounds();
     return _list->Get(_current);
  }

private:
  const List<Item>* _list;
  long _current;
};

template <typename Item>
class ReverseListIterator : public Iterator<Item>
{
public:
  ReverseListIterator(const List<Item>* aList)
    : _list(aList), _current(_list->size()-1) {  }

  virtual void First() { _current = _list->size()-1; }
  virtual void Next()  { _current--;   }
  virtual bool IsDone() const { return _current < 0; }
  virtual Item CurrentItem() const {
     if (IsDone())
         throw IteratorOutOfBounds();
     return _list->Get(_current);
  }

private:
  const List<Item>* _list;
  long _current;
};
