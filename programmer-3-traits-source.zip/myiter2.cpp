// myiter2 �P myiter ���t���b��A���Ҩϥ� std::iterator �ӳ]�p ListIter.
#include "c:\g001p\prog\mylist.cpp"      // inclusion model
#include "find3.h"       // inclusion model
#include <iostream>
#include <iterator>
using std::cout;
using std::endl;
using std::iterator;
using std::forward_iterator_tag;

// Item �i�H�O��V��C�`�I�����V��C�`�I
// �o�� iterator �S�w�u�� list �A�ȡA
// �]����W�S�� operator++ ���G
template <class Item>
struct ListIter : public iterator<forward_iterator_tag, Item>
{
  Item* ptr;

  ListIter(Item* p = 0)  // default ctor
    :  ptr(p) { }

  // �S����@ copy ctor�A�]���sĶ�����Ѫ��w�]�欰�w�����C
  // �S����@ operator=�A�]���sĶ�����Ѫ��w�]�欰�w�����C

  Item& operator*()  const { return *ptr; }
  Item* operator->() const { return  ptr; }

  // pre-increment operator
  ListIter& operator++()
     { ptr =  ptr->next(); return *this; }

  // post-increment operator
  ListIter  operator++(int)
     { ListIter tmp = *this; ++*this; return tmp; }

  bool operator==(const ListIter& i) const
    { return ptr == i.ptr; }
  bool operator!=(const ListIter& i) const
    { return ptr != i.ptr; }
};


template <typename T>
bool operator!=(const ListItem<T>& item, T n)   // expose ListItem. bad
 {  return item.value() != n; }


void main()
{
   List<int> mylist;

   for(int i=0; i<5; ++i) {
       mylist.insert_front(i);
       mylist.insert_end(i+2);
   }
   mylist.display();               // 10 ( 4 3 2 1 0 2 3 4 5 6 )

   ListIter<ListItem<int> > begin(mylist.front());  // expose ListItem! bad!
   // ListIter<ListItem<int> > end(mylist.end());
   ListIter<ListItem<int> > end;  // default is 0, null
   ListIter<ListItem<int> > iter;

   // test operator
   cout << (*begin).value() << endl;      // 4
   // cout << (*end).value() << endl;        // 6
   cout << (begin != end) << endl;        // 1
   iter = begin;
   cout << (begin != iter) << endl;       // 0
   cout << (*(++iter)).value() << endl;   // 3

   // test operator
   cout << begin->value() << endl;        // 4
   iter = begin;
   cout << (++iter)->value() << endl;     // 3



   iter = find(begin, end, 3);
   if (iter == end)
       cout << "not found" << endl;
   else
       cout << "found. " << iter->value() << endl;   // v

   iter = find(begin, end, 7);
   if (iter == end)
       cout << "not found" << endl;                  // v
   else
       cout << "found. " << iter->value() << endl;

   iter = find(begin, end, 6);
   if (iter == end)                                  // v
       cout << "not found" << endl;
   else
       cout << "found. " << iter->value() << endl;
}



