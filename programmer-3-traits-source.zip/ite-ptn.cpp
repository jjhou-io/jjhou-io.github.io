// based on [Gamma95] 5.4.10

#include "mylist.cpp"    // inclusion model
#include "ite-ptn.h"
#include <string>
#include <iostream>

using std::cout;
using std::endl;
using std::string;


class Employee {
public:
  Employee(string name)
    : _name(name) {  }

  void Print() { cout << _name << endl; }
private:
  string _name;
};


// [Lippman98] 15.11 �`���L�����w�o�ظѪk (�n�S First �M Next)
void PrintEmployees(Iterator<Employee*>& i) {
   for(i.First(); !i.IsDone(); i.Next()) {
      i.CurrentItem()->Print();
   }
}

int main()
{
  List<Employee*>* myEmployees = new List<Employee*>;

  myEmployees->insert_end(new Employee(string("jjhou")));
  myEmployees->insert_end(new Employee(string("mjchen")));
  myEmployees->insert_end(new Employee(string("dongdong")));
  myEmployees->insert_end(new Employee(string("jason")));
  myEmployees->insert_end(new Employee(string("allan")));
  myEmployees->insert_end(new Employee(string("steve")));

  ListIterator<Employee*> forward(myEmployees);
  PrintEmployees(forward);

  ReverseListIterator<Employee*> backward(myEmployees);
  PrintEmployees(backward);
}

