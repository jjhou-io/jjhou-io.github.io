// based on C++ Primer 3/e, section 5.11

#ifndef _JJLIST__
#define _JJLIST__

#include <iostream>

class ListOutOfBounds { };

template <typename T>
class ListItem;         // forward declaration

template <typename T>
class List
{
public:
  List() : _front(0), _end(0), _size(0) { }
  ~List() { remove_all(); }

  // meyers1, item11, ���Ӭ� List �ŧi copy ctor �M copy assignment operator
  List(const List& rhs);
  List& operator=(const List& rhs);

  long size() const { return _size; }
  ListItem<T>* front() const { return _front; }
  ListItem<T>* end() const { return _end; }

  ListItem<T>* find(T value) const;

  ListItem<T>* remove(const ListItem<T>* ptr);
  int remove(T value);
  void remove_front();
  void remove_all();

  void insert(T value, ListItem<T>* ptr);  // �w���� ptr �ҫ����U�@��m
  void insert_front(T value);
  void insert_end(T value);

  void inc_size() { ++_size; }
  void dec_size() { --_size; }

  void display(std::ostream &os=std::cout) const;


  // for [Gamma95], app-C.
  T Get(long index) const;  // list �o�� index�A����


private:
  ListItem<T>* _end;    // �`�N�A�o�̪� _end ���O offset by one.
                        // �ӬO�u�����V�̫�@�Ӥ����C
  ListItem<T>* _front;
  long _size;

  void insert_all(const List &rhs);  // used by copy ctor and operator=
};

template <typename T>
class ListItem
{
public:
  ListItem(T value, ListItem* ptr=0)      // ctor, �]�w value �åO
    : _value(value)                       // ptr ���V�o�ӷs����
  {
    if (ptr) {
        _next = ptr->_next;
        ptr->_next = this;
    }
    else
        _next = 0;
  }

  // ���� pointer member, ���] class ���å��ʺA�t�m�O����A
  // �ҥH���ݼ��g dtor.

  T value() const { return _value; }         // return current value
  ListItem* next() const { return _next; }   // return next
  void next(ListItem* ptr) { _next = ptr; }  // set next

private:
  T _value;
  ListItem* _next;
};

#endif // _JJLIST__

