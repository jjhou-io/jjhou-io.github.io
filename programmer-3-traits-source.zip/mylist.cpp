// based on C++ Primer 3/e, section 5.11
#include <iostream>
#include "mylist.h"

template <typename T>
void List<T>::insert(T value, ListItem<T>* ptr)
{
  if (!ptr)                          // �p�G ptr==0
      insert_front(value);           // �N�w�����Y��
  else if (ptr == end())             // �p�G ptr ���V����
      insert_end(value);             // �N�w�������
  else {
      new ListItem<T>(value, ptr);   // �_�h�N�w���� ptr �ҫ����U�@��m
      inc_size();
  }
}

template <typename T>
void List<T>::insert_front(T value)
{
  if (_front) {
      ListItem<T>* temp = new ListItem<T>(value);
      temp->next(_front);
      _front = temp;
  }
  else // empty
      _end = _front = new ListItem<T>(value);

  inc_size();
}


template <typename T>
void List<T>::insert_end(T value)
{
  if (_end)
      _end = new ListItem<T>(value, _end);
  else // empty
      _end = _front = new ListItem<T>(value);

  inc_size();
}


template <typename T>
void List<T>::display(std::ostream &os) const
{
  os << "\n" << _size << " ( ";

  ListItem<T>* ptr = _front;
  while(ptr) {
     os << ptr->value() << " ";
     ptr = ptr->next();
  }

  os << ")" << std::endl;
}


template <typename T>
ListItem<T>* List<T>::find(T value) const
{
  ListItem<T>* ptr = front();
  while (ptr) {
     if (value == ptr->value())   // value type �����䴩 operator==
         break;                   // �M��Ĥ@�ӧk�X�����C���N�h�X
     ptr = ptr->next();
  }
  return ptr;
}


template <typename T>
void List<T>::remove_front()
{
  if (_front) {
      ListItem<T>* ptr = _front;
      _front = _front->next();

      dec_size();
      delete ptr;
  }
}

template <typename T>
void List<T>::remove_all()
{
    while(_front)          // �@�@�����Y���A�̫ᵲ�G�N�O��������
        remove_front();

    _size = 0;
    _front = _end = 0;
}

template <typename T>
int List<T>::remove(T value)   // �N�k�X������������
{
  // ref C++ Primer 3/e, p232
}

template <typename T>
ListItem<T>* List<T>::remove(const ListItem<T>* ptr)
{
  // ���� ptr �ҫ�����
}



// for [Gamma95], app-C.
template <typename T>
T List<T>::Get(long index) const   // list �o�� index�A����
{
   if (index >= size())
       throw ListOutOfBounds();
   ListItem<T>* ptr = front();
   for(int i=0; i<index; ++i)   // ���N 'index' ��
       ptr = ptr->next();
   return ptr->value();
}



template <typename T>
inline List<T>::List(const List& rhs)  // ctor
  : _front(0), _end(0), _size(0)
{
   insert_all(rhs);
}


template <typename T>
inline List<T>& List<T>::operator=(const List& rhs)
{
   if (this != &rhs) {  // avoid self assignment
      remove_all();
      insert_all(rhs);
   }
   return *this;
}


template <typename T>
void List<T>::insert_all(const List& rhs)
{
   ListItem<T>* pt = rhs.front();
   while (pt) {
      insert_end(pt->value());
      pt = pt->next();
   }
}
