
public class Base
{
  public void f() throws Exception{/* does something */}
}
