
public class Derived extends Base
{
  public void f() throws Exception
  {
    throw new Exception("hi");
  }
}
