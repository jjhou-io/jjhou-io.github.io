package api;

abstract public class PersistentException extends Exception
{
}
