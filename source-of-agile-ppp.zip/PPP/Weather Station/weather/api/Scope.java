package api;

public class Scope
{
  public static StationToolkit stationToolkit;

}
