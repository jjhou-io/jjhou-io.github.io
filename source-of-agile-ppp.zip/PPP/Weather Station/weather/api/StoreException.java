package api;

public class StoreException 
                        extends PersistentException
{
}
