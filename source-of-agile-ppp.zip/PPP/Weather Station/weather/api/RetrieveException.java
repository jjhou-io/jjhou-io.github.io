package api;

public class RetrieveException 
                        extends PersistentException
{
}
