package wmsdata;

public class Scope
{
  public static DataToolkit itsDataToolkit; 
}
