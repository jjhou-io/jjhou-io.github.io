package persistence;

public class Scope
{
  public static void init()
  {
    wmsdata.Scope.itsDataToolkit = new DataToolkit();
  }
}
