package test;

class BarometricPressureImp implements api.BarometricPressureSensorImp
{
  public double read()
  {
    return 1.0;
  }
}
