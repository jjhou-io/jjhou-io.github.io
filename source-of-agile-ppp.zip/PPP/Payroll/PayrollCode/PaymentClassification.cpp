#include "PaymentClassification.h"
#include "Paycheck.h"

PaymentClassification::~PaymentClassification()
{
}


