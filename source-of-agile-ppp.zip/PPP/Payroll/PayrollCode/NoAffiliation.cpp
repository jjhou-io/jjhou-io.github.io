#include "NoAffiliation.h"

NoAffiliation::~NoAffiliation()
{
}

NoAffiliation::NoAffiliation()
{
}

double NoAffiliation::CalculateDeductions(Paycheck&) const
{
  return 0;
}
