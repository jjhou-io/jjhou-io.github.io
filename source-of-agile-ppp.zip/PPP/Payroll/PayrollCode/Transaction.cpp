#include "Transaction.h"

Transaction::~Transaction()
{
}
