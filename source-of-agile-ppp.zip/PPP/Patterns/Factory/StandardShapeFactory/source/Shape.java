
public interface Shape
{
  public String getShapeType();
}
