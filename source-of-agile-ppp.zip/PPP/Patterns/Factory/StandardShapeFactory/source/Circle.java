
public class Circle implements Shape
{
  public String getShapeType()
  {
    return "Circle";
  }
}
