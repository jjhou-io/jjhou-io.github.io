
public interface Shape
{
  public String getShapeName();
}
