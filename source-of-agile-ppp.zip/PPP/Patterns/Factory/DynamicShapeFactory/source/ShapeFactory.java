
public interface ShapeFactory
{
  public Shape make(String shapeName) throws Exception;
}
