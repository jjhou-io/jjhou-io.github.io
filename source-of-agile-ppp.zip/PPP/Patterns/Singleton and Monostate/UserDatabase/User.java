public class User
{
	private String userName;
	private String password;
}
