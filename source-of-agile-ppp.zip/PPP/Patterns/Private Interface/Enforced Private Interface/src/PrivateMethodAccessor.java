
public interface PrivateMethodAccessor
{
  public void private_f();
}
