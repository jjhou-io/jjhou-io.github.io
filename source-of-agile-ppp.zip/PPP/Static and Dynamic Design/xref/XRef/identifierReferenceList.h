namespace XRef
{
	class IdentifierReferenceList;
};

class XRef::IdentifierReferenceList
{
};
