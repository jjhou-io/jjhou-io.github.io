
#pragma warning(disable:4786)
#include "XRef/xref.h"
#include "Parser/identifier.h"
#include "Parser/namedScope.h"

void main() {};
