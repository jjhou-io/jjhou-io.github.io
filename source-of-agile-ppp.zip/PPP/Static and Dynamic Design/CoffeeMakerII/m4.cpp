#include "coffeeMakerFSM_i.h"

int main()
{
    return 0;
}
