// Pollable.cpp: implementation of the Pollable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CoffeeMakerI.h"
#include "Pollable.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

using namespace com_cmindustries_pollable;

Pollable::Pollable()
{

}

Pollable::~Pollable()
{

}
