// MIVAPI.cpp: implementation of the MIVAPI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CoffeeMakerI.h"
#include "MIVAPI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

using namespace com_cmindustries_m4_api;

API::API()
{

}

API::~API()
{

}
