class Test
{
  public static void main(String args[])
  {
    Integer ia = new Integer(10);
    Integer ib = new Integer(10);
    System.out.println("ia.equals(ib) is " + (ia.equals(ib)));
    System.out.println("ib.equals(ia) is " + (ib.equals(ia)));
  }
}