class Test
{
  public static void main(String args[])
  {
    int a = 10;
    int b = 20;
    int[] arr = new int[10];
    for (int i=0; i<10; i++)
      arr[i] = a + b;
  }
}