interface Vehicle
{
  public void startEngine();
  public void stopEngine();
  public void accelerate();
  public void decelerate();
}