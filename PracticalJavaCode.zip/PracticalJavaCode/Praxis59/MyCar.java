class MyCar implements Vehicle
{
  public void startEngine() {
    //Code to start engine...
  }
  public void stopEngine() {
    //Code to stop engine...
  }
  public void accelerate()  {
    //Code to accelerate...
  }
  public void decelerate() {
    //Code to decelerate...
  }
  public void loadPeopleInCar() {
    //Code to load people in car...
  }
  public int adultSeating() {
    return 2;
  }
  public int childSeating() {
    return 2;
  }
}