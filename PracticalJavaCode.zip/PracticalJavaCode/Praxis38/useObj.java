public Integer useObject(int increment)
{
  int i = 5;
  i = i + increment;
  return (new Integer(i));
}