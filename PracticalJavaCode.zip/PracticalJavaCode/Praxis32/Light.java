class Light
{
  private int val;
  private boolean hasData = true;
  public Light(int a)
  {
    val = a;
  }
  //...
}