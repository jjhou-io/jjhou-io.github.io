interface Bowler
{
  public static int HighScore = 300;
  public static int LowScore = 120;
  public void computeScore();
}