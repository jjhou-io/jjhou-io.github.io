// Author: J.J.Hou
// File: serializeTest.java
//
// for JDK1.4 with JSR14,
// build : javag.bat serializeTest.java
// options: -gj -warnunchecked (�w���O�� javag.bat ��)
// �p�G��Ҧ� <> �����A�i�H��¤� JDK1.3 or JDK1.4 �sĶ�C

import java.util.LinkedList;
import java.util.Collections;
import java.util.List;  // for List
import java.util.*;     // for Iterator
import java.io.*;       // for IO
import java.lang.reflect.*;

public class serializeTest {
  public static void main(String[] args)
    throws ClassNotFoundException, IOException {

    // �`�N�G�Ҧ� collection classes ���������t Object-derived class object�A
    // �N�����i�H�� int, float...�A������ Integer, Float...�C 	 
    //
    // �]�i�H��Ҧ��� <> �������C
    LinkedList<Object> sl = new LinkedList<Object>();
    //System.out.println("sl=" + sl);  // s1=[]
    
    
    ArrayList<Integer> ia = new ArrayList<Integer>();
    //�]�i�H�GArrayList ia = new ArrayList();    
    ia.add(new Integer(0x19));
    ia.add(new Integer(0x16));
    ia.add(new Integer(0x19));
    ia.add(new Integer(0x16));    
    sl.add(new Stroke(new Integer(2), ia)); 
    
    ia = new ArrayList<Integer>();
    //�]�i�H�Gia = new ArrayList();    
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x2b));
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x2c));    
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x2c));      
    sl.add(new Stroke(new Integer(5), ia));     
    
    ia = new ArrayList<Integer>();
    //�]�i�H�Gia = new ArrayList();    
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x48));
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x48));         
    sl.add(new Stroke(new Integer(0xA), ia));     
    
    ia = new ArrayList<Integer>();
    //�]�i�H�Gia = new ArrayList();
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x64));
    ia.add(new Integer(0x18));
    ia.add(new Integer(0x64));    
    sl.add(new Stroke(new Integer(0x14), ia));   
    
    Rect r = new Rect(new Integer(0x11), new Integer(0x22),   
                      new Integer(0x33), new Integer(0x44));                      
    Circle c = new Circle(new Integer(0x55), new Integer(0x66), 
                          new Integer(0x77));
    sl.add(r);      
    sl.add(c);
    sl.add(r);      
    sl.add(c);             
    
    //System.out.println("sl=" + sl);   
/*
sl=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=68], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=68], [X=85,Y=102,R=119]]
*/
    ObjectOutputStream out =
      new ObjectOutputStream(
        new FileOutputStream("collect.out"));

    out.writeObject(sl);
    out.close();  // also flush output stream

    ObjectInputStream in =
      new ObjectInputStream(
        new FileInputStream("collect.out"));

    LinkedList sl2  = (LinkedList)in.readObject();
    in.close();    
    
    //System.out.println("sl2=" + sl2);       
/*
sl2=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=68], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=68], [X=85,Y=102,R=119]]
*/

    // �H�U�ק� sl �� #4 �������e�A�ݬ� #6 �������e�O�_�]�����ܡA�H������
    // Java Collections �O "reference semantices
    Object o = sl.get(4);  // �����૬�� Rect �]�i�H�H�U�椧println()��X����H��
    //System.out.println("sl[4]=" + o);     
    //System.out.println("height=" + ((Rect)o).getHeight()); // height=68
    ((Rect)o).setHeight(new Integer(0x50));
    //System.out.println("sl=" + sl);  
/*
sl=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=80], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=80], [X=85,Y=102,R=119]]
*/    
    
    // �H�U�H�ۦP�覡���� sl2�A�H������ deserialization �ұo���G���������ۦP��쥻���c�C
    Object o2 = sl2.get(4);  // �����૬�� Rect �]�i�H�H�U�椧println()��X����H��
    //System.out.println("sl2[4]=" + o2);     
    //System.out.println("height=" + ((Rect)o2).getHeight()); // height=68
    ((Rect)o2).setHeight(new Integer(0x50));
    //System.out.println("sl2=" + sl2);  
/*
sl2=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=80], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=80], [X=85,Y=102,R=119]]
*/     



    // *** dynamic types system testing...
    Object obj = (Object)sl;  
    if (obj instanceof Class) {
        System.out.println("obj instanceof Class"); 
    } else if (obj instanceof ObjectStreamClass) {
        System.out.println("obj instanceof ObjectStreamClass"); 
    } else {
        System.out.println("obj instanceof neither ObjectStreamClass nor Class");     
    }
    // obj instanceof neither ObjectStreamClass nor Class
    
    Class c1 = obj.getClass();    
    if (c1 instanceof Class) {
        System.out.println("c1 instanceof Class");  // c1 instanceof Class 
    }
    
    //�H�U���� Class Descriptor (i.e. ObjectStreamClass)
    //ObjectStreamClass desc = ObjectStreamClass(c1); // �ѩ�private ctor �ҥH�L�k���\
    ObjectStreamClass desc = ObjectStreamClass.lookup(c1);
      //�p�G�䤣��A�|���ͤ@�ӨöǦ^�C
      
    System.out.println("isProxy=" + Proxy.isProxyClass(c1)); 
      // isProxy=false    
      
    //�H�U���յy����o�� class descriptor �� accessors
    //�ѩ�cannot be accessed from outside package, �ҥH�j�СC
    /*
    System.out.println("isProxy=" + desc.isProxy()); 
      // isProxy=      
    System.out.println("isSerializable=" + desc.isSerializable()); 
      // isSerializable=
    System.out.println("isExternalizable=" + desc.isExternalizable()); 
      // isExternalizable=   
    System.out.println("hasWriteObjectData=" + desc.hasWriteObjectData()); 
      // hasWriteObjectData=       
    System.out.println("isInstantiable=" + desc.isInstantiable()); 
      // isInstantiable=  
    System.out.println("hasWriteObjectMethod=" + desc.hasWriteObjectMethod()); 
      // hasWriteObjectMethod= 
    System.out.println("hasReadObjectMethod=" + desc.hasReadObjectMethod()); 
      // hasReadObjectMethod= 
    System.out.println("hasReadObjectNoDataMethod=" + desc.hasReadObjectNoDataMethod()); 
      // hasReadObjectNoDataMethod= 
    System.out.println("hasWriteReplaceMethod=" + desc.hasWriteReplaceMethod()); 
      // hasWriteReplaceMethod= 
    System.out.println("hasReadResolveMethod=" + desc.hasReadResolveMethod()); 
      // hasReadResolveMethod= 
    */
             
    //�H�U���յy����o�� class descriptor ���Y�� methods                        
    System.out.println("desc=" + desc);
      // desc=java.util.LinkedList: static final long serialVersionUID = 876323262645176354L;
    System.out.println(desc.getSerialVersionUID());    
      // 876323262645176354
    System.out.println(desc.getName());    
      // java.util.LinkedList
    ObjectStreamField[] osf = desc.getFields();
    System.out.println(osf);    
      // [Ljava.io.ObjectStreamField;@df073d  	<-- �����ܡH
    System.out.println(osf.length);  		// 0
    for (int i = 0; i < osf.length; i++)
        System.out.println(osf[i]);       


    //�H�U���� Reflection: Class
    Method[] m1 = c1.getMethods();
    Constructor[] ctor1 = c1.getConstructors();     
    Field[] f1 = c1.getFields();
    System.out.println("Method[]:");
    for (int i = 0; i < m1.length; i++)
        System.out.println(m1[i]);
    System.out.println("Constructor[]:");        
    for (int i = 0; i < ctor1.length; i++)
        System.out.println(ctor1[i]); 
    System.out.println("Field[]:");  
    for (int i = 0; i < f1.length; i++)
        System.out.println(f1[i]);  
/*
Method[]:
public java.lang.Object java.util.LinkedList.clone()
public int java.util.LinkedList.indexOf(java.lang.Object)
public int java.util.LinkedList.lastIndexOf(java.lang.Object)
public boolean java.util.LinkedList.addAll(int,java.util.Collection)
public boolean java.util.LinkedList.addAll(java.util.Collection)
public void java.util.LinkedList.add(int,java.lang.Object)
public boolean java.util.LinkedList.add(java.lang.Object)
public java.lang.Object java.util.LinkedList.get(int)
public boolean java.util.LinkedList.contains(java.lang.Object)
public int java.util.LinkedList.size()
public java.lang.Object[] java.util.LinkedList.toArray()
public java.lang.Object[] java.util.LinkedList.toArray(java.lang.Object[])
public boolean java.util.LinkedList.remove(java.lang.Object)
public java.lang.Object java.util.LinkedList.remove(int)
public void java.util.LinkedList.clear()
public java.lang.Object java.util.LinkedList.set(int,java.lang.Object)
public java.util.ListIterator java.util.LinkedList.listIterator(int)
public java.lang.Object java.util.LinkedList.getFirst()
public java.lang.Object java.util.LinkedList.getLast()
public java.lang.Object java.util.LinkedList.removeFirst()
public java.lang.Object java.util.LinkedList.removeLast()
public void java.util.LinkedList.addFirst(java.lang.Object)
public void java.util.LinkedList.addLast(java.lang.Object)
public java.util.Iterator java.util.AbstractSequentialList.iterator()
public int java.util.AbstractList.hashCode()
public boolean java.util.AbstractList.equals(java.lang.Object)
public java.util.List java.util.AbstractList.subList(int,int)
public java.util.ListIterator java.util.AbstractList.listIterator()
public java.lang.String java.util.AbstractCollection.toString()
public boolean java.util.AbstractCollection.isEmpty()
public boolean java.util.AbstractCollection.containsAll(java.util.Collection)
public boolean java.util.AbstractCollection.removeAll(java.util.Collection)
public boolean java.util.AbstractCollection.retainAll(java.util.Collection)
public final native java.lang.Class java.lang.Object.getClass()
public final void java.lang.Object.wait(long,int) throws java.lang.InterruptedException
public final void java.lang.Object.wait() throws java.lang.InterruptedException
public final native void java.lang.Object.wait(long) throws java.lang.InterruptedException
public final native void java.lang.Object.notify()
public final native void java.lang.Object.notifyAll()
Constructor[]:
public java.util.LinkedList(java.util.Collection)
public java.util.LinkedList()
Field[]:
*/           
        
    //�H�U���� Reflection: Class ("Declared")                      
    Method[] md1 = c1.getDeclaredMethods();
    Constructor[] ctord1 = c1.getDeclaredConstructors(); 
    Field[] fd1 = c1.getDeclaredFields(); 
    System.out.println("DeclaredMethod[]:");    
    for (int i = 0; i < md1.length; i++)
        System.out.println(md1[i]);
    System.out.println("DeclaredConstructor[]:");   
    for (int i = 0; i < ctord1.length; i++)
        System.out.println(ctord1[i]);   
    System.out.println("DeclaredField[]:"); 
    for (int i = 0; i < fd1.length; i++)
        System.out.println(fd1[i]);      
/*
DeclaredMethod[]:
public java.lang.Object java.util.LinkedList.clone()
public int java.util.LinkedList.indexOf(java.lang.Object)
public int java.util.LinkedList.lastIndexOf(java.lang.Object)
public boolean java.util.LinkedList.addAll(int,java.util.Collection)
public boolean java.util.LinkedList.addAll(java.util.Collection)
public void java.util.LinkedList.add(int,java.lang.Object)
public boolean java.util.LinkedList.add(java.lang.Object)
public java.lang.Object java.util.LinkedList.get(int)
public boolean java.util.LinkedList.contains(java.lang.Object)
public int java.util.LinkedList.size()
public java.lang.Object[] java.util.LinkedList.toArray()
public java.lang.Object[] java.util.LinkedList.toArray(java.lang.Object[])
public boolean java.util.LinkedList.remove(java.lang.Object)
public java.lang.Object java.util.LinkedList.remove(int)
private void java.util.LinkedList.remove(java.util.LinkedList$Entry)
static java.util.LinkedList$Entry java.util.LinkedList.access$000(java.util.LinkedList)
static int java.util.LinkedList.access$100(java.util.LinkedList)
static void java.util.LinkedList.access$200(java.util.LinkedList,java.util.LinkedList$Entry)
private synchronized void java.util.LinkedList.writeObject(java.io.ObjectOutputStream) throws java.io.IOException
public void java.util.LinkedList.clear()
static java.util.LinkedList$Entry java.util.LinkedList.access$300(java.util.LinkedList,java.lang.Object,java.util.LinkedList$Entry)
private synchronized void java.util.LinkedList.readObject(java.io.ObjectInputStream) throws java.io.IOException,java.lang.ClassNotFoundException
public java.lang.Object java.util.LinkedList.set(int,java.lang.Object)
public java.util.ListIterator java.util.LinkedList.listIterator(int)
private java.util.LinkedList$Entry java.util.LinkedList.entry(int)
public java.lang.Object java.util.LinkedList.getFirst()
public java.lang.Object java.util.LinkedList.getLast()
public java.lang.Object java.util.LinkedList.removeFirst()
public java.lang.Object java.util.LinkedList.removeLast()
public void java.util.LinkedList.addFirst(java.lang.Object)
public void java.util.LinkedList.addLast(java.lang.Object)
private java.util.LinkedList$Entry java.util.LinkedList.addBefore(java.lang.Object,java.util.LinkedList$Entry)
DeclaredConstructor[]:
public java.util.LinkedList(java.util.Collection)
public java.util.LinkedList()
DeclaredField[]:
private transient java.util.LinkedList$Entry java.util.LinkedList.header
private transient int java.util.LinkedList.size
private static final long java.util.LinkedList.serialVersionUID
*/      
 
   
    Class c2 = Class.forName("Stroke");
    System.out.println(c2);          
    Method[] md2 = c2.getDeclaredMethods();
    Constructor[] ctord2 = c2.getDeclaredConstructors(); 
    Field[] fd2 = c2.getDeclaredFields(); 
    for (int i = 0; i < md2.length; i++)
        System.out.println(md2[i]);
    for (int i = 0; i < ctord2.length; i++)
        System.out.println(ctord2[i]);   
    for (int i = 0; i < fd2.length; i++)
        System.out.println(fd2[i]);      
/* output:
class Stroke
public java.lang.String Stroke.toString()
public Stroke(java.lang.Integer,java.util.ArrayList)
java.lang.Integer Stroke.m_width
java.util.ArrayList Stroke.m_ia
*/            

      
    Class c3 = Class.forName("Rect");
    System.out.println(c3);         
    Method[] md3 = c3.getDeclaredMethods();
    Constructor[] ctord3 = c3.getDeclaredConstructors(); 
    Field[] fd3 = c3.getDeclaredFields(); 
    for (int i = 0; i < md3.length; i++)
        System.out.println(md3[i]);
    for (int i = 0; i < ctord3.length; i++)
        System.out.println(ctord3[i]);   
    for (int i = 0; i < fd3.length; i++)
        System.out.println(fd3[i]);           
/* output:
class Rect
public java.lang.String Rect.toString()
public void Rect.setHeight(java.lang.Integer)
public java.lang.Integer Rect.getHeight()
public Rect(java.lang.Integer,java.lang.Integer,java.lang.Integer,java.lang.Integer)
java.lang.Integer Rect.m_left
java.lang.Integer Rect.m_top
java.lang.Integer Rect.m_width
java.lang.Integer Rect.m_height
*/        

       
    Class c4 = Class.forName("Circle");
    System.out.println(c4);         
    Method[] md4 = c4.getDeclaredMethods();
    Constructor[] ctord4 = c4.getDeclaredConstructors(); 
    Field[] fd4 = c4.getDeclaredFields(); 
    for (int i = 0; i < md4.length; i++)
        System.out.println(md4[i]);
    for (int i = 0; i < ctord4.length; i++)
        System.out.println(ctord4[i]);   
    for (int i = 0; i < fd4.length; i++)
        System.out.println(fd4[i]);                             
/* output:
class Circle
public java.lang.String Circle.toString()
public Circle(java.lang.Integer,java.lang.Integer,java.lang.Integer)
java.lang.Integer Circle.m_x
java.lang.Integer Circle.m_y
java.lang.Integer Circle.m_r
*/       

  } // main
}  // serializeTest
