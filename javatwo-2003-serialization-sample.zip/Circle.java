// Author: J.J.Hou (Top Studio)
// File: Circle.java

import java.util.*;
import java.io.*;   // for Serializable

public class Circle implements Serializable 
{
  Integer m_x, m_y, m_r;

  public Circle(Integer x, Integer y, Integer r) {
    this.m_x = x;
    this.m_y = y;
    this.m_r = r;      
  }

  public String toString() {
    return "[X=" + m_x + ",Y=" + m_y + ",R=" + m_r + "]";
  }
}