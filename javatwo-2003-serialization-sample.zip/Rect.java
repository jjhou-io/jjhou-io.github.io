// Author: J.J.Hou (Top Studio)
// File: Rect.java

import java.util.*;
import java.io.*;   // for Serializable


public class Rect implements Serializable 
{
   // �Q�ΥH�U�o�q�A�H c:> javadoc rect.java ���͡]�\�h�^.htm�C�u���O�����C
   /**
     * The vertexes of Rect.
     * @serial
     */
  Integer m_left, m_top, m_width, m_height;
  
  public Rect(Integer left, Integer top, 
              Integer width, Integer height ) {
    this.m_left = left;
    this.m_top = top;
    this.m_width = width;    
    this.m_height = height;    
  }
  
  public Integer getHeight()    { return m_height; }
  public void setHeight(Integer i) { m_height = i; }

  public String toString() {
    return "[L=" + m_left + ",T=" + m_top + 
           ",W=" + m_width + ",H=" + m_height + "]";
  }
}

