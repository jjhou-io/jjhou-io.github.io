// Author: J.J.Hou (Top Studio)
// File: Stroke.java

import java.util.*;
import java.io.*;   // for Serializable

public class Stroke implements Serializable 
{
  Integer m_width;
  ArrayList<Integer> m_ia;

  public Stroke(Integer width, ArrayList<Integer> ia) {
    this.m_width = width;
    this.m_ia = ia;
  }

  public String toString() {
    return "[width=" + m_width +
      ",points=" + m_ia + "]";
  }
}

