// #include <iostream>
#include <iostream.h>

/**
 ** gossipaceous Anna Livia
 **
 **/
int main() 
{
    cout << "gossipaceous Anna Livia\n";
}
