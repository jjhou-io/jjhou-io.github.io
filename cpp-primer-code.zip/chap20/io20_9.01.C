// #include <iostream>
#include <iostream.h>

/**
 **
 ** bool object illustrate set to true: 1
 **
 **/

int main()
{
    bool illustrate = true;

    cout << "bool object illustrate set to true: "
         << illustrate << endl;
}
