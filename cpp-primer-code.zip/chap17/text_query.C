#include "TextQuery.h"

int main()
{
        TextQuery tq;

        tq.build_up_text();
        tq.query_text();

        return 0;
}

