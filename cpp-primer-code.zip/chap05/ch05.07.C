// note: no compiler available at this time to compile

#include <iostream>
int main()
{
    for ( int ix = 0;
	  // assigns done true or false based on
	  // whether ix is equal to 10
          bool done = ix == 10; ++ix )
               cout << "ix: " << ix << endl;
}

