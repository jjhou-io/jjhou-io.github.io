#include <string>
int lexicoCompare( const string &s1, const string &s2 ) {
	return s1.compare(s2);
}
