
//#define DEBUG

#ifdef DEBUG
#include <stdio.h>
#define MSG(x)  printf("%s\n", x);
#else
#define MSG(x);
#endif

