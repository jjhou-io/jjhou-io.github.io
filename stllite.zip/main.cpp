#include "list"        // list<T>
#include "algorithm"   // count_if(),find(),copy(),for_each()
#include "iterator"    // reverse_iterator,advance(),distance()
#include "functional"  // not1(),bind2nd(),binder2nd,less
#include "stack"       // stack<T>
#include <iostream>

using std::endl;
using std::cout;
using namespace stllite;

template <typename T>
struct printElem
{
  void operator()(T elem)
  {
    cout << elem << ' ';
  }
};

struct Student {
  int  age;
  char grade;
  Student() : age(7),grade('B') { cout << "Student ctor" << endl; }
 ~Student() { cout << "Student dtor" << endl; }
};

int main()
{
  cout << "sizeof(Student)=" << sizeof(Student) << endl;  // 8
  Student s;                                              // Student ctor
  cout << s.age << ' ' << s.grade << endl;                // 7 B
  Student* p = (Student*)alloc::allocate(20);
  construct(p,s);                                         //(ctor, not default ctor!)
  cout << p->age << ' ' << p->grade << endl;              // 7 B
  destroy(p);                                             // Student dtor
  alloc::deallocate(p,20);

  p = simple_alloc<Student,alloc>::allocate(5);
  simple_alloc<Student,alloc>::deallocate(p);



  // Jostream_iterator �i�N���N��ô���ܤ@�� output stream �]�ƤW�A�Ѩ���3���C
  //Jostream_iterator<int> outite(cout, " ");
  list<int> mylist;

  for(int i=0; i<5; ++i) {
      mylist.push_front(i);
      mylist.push_back(i+2);
  }

  // �N�Ҧ����e������ outite �h�C�ѩ� outite ô���� cout�A�ҥH��X�ܿù��W�C
  //copy(mylist.begin(), mylist.end(), outite);  cout << endl;
  for_each(mylist.begin(), mylist.end(), printElem<int>());
  cout << endl;
  // ��X���G�G4 3 2 1 0 2 3 4 5 6

  // �Q�� find() ��X����2���Ҧb��m�A�b�ӳB�w������5�C
  mylist.insert(find(mylist.begin(), mylist.end(), 2), -5);
  //copy(mylist.begin(), mylist.end(), outite);  cout << endl;
  for_each(mylist.begin(), mylist.end(), printElem<int>());
  cout << endl;
  // ��X���G�G4 3 -5 2 1 0 2 3 4 5 6

  //mylist.erase(mylist.end());   // Exception: STATUS_ACCESS_VIOLATION
  mylist.erase(mylist.begin());
  mylist.pop_back();
  mylist.pop_front();

  //copy(mylist.begin(), mylist.end(), outite);  cout << endl;
  for_each(mylist.begin(), mylist.end(), printElem<int>());
  cout << endl;
  // ��X���G�G-5 2 1 0 2 3 4 5

  cout << mylist.size() << endl;
  // 8

  // �H�U���խ��N��
  list<int>::iterator iit1 = mylist.begin();
  list<int>::iterator iit2 = mylist.end();
  //copy(iit1, iit2, outite);  cout << endl;
  for_each(mylist.begin(), mylist.end(), printElem<int>());
  cout << endl;
  // ��X���G�G-5 2 1 0 2 3 4 5

  cout << count_if(mylist.begin(), mylist.end(), bind2nd(less<int>(),5));
  cout << endl;
  // 7
  cout << count_if(mylist.begin(), mylist.end(), not1(bind2nd(less<int>(),3)));
  cout << endl;
  // 3


  iit1 = mylist.begin();
  iit2 = mylist.end();
  int dis=0;
  //CB5 can't recognize advance(), need "stllite::" explicitly. why?
  stllite::advance(iit1, 3);
  cout << *iit1 << endl;  // 0
  *iit1 = 99;
  cout << *iit1 << endl;  // 99

  //CB5 can't recognize distance(), need "stllite::" explicitly. why?
  stllite::distance(iit1, iit2, dis);
  cout << dis << endl;    // 5


  mylist.clear();
  //copy(mylist.begin(), mylist.end(), outite);  cout << endl;
  for_each(mylist.begin(), mylist.end(), printElem<int>());
  cout << endl;
  // none

  int ia[5] = { 0,1,2,3,4 };
  stllite::reverse_iterator<int*,int> rii(&ia[2]);  //CB5 can't recognize stllite's reverse_iterator, we need to write "stllite::" explicitly. I don't know why.
  cout << ia[2] << endl;  // 2
  cout << *rii << endl;   // 1

  stack<int> si;
  si.push(928);
  si.push(428);
  si.push(1218);
  cout << "si size=" << si.size() << endl;  // 3
  cout << si.top() << ' ';  si.pop(); // 1128
  cout << si.top() << ' ';  si.pop(); // 428
  cout << si.top() << ' ';  si.pop(); // 928

  // Student dtor
}


