//�@�̡G�J��
//�ت��G��U����JDK1.5��GP�MSerialization
//�ɦW�GRect.java
//�سy�G�� seriTest.java

import java.util.*;
import java.lang.*;
import java.io.*;   // for Serializable

public class Rect<T extends Number> extends Shape
                     implements Serializable
{
  T m_left, m_top, m_width, m_height;

  public Rect(T left, T top,
              T width, T height ) {
    this.m_left = left;
    this.m_top = top;
    this.m_width = width;
    this.m_height = height;
  }

  public T getHeight() { return m_height; }
  public void setHeight(T i) { m_height = i; }

  public String toString() {
    return "[L=" + m_left + ",T=" + m_top +
           ",W=" + m_width + ",H=" + m_height + "]";
  }

  public void draw() {
        toString();
  }

  public double L() {
        //�p��P��
        //! return (double)((m_width + m_height) * 2);

        //System.out.println("in L(), m_width =" + m_width.doubleValue());
        //System.out.println("in L(), m_height=" + m_height.doubleValue());
        return (m_width.doubleValue() + m_height.doubleValue()) * 2;
  }

}

