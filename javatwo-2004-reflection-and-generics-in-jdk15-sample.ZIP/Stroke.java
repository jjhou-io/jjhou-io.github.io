//�@�̡G�J��
//�ت��G��U����JDK1.5��GP�MSerialization
//�ɦW�GStroke.java
//�سy�G�� seriTest.java

import java.util.*;
import java.io.*;   // for Serializable

public class Stroke<W extends Number,T extends Number> extends Shape
                         implements Serializable
{
  W m_width;
  ArrayList<T> m_ia;

  public Stroke(W width, ArrayList<T> ia) {
    this.m_width = width;
    this.m_ia = ia;
  }

  public String toString() {
    return "[width=" + m_width +
      ",points=" + m_ia + "]";
  }

  public void draw() {
        toString();
  }

  public double L() {
        return 40.0;  //�ȮɭJ���v�R�o��g
  }
}

