//�@�̡G�J��
//�ت��G���� Method.invoke() �M Field.setDouble()
//�ɦW�GDynTest.java

import java.lang.reflect.*;
import java.util.*;
        
public class DynTest {
	    public double d; // a field
	    
      public int add(int a, int b)
      {
      	 System.out.println("add() invoked");  
         return a + b;
      }
      public String tName(String s, Hashtable ht)
      {
      	 System.out.println("tName() invoked");  
         return s;
      } 
        
      public static void main(String args[])
      {
      	//����1. Method.invoke()
        {
         try {
         	  //�ǳƤ@�� Method object
            Class c = Class.forName("DynTest");
            Class pTypes[] = new Class[2];
            pTypes[0] = Integer.TYPE;
            pTypes[1] = Integer.TYPE;
            //���w�Y��class�����Y��signature
            //�K�i�W�@�L�G�a��X�]��o�^�@��method
            Method m = c.getMethod("add", pTypes);
            
            //�ǳ� invoking object
            DynTest obj = new DynTest();
            
            //�ǳ�argumetns
            Object arg[] = new Object[2];
            arg[0] = new Integer(37);
            arg[1] = new Integer(47);
            
            //�I�s�æC�L���G
            Object r = m.invoke(obj, arg);
            Integer rVal = (Integer)r;
            System.out.println("return: "+rVal.intValue());  //84
         }
         catch (Throwable e) {
            System.err.println(e);
         }
        }
         
        //����2. Method.invoke() 
        {
         try {
         	  //�ǳƤ@�� Method object
            Class c = Class.forName("DynTest");
            Class pTypes[] = new Class[2];
            pTypes[0] = Class.forName("java.lang.String");     
            pTypes[1] = Class.forName("java.util.Hashtable");  
            //���w�Y��class�����Y��signature
            //�K�i�W�@�L�G�a��X�]��o�^�@��method
            Method m = c.getMethod("tName", pTypes);
            
            //�ǳ�argumetns
            Object arg[] = new Object[2];
            arg[0] = new String("return: "+"Hello,World!");
            arg[1] = null;
            
            //�I�s�æC�L���G
            //Object r = m.invoke(this, arg);  //ERROR: non-static variable this cannot be referenced from a static context
            //�ǳ� invoking object
            DynTest obj = new DynTest();            
            Object r = m.invoke(obj, arg);
            String rVal = (String)r;
            System.out.println(rVal);	//Hello,World!
         }
         catch (Throwable e) {
            System.err.println(e);
         }         
        }
        
        //����3. Field.setDouble()
        {
         try {
            Class c = Class.forName("DynTest");
            Field f = c.getField("d");
            DynTest obj = new DynTest();
            System.out.println("before setting, d= " + obj.d); //0.0
            f.setDouble(obj, 12.34);
            System.out.println("after setting, d= " + obj.d);  //12.34
         }
         catch (Throwable e) {
            System.err.println(e);
         }         	
        }	
         
      } //main
}
