//�@�̡G�J��
//�ت��G����JDK1.5��GP�MSerialization
//�ɦW�GseriTest.java
//�سy�G(JDK1.5) javac -Xlint:unchecked seriTest.java

import java.util.LinkedList;
import java.util.Collections;
import java.util.List;  // for List
import java.util.*;     // for Iterator
import java.io.*;       // for IO
import java.lang.reflect.*;

public class seriTest {
  public static void main(String[] args)
    throws ClassNotFoundException, IOException {

    LinkedList<Shape> sl = new LinkedList<Shape>();
    
    ArrayList<Integer> ia = new ArrayList<Integer>();  
    ia.add(0x19);  //Auto-boxing
    ia.add(0x16);
    ia.add(0x19);
    ia.add(new Integer(0x16));   
    sl.add(new Stroke<Integer,Integer>(2, ia)); 
       
    ia = new ArrayList<Integer>();   
    ia.add(0x18);
    ia.add(0x2b);
    ia.add(0x18);
    ia.add(0x2c);    
    ia.add(0x18);
    ia.add(0x2c);      
    sl.add(new Stroke<Integer,Integer>(5, ia));     
    
    ia = new ArrayList<Integer>(); 
    ia.add(0x18);
    ia.add(0x48);
    ia.add(0x18);
    ia.add(0x48);         
    sl.add(new Stroke<Integer,Integer>(0xA, ia));     
    
    ia = new ArrayList<Integer>();
    ia.add(0x18);
    ia.add(0x64);
    ia.add(0x18);
    ia.add(0x64);    
    sl.add(new Stroke<Integer,Integer>(0x14, ia));   
    
    Rect<Integer> r = new Rect<Integer>(0x11,0x22,0x33,0x44);                      
    Circle<Integer> c = new Circle<Integer>(0x55,0x66,0x77);
    sl.add(r);      
    sl.add(c);
    sl.add(r);      
    sl.add(c);                
    
    System.out.println("sl=" + sl);   
/*
sl=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=68], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=68], [X=85,Y=102,R=119]]
*/

    ObjectOutputStream out =
      new ObjectOutputStream(
        new FileOutputStream("collect.out"));

    out.writeObject(sl);
    out.close();  // also flush output stream

    ObjectInputStream in =
      new ObjectInputStream(
        new FileInputStream("collect.out"));

    LinkedList sl2  = (LinkedList)in.readObject();
    in.close(); 
      
    
    System.out.println("sl2=" + sl2);       
/*
sl2=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=68], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=68], [X=85,Y=102,R=119]]
*/

    // �H�U�ק� sl �� #4 �������e�A�ݬ� #6 �������e�O�_�]�����ܡA�H������
    // Java Collections �O "reference semantices
    Rect<Integer> o = (Rect<Integer>)sl.get(4);  
    //System.out.println("sl[4]=" + o);     
    //System.out.println("height=" + ((Rect)o).getHeight()); // height=68
    o.setHeight(0x50);
    System.out.println("sl=" + sl);  
/*
sl=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=80], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=80], [X=85,Y=102,R=119]]
*/    
    
    // �ۦP�覡���� sl2�A���� deserialization �ұo���G���������ۦP��쥻���c�C
    Object o2 = sl2.get(4);  // �����૬�� Rect �]�i�Hprintln()��X����H��
    //System.out.println("sl2[4]=" + o2);     
    //System.out.println("height=" + ((Rect)o2).getHeight()); // height=68
    ((Rect<Integer>)o2).setHeight(0x50);
    System.out.println("sl2=" + sl2);  
/*
sl2=[[width=2,points=[25, 22, 25, 22]], [width=5,points=[24, 43, 24, 44, 24, 44]], 
[width=10,points=[24, 72, 24, 72]], [width=20,points=[24, 100, 24, 100]], 
[L=17,T=34,W=51,H=80], [X=85,Y=102,R=119], [L=17,T=34,W=51,H=80], [X=85,Y=102,R=119]]
*/     
    Shape s = Collections.max(sl);
    System.out.println("max=" + s); 

  } // main
}  // serializeTest
