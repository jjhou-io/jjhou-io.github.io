/*
 * ReflectClass.java -  Dump a class using Reflection.
 *
 * Copyright (c) 1997 Chuck McManis, All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * CHUCK MCMANIS MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. CHUCK MCMANIS
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
//��s�G�J��
//�ت��G������������է�hReflection APIs�A
//      �Y�ǮɭԨϥ�JDK1.5�s��for-loop�y�k
//�ɦW�GReflectClass.java�]�u�έ��ɦW�^
//�سy�G(JDK1.5) javac -Xlint:unchecked ReflectClass.java

import java.lang.reflect.*;
import java.util.*;

public class ReflectClass {

    //�H�U�W�[�T��inner classes A,B,C�A���F���լ�����Reflection APIs
    private static class A {
    }
    public static class B {
    }
    private static class C {
    }

    //�H�U�W�[�@��fields�A���F���լ�����Reflection APIs
    public Hashtable<String,Integer> ht;
    private String str;
    static public int i;
    private Short s;

    //nm: fullname
    //ht: key:classname, value:fullname
    public static String tName(String nm, Hashtable<String,String> ht) {
        String yy;
        String arr;

        if (nm.charAt(0) != '[') {
            int i = nm.lastIndexOf(".");
            if (i == -1)
                return nm; // �O��primitive type, ������
            else {
                yy = nm.substring(i+1);
                if (ht != null)			//�p�Ght���Onull
                    ht.put(nm, yy); //�Nclass types�O����hashtable.
                return yy;					//�L�צp��Ǧ^class name
            }
        }
        arr = "[]";
        if (nm.charAt(1) == '[')
            yy = tName(nm.substring(1), ht);
        else {
            switch (nm.charAt(1)) {
                case 'L' :
                    yy = tName(nm.substring(nm.indexOf("L")+1, nm.indexOf(";")), ht);
                    break;
                case 'I':
                    yy = "int";
                    break;
                case 'V':
                    yy = "void";
                    break;
                case 'C':
                    yy = "char";
                    break;
                case 'D':
                    yy = "double";
                    break;
                case 'F':
                    yy = "float";
                    break;
                case 'J':
                    yy = "long";
                    break;
                case 'S':
                    yy = "short";
                    break;
                case 'Z':
                    yy = "boolean";
                    break;
                case 'B':
                    yy = "byte";
                    break;
                default:
                    yy = "BOGUS:"+nm;
                    break;
            }
        }
        return yy+arr;
    }

    public static void main(String args[]) {
        Constructor   cn[];
        Method        mm[];
        Field         ff[];
        Class         c = null;
        Class         supClass;
        String        x, y, s1, s2, s3;
        Hashtable<String,String> classRef = new Hashtable<String,String>();

        if (args.length == 0) {
            System.out.println("Please specify a class name on the command line.");
            System.exit(1);
        }
        else {
            System.out.println("arg[0]=" + args[0]);  //���w���[���H,fullname
        }

        try {
            c = Class.forName(args[0]);
            System.out.println(c);										//��ڤ��[���H,fullname
            System.out.println();
        } catch (ClassNotFoundException ee) {
            System.out.println("Couldn't find class '"+args[0]+"'");
            System.exit(1);
        }

        {
        Class         cc[];
        Class         ctmp;
        
        //�i�����Oarray��enum��...
        if (c.isArray())      
          System.out.println("isArray");
        else if (c.isEnum())
          System.out.println("isEnum");
        else if (c.isPrimitive())          
          System.out.println("isPrimitive");
        else if (c.isSynthetic())           
          System.out.println("isSynthetic");
        else if (c.isAnnotation())            
          System.out.println("isAnnotation");    
        else if (c.isInterface())            
          System.out.println("isInterface"); 

        //��Xinner classes
        cc = c.getDeclaredClasses();  
        System.out.println("inner classes, " + cc.length);
        for (Class cite : cc)
            System.out.println(tName(cite.getName(), null));                 
        
        //��Xouter classes
        ctmp = c.getDeclaringClass(); 
        System.out.println("outer class, ");
        if (ctmp != null)
            System.out.println(ctmp.getName());
            
        Type[] tt;
        Type t;
        tt = c.getGenericInterfaces();
        t = c.getGenericSuperclass();
        //�H�W�A�ѩ�Type�O��empty interface�A�ҥH����]���వ!!  
   
        System.out.println();  
        }

        /*
         * Step 0: If we're in a package, put that out first.
         */
        Package p;
        p = c.getPackage();
        if (p != null)
            System.out.println("package " + p.getName() + ";");        

        /*
         * �B��Reflection API��Xclass�������򦨥�
         */
         
        //Reflection API�S��������ڭ̧�Ximport�A�ҥH�o�ۤv��...
        //���o�Ҧ�fields�A�N��type�O����hashtable
        ff = c.getDeclaredFields();
        for (int i = 0; i < ff.length; i++) {
            x = tName(ff[i].getType().getName(), classRef);
        }
        //���o�Ҧ�ctors�A�N��parameters type�O����hashtable
        cn = c.getDeclaredConstructors();
        for (int i = 0; i < cn.length; i++) {
            Class cx[] = cn[i].getParameterTypes();
            for (int j = 0; j < cx.length; j++) {
                x = tName(cx[j].getName(), classRef);
            }
        }
        //���o�Ҧ�methods�A�N��return/parameters type�O����hashtable
        mm = c.getDeclaredMethods();
        for (int i = 0; i < mm.length; i++) {
            x = tName(mm[i].getReturnType().getName(), classRef);
            Class cx[] = mm[i].getParameterTypes();
            for (int j = 0; j < cx.length; j++) {
                x = tName(cx[j].getName(), classRef);
            }
        }

        //����import�ۤv�A�ҥH�qhashtable�������ۤv
        classRef.remove(c.getName());

        /*
         * Step 2: �H�U�}�l�C�Lclass���e�C�����Oimport statements�C
         */
        for (Enumeration e = classRef.keys(); e.hasMoreElements(); ) {
            System.out.println("import "+e.nextElement()+";");
        }
        System.out.println();

        /*
         * Step 3: �M��Oclass or interface introducer
         */
        int mod = c.getModifiers();
        System.out.print(Modifier.toString(mod));		//���modifier

        if (Modifier.isInterface(mod)) {
            System.out.print(" ");  		//"interface" �w�t��modifier
        } else {
            System.out.print(" class ");						//����r "class"
        }
        System.out.print(tName(c.getName(), null));	//class�W��
        
        TypeVariable<Class>[] tv;
        tv = c.getTypeParameters(); //warning: unchecked conversion     
        for (int i = 0; i < tv.length; i++) {
            x = tName(tv[i].getName(), null);  //�Ҧp E,K,V...
            if (i == 0) //�Ĥ@��
                System.out.print("<" + x);       
            else 				//�D�Ĥ@��     
                System.out.print("," + x);    
            if (i == tv.length-1) //�̫�@�� 
                System.out.println(">");                                
        }                  

        //��X superclass
        supClass = c.getSuperclass();
        if (supClass != null) {						//�p�G��super class
            System.out.print(" extends "+tName(supClass.getName(), classRef));
        }

        {
        //��X implemented interfaces
        Class         cc[];
        Class         ctmp;        

        cc = c.getInterfaces();  
        if (cc.length != 0)
            System.out.print(", \r\n" + "    implements ");
        for (Class cite : cc)
            System.out.print(tName(cite.getName(), null)+", ");           
        }
                        
        System.out.println(" {");

        /*
         * Step 4: �C�L�Ҧ�fields
         * �榡���G[Modifiers] [Type] [Name] ;
         */

        System.out.println("\n\r/*\n\r * Field Definitions.\r\n */");
        for (int i = 0; i < ff.length; i++) {
            int md     = ff[i].getModifiers();
            System.out.println("    "+Modifier.toString(md)+" "+
                    tName(ff[i].getType().getName(), null) +" "+
                    ff[i].getName()+";");
            System.out.println("jj: " + ff[i].toGenericString());        
        }

        /*
         * Step 5: �C�L�Ҧ�ctors�ŧi��
         * �榡���G[Modifiers] ClassName ( [ Parameters ] ) { }
         */
        System.out.println("\n\r/*\n\r * Declared Constructors. \n\r */");
        for (int i = 0; i < cn.length; i++) {
            int md = cn[i].getModifiers();
            System.out.print("    " + Modifier.toString(md) + " " + cn[i].getName());

            Class cx[] = cn[i].getParameterTypes();
            System.out.print("(");
            for (int j = 0; j < cx.length; j++) {
                System.out.print(tName(cx[j].getName(), null));
                if (j < (cx.length - 1)) System.out.print(", ");
            }
            System.out.print(") ");
            System.out.println("{ ... }");
            System.out.println("jj: " + cn[i].toGenericString());
        }

        /*
         * Step 6: �C�L�Ҧ�methods�ŧi��
         * �榡���G[modifiers] [type] [name] ( [optional parameters] ) { }
         */
        System.out.println("\n\r/*\n\r * Declared Methods.\n\r */");
        for (int i = 0; i < mm.length; i++) {
            int md = mm[i].getModifiers();
            System.out.print("    "+Modifier.toString(md)+" "+
                    tName(mm[i].getReturnType().getName(), null)+" "+
                    mm[i].getName());

            Class cx[] = mm[i].getParameterTypes();
            System.out.print("(");
            for (int j = 0; j < cx.length; j++) {
                System.out.print(tName(cx[j].getName(), null));
                if (j < (cx.length - 1)) System.out.print(", ");
            }
            System.out.print(") ");
            System.out.println("{ ... }");
            System.out.println("jj: " + mm[i].toGenericString());
        }

        /*
         * Step 7: �C�Lclass�ŧi���̫᪺���� "}"
         */
        System.out.println("}");
        
    } //main  
}
