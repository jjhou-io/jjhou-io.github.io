//�@�̡G�J��
//�ت��G��U����JDK1.5��GP�MSerialization
//�ɦW�GShape.java
//�سy�G�� seriTest.java

import java.lang.*;  //for Comparable

public abstract class Shape 
                            implements Comparable<Shape>
{
  private int Color;
  public void setColor(int c) { Color = c; }
  public abstract void draw();

  public abstract double L();
  public int compareTo(Shape o) {  	
  	return (this.L() < o.L() ? -1 : (this.L() == o.L() ? 0 : 1)); 
  }
}
