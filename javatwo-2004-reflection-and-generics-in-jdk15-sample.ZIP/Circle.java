//�@�̡G�J��
//�ت��G��U����JDK1.5��GP�MSerialization
//�ɦW�GCircle.java
//�سy�G�� seriTest.java

import java.util.*;
import java.io.*;   // for Serializable

public class Circle<T extends Number> extends Shape
                       implements Serializable
{
  T m_x, m_y, m_r;

  public Circle(T x, T y, T r) {
    this.m_x = x;
    this.m_y = y;
    this.m_r = r;
  }

  public String toString() {
    return "[X=" + m_x + ",Y=" + m_y + ",R=" + m_r + "]";
  }

  public void draw() {
        toString();
  }

  public double L() {
        //System.out.println("in L(), m_r =" + m_r.doubleValue());
        return (2.0 * 3.141592653 * m_r.doubleValue());
  }
}
